# Диагностика PostgreSQL executor: Rust RELEASE

Это отдельные EXPLAIN ANALYZE запросы после COPY. Они не участвуют в throughput-гистограмме.
Указаны только выбранные первый/последний chunk каждого диагностического запуска; это не сумма работы всех readers.

`Shared hit/read` взяты только с корневого узла: PostgreSQL уже включает дочерние узлы в эти счётчики. Их нельзя суммировать по дереву. Это обращения к buffers, не число уникальных страниц и не прямое измерение дискового I/O.

EXPLAIN SELECT может не извлекать/сериализовывать все TOAST payloads, которые COPY отправляет клиенту. Executor milliseconds нельзя подставлять вместо времени COPY или полного Transferia pipeline. Rows × loops восстановлены из EXPLAIN; при нескольких loops исходное среднее может быть округлено PostgreSQL.

| Таблица | Механизм | P | Chunk | Root / leaves | Actual rows × loops | Shared hit | Shared read | Executor ms |
|---|---|---:|---:|---|---:|---:|---:|---:|
| public.pgsnap_clickbench | ctid | 8 | 0 | Tid Range Scan | 62574 | 5300 | 0 | 5.786 |
| public.pgsnap_clickbench | ctid | 8 | 7 | Tid Range Scan | 62168 | 5295 | 0 | 5.597 |
| public.pgsnap_clickbench | equal | 8 | 0 | Index Scan | 62498 | 63099 | 0 | 53.037 |
| public.pgsnap_clickbench | equal | 8 | 7 | Index Scan | 62500 | 63082 | 0 | 48.282 |
| public.pgsnap_clickbench | hash | 8 | 0 | Seq Scan | 62365 | 42395 | 0 | 127.296 |
| public.pgsnap_clickbench | hash | 8 | 7 | Seq Scan | 62560 | 42395 | 0 | 127.95 |
| public.pgsnap_clickbench | modulo | 8 | 0 | Seq Scan | 62500 | 42395 | 0 | 141.432 |
| public.pgsnap_clickbench | modulo | 8 | 7 | Seq Scan | 62500 | 42395 | 0 | 118.962 |
| public.pgsnap_clickbench | weighted_ctid | 8 | 0 | Tid Range Scan | 7092 | 595 | 0 | 0.757 |
| public.pgsnap_clickbench | weighted_ctid | 8 | 63 | Tid Range Scan | 6412 | 572 | 0 | 0.652 |
| public.pgsnap_numeric | ctid | 8 | 0 | Tid Range Scan | 252273 | 2581 | 0 | 13.004 |
| public.pgsnap_numeric | ctid | 8 | 7 | Tid Range Scan | 245585 | 2577 | 0 | 12.738 |
| public.pgsnap_numeric | equal | 8 | 0 | Index Scan | 250000 | 3244 | 0 | 29.946 |
| public.pgsnap_numeric | equal | 8 | 7 | Index Scan | 250000 | 3264 | 0 | 29.804 |
| public.pgsnap_numeric | hash | 8 | 0 | Seq Scan | 249803 | 20644 | 0 | 233.377 |
| public.pgsnap_numeric | hash | 8 | 7 | Seq Scan | 250332 | 20644 | 0 | 240.941 |
| public.pgsnap_numeric | modulo | 8 | 0 | Seq Scan | 250000 | 20644 | 0 | 855.218 |
| public.pgsnap_numeric | modulo | 8 | 7 | Seq Scan | 250000 | 20644 | 0 | 841.423 |
| public.pgsnap_numeric | weighted_ctid | 8 | 0 | Tid Range Scan | 31565 | 306 | 0 | 1.653 |
| public.pgsnap_numeric | weighted_ctid | 8 | 63 | Tid Range Scan | 29943 | 354 | 0 | 1.568 |
| public.pgsnap_numeric_bloat | ctid | 8 | 0 | Tid Range Scan | 0 | 2575 | 0 | 1.907 |
| public.pgsnap_numeric_bloat | ctid | 8 | 7 | Tid Range Scan | 200000 | 2574 | 0 | 11.23 |
| public.pgsnap_numeric_bloat | equal | 8 | 0 | Index Scan | 25000 | 5248 | 0 | 11.891 |
| public.pgsnap_numeric_bloat | equal | 8 | 7 | Index Scan | 25000 | 329 | 0 | 3.088 |
| public.pgsnap_numeric_bloat | hash | 8 | 0 | Seq Scan | 25220 | 20599 | 0 | 36.443 |
| public.pgsnap_numeric_bloat | hash | 8 | 7 | Seq Scan | 24974 | 20599 | 0 | 36.329 |
| public.pgsnap_numeric_bloat | modulo | 8 | 0 | Seq Scan | 25000 | 20599 | 0 | 96.066 |
| public.pgsnap_numeric_bloat | modulo | 8 | 7 | Seq Scan | 25000 | 20599 | 0 | 96.491 |
| public.pgsnap_numeric_bloat | weighted_ctid | 8 | 0 | Tid Range Scan | 1897 | 18557 | 0 | 12.602 |
| public.pgsnap_numeric_bloat | weighted_ctid | 8 | 63 | Tid Range Scan | 3476 | 37 | 0 | 0.202 |
| public.pgsnap_numeric_width_skew | ctid | 8 | 0 | Tid Range Scan | 26166 | 382 | 0 | 1.465 |
| public.pgsnap_numeric_width_skew | ctid | 8 | 7 | Tid Range Scan | 24836 | 378 | 0 | 1.399 |
| public.pgsnap_numeric_width_skew | equal | 8 | 0 | Index Scan | 25000 | 436 | 0 | 3.289 |
| public.pgsnap_numeric_width_skew | equal | 8 | 7 | Index Scan | 25000 | 452 | 0 | 3.345 |
| public.pgsnap_numeric_width_skew | hash | 8 | 0 | Seq Scan | 25007 | 3052 | 0 | 24.321 |
| public.pgsnap_numeric_width_skew | hash | 8 | 7 | Seq Scan | 25135 | 3052 | 0 | 24.294 |
| public.pgsnap_numeric_width_skew | modulo | 8 | 0 | Seq Scan | 25000 | 3052 | 0 | 86 |
| public.pgsnap_numeric_width_skew | modulo | 8 | 7 | Seq Scan | 25000 | 3052 | 0 | 87.419 |
| public.pgsnap_numeric_width_skew | weighted_ctid | 8 | 0 | Tid Range Scan | 18432 | 264 | 0 | 1.089 |
| public.pgsnap_numeric_width_skew | weighted_ctid | 8 | 28 | Tid Range Scan | 7 | 1 | 0 | 0.015 |

Полные предикаты, счётчики каждого leaf и Rows Removed сохранены в `diagnostics.csv` и `diagnostics.json`. Rows Removed сохранены на своём узле с отдельно указанными loops; они не объявляются количеством уникальных отброшенных строк во всём плане.
