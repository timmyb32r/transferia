# Происхождение результатов и воспроизведение

В [основной отчёт](../../pg-snapshot-benchmark-2026-09-20.md) входят **1 044
измерения чтения Rust release**, разделённые на три серии. Прототипные
Python/C-замеры, smoke и диагностические чтения в эти числа не входят.

| Серия | Каталоги исходных событий | Fixtures | Стратегий | P | Повторов | Успешных COPY-прогонов | Агрегаты |
|---|---|---:|---:|---|---:|---:|---|
| Основная, v1 | `rust-{profile}` | 6 | 10 | 1/2/4/8; single только P1 | 3 | 666 | [results/summary.csv](results/summary.csv) |
| Кандидаты, v2 | `rust-candidate-{profile}` | 6 | 5 | 8/16/32 | 3 | 270 | [results-candidate/summary.csv](results-candidate/summary.csv) |
| Уточнение, v3 | `rust-ctidhash-{profile}` | 3 | 4 | 4/8/16 | 3 | 108 | [results-refined/summary.csv](results-refined/summary.csv) |

Шесть profiles: `numeric`, `numeric_skew`, `transfer_logs`, `clickbench`,
`numeric_bloat`, `numeric_width_skew`. Уточнённая серия использует только
`numeric_skew`, `numeric_bloat`, `numeric_width_skew`. Точный список стратегий
каждой серии находится в [командах запуска](fixtures/README.md#запуск-трёх-серий-измерений)
и в событии `experiment` каждого файла. Серии не объединялись при вычислении
медиан или выборе лучшего P.

Во всех сериях seed `20260920`, sample `1%`, `chunks_per_worker=8`, три
повторения каждой комбинации. Расписание перемешано с фиксированным seed;
`REPEATABLE(seed)` сохраняет выборку для неизменного heap. Повторы проверяют
разброс выполнения, **не** устойчивость результата к разным sample seeds.
Основной `sample` использует `SYSTEM`; weighted-стратегии — `BERNOULLI`.

## Измеритель и данные

Координатор, PostgreSQL COPY reader, счётчик бинарных строк и таймеры написаны
на Rust. В событиях всех трёх серий зафиксированы `release_build=true`,
`debug_assertions=false`, `consumer=rust_release`, 16 потоков Tokio.
Измеритель отказывается запускаться с включёнными debug assertions.
Текущий исходник v3: [main.rs](../../../scripts/pg-snapshot-benchmark/src/main.rs),
[Cargo.toml](../../../scripts/pg-snapshot-benchmark/Cargo.toml),
[Cargo.lock](../../../scripts/pg-snapshot-benchmark/Cargo.lock).
Замороженные `main.rs` для [v1](raw/main-v1.rs.gz) и [v2](raw/main-v2.rs.gz)
сохранены отдельно для сверки изменений; manifest/lock указаны выше.
v3 добавляет новые стратегии к прежним, не заменяя измеренные реализации.

Сначала production-источник `data_generator` и PostgreSQL sink Transferia
создали три исходные таблицы. Для этой загрузки использован уже существовавший
на dev-сервере бинарник `~/cursor/transferia/target/debug/transferia`.
**Точный исходный commit этого готового бинарника не установлен.** Его нельзя
объявлять проверенной сборкой текущего checkout. Это ограничение provenance
генератора; этот бинарник не исполнял сравнительные чтения.

Конфигурации, фактические размеры и преобразования доступны в
[fixtures/](fixtures/README.md), [load-results.json](raw/load-results.json),
[preparation-results.json](raw/preparation-results.json) и
[диагностике fixtures](fixtures/diagnose-fixtures.log).
Времена загрузки/подготовки — отдельные служебные наблюдения; они не входят
в 1 044 измерения производительности способов чтения. SQL-производные
skew-fixtures не подменяют три исходных генераторных набора.

## Среда и границы измерения

[cluster-resources.json](raw/cluster-resources.json) фиксирует preset сервера
`s4-c32-m128`, диск local SSD; [client-environment.txt](raw/client-environment.txt)
содержит Linux/CPU/RAM клиента и версии Rust/Cargo. Версия PostgreSQL и адрес
реального сервера сохранены в событии `table`; настройки PostgreSQL — в
`settings` внутри [preparation-results.json](raw/preparation-results.json).
Каждый reader отдельно задаёт `max_parallel_workers_per_gather=0` и `jit=off`.
Это отличается от общей настройки сервера, которая также сохранена.

Сравниваются полные бинарные COPY с одинаковой проекцией и общим экспортированным
snapshot. `total_seconds = planning_seconds + scan_seconds`; открытие readers
и импорт snapshot записаны отдельно. Метрика `with_startup_seconds` добавляет
эту стоимость **к каждому прогону до агрегации**. Обе метрики исключают metadata,
проверочные COUNT/DISTINCT, EXPLAIN и запись артефактов. Поля результата читаются
полностью, но не преобразуются в Arrow и не записываются в destination.

Каждый timed run проверяет точное количество строк и бинарное framing.
Это не checksum полного payload. Отдельные
[34 функциональных проверки](raw/edge-results.json) сверяют точные множества
идентичностей на небольших fixtures. [linear-equivalence.json](raw/linear-equivalence.json)
проверяет совпадение массивов границ старого и линейного weighted при P8/P16.
Диагностические EXPLAIN ANALYZE сохранены отдельно в `rust-diagnostic-*.events.jsonl.gz`
и [results/diagnostics/](results/diagnostics/FINDINGS.md).

## Исходные события и offline-анализ

В [raw/](raw/) сохранены 15 сжатых performance-файлов `*.events.jsonl.gz`
и четыре диагностических. Например,
[main numeric](raw/rust-numeric.events.jsonl.gz),
[candidate numeric](raw/rust-candidate-numeric.events.jsonl.gz),
[refined TOAST](raw/rust-ctidhash-numeric_width_skew.events.jsonl.gz).
События содержат конфигурацию, metadata, расписание, predicates, planning,
каждый chunk с worker/строками/байтами, итоговые timing и завершение серии.

В каждом каталоге `results*` есть `completed-runs.csv`, `summary.csv/json`,
`profile-summary.csv`, `worker-balance.csv` и PNG/SVG. Медианы, min/max и n
сохраняются отдельно по profile/table/числу строк/стратегии/P. Min/max трёх
повторов не являются доверительным интервалом. Byte shares включают framing
COPY; service-time imbalance не является загрузкой CPU.

Для повторного анализа без БД распаковать архивы в новый каталог из корня
репозитория; существующие файлы эта команда не перезаписывает:

```sh
python3 - <<'PY'
import gzip
from pathlib import Path

raw = Path('docs/research/pg-snapshot-benchmark-2026-09-20/raw')
replay = Path('target/benchmarks/pg-snapshot-replay-2026-09-20')
for archive in sorted(raw.glob('*.events.jsonl.gz')):
    directory = replay / archive.name.removesuffix('.events.jsonl.gz')
    directory.mkdir(parents=True, exist_ok=True)
    with gzip.open(archive, 'rb') as source, (directory / 'events.jsonl').open('xb') as target:
        target.write(source.read())
PY
```

Далее нужен Python с matplotlib; Python выполняет только анализ готовых данных:

```sh
python3 scripts/analyze_pg_snapshot_benchmark.py \
  --input target/benchmarks/pg-snapshot-replay-2026-09-20 \
  --output target/benchmarks/pg-snapshot-replay-2026-09-20/analysis-main
python3 scripts/analyze_pg_snapshot_benchmark.py \
  --input target/benchmarks/pg-snapshot-replay-2026-09-20 \
  --include 'rust-candidate-*' \
  --output target/benchmarks/pg-snapshot-replay-2026-09-20/analysis-candidate
python3 scripts/analyze_pg_snapshot_benchmark.py \
  --input target/benchmarks/pg-snapshot-replay-2026-09-20 \
  --include 'rust-ctidhash-*' \
  --output target/benchmarks/pg-snapshot-replay-2026-09-20/analysis-refined
```

Default include ограничен шестью исходными main-каталогами. Diagnostic,
smoke и другие серии не добавляются автоматически. Результаты другого
запуска с такими же именами нужно хранить под отдельным input, чтобы не
смешивать экспериментальные условия.
