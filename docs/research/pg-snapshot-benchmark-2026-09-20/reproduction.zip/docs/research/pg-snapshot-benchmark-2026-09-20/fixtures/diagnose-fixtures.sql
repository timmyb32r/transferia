-- Read-only fixture diagnostics; never re-run preparation DDL for this.
-- row_datum_bytes = pg_column_size(whole-row datum), NOT COPY or heap bytes.
-- It can materialize external values; statement timeout bounds diagnostics.
\set ON_ERROR_STOP on
\set bench_schema public
\timing on
SET search_path TO :"bench_schema", pg_catalog;
SET statement_timeout = '60s';
BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY;
SELECT c.relname, pg_relation_size(c.oid) AS heap_bytes,
       pg_indexes_size(c.oid) AS index_bytes,
       CASE WHEN c.reltoastrelid=0 THEN 0 ELSE pg_relation_size(c.reltoastrelid) END AS toast_heap_bytes,
       pg_total_relation_size(c.oid) AS total_bytes,c.relpages,c.reltuples
FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
WHERE n.nspname=:'bench_schema' AND c.relname IN (
'pgsnap_numeric',
'pgsnap_transfer_logs',
'pgsnap_clickbench',
'pgsnap_numeric_skew',
'pgsnap_numeric_bloat',
'pgsnap_numeric_width_skew') ORDER BY c.relname;

-- numeric: exact rows and PostgreSQL row-datum bytes per physical eighth.
WITH physical AS (
    SELECT pg_relation_size('pgsnap_numeric') / current_setting('block_size')::bigint AS blocks
), counts AS (
    SELECT least(7, split_part(trim(both '()' FROM b.ctid::text), ',', 1)::bigint * 8 /
                    greatest(1, physical.blocks)) AS part,
           count(*) AS rows,
           sum(pg_column_size(b.*)::bigint) AS row_datum_bytes,
           min(b."column_1") AS min_key,max(b."column_1") AS max_key
    FROM ONLY pgsnap_numeric AS b CROSS JOIN physical GROUP BY part
)
SELECT 'numeric' AS profile,part,coalesce(counts.rows,0) AS rows,
       coalesce(row_datum_bytes,0) AS row_datum_bytes,min_key,max_key
FROM generate_series(0,7) AS parts(part) LEFT JOIN counts USING (part)
ORDER BY part;

-- transfer_logs: exact rows and PostgreSQL row-datum bytes per physical eighth.
WITH physical AS (
    SELECT pg_relation_size('pgsnap_transfer_logs') / current_setting('block_size')::bigint AS blocks
), counts AS (
    SELECT least(7, split_part(trim(both '()' FROM b.ctid::text), ',', 1)::bigint * 8 /
                    greatest(1, physical.blocks)) AS part,
           count(*) AS rows,
           sum(pg_column_size(b.*)::bigint) AS row_datum_bytes,
           min(b."_system_offset") AS min_key,max(b."_system_offset") AS max_key
    FROM ONLY pgsnap_transfer_logs AS b CROSS JOIN physical GROUP BY part
)
SELECT 'transfer_logs' AS profile,part,coalesce(counts.rows,0) AS rows,
       coalesce(row_datum_bytes,0) AS row_datum_bytes,min_key,max_key
FROM generate_series(0,7) AS parts(part) LEFT JOIN counts USING (part)
ORDER BY part;

-- clickbench: exact rows and PostgreSQL row-datum bytes per physical eighth.
WITH physical AS (
    SELECT pg_relation_size('pgsnap_clickbench') / current_setting('block_size')::bigint AS blocks
), counts AS (
    SELECT least(7, split_part(trim(both '()' FROM b.ctid::text), ',', 1)::bigint * 8 /
                    greatest(1, physical.blocks)) AS part,
           count(*) AS rows,
           sum(pg_column_size(b.*)::bigint) AS row_datum_bytes,
           min(b."WatchID") AS min_key,max(b."WatchID") AS max_key
    FROM ONLY pgsnap_clickbench AS b CROSS JOIN physical GROUP BY part
)
SELECT 'clickbench' AS profile,part,coalesce(counts.rows,0) AS rows,
       coalesce(row_datum_bytes,0) AS row_datum_bytes,min_key,max_key
FROM generate_series(0,7) AS parts(part) LEFT JOIN counts USING (part)
ORDER BY part;

-- numeric_skew: exact rows and PostgreSQL row-datum bytes per physical eighth.
WITH physical AS (
    SELECT pg_relation_size('pgsnap_numeric_skew') / current_setting('block_size')::bigint AS blocks
), counts AS (
    SELECT least(7, split_part(trim(both '()' FROM b.ctid::text), ',', 1)::bigint * 8 /
                    greatest(1, physical.blocks)) AS part,
           count(*) AS rows,
           sum(pg_column_size(b.*)::bigint) AS row_datum_bytes,
           min(b."column_1") AS min_key,max(b."column_1") AS max_key
    FROM ONLY pgsnap_numeric_skew AS b CROSS JOIN physical GROUP BY part
)
SELECT 'numeric_skew' AS profile,part,coalesce(counts.rows,0) AS rows,
       coalesce(row_datum_bytes,0) AS row_datum_bytes,min_key,max_key
FROM generate_series(0,7) AS parts(part) LEFT JOIN counts USING (part)
ORDER BY part;

-- numeric_bloat: exact rows and PostgreSQL row-datum bytes per physical eighth.
WITH physical AS (
    SELECT pg_relation_size('pgsnap_numeric_bloat') / current_setting('block_size')::bigint AS blocks
), counts AS (
    SELECT least(7, split_part(trim(both '()' FROM b.ctid::text), ',', 1)::bigint * 8 /
                    greatest(1, physical.blocks)) AS part,
           count(*) AS rows,
           sum(pg_column_size(b.*)::bigint) AS row_datum_bytes,
           min(b."column_1") AS min_key,max(b."column_1") AS max_key
    FROM ONLY pgsnap_numeric_bloat AS b CROSS JOIN physical GROUP BY part
)
SELECT 'numeric_bloat' AS profile,part,coalesce(counts.rows,0) AS rows,
       coalesce(row_datum_bytes,0) AS row_datum_bytes,min_key,max_key
FROM generate_series(0,7) AS parts(part) LEFT JOIN counts USING (part)
ORDER BY part;

-- numeric_width_skew: exact rows and PostgreSQL row-datum bytes per physical eighth.
WITH physical AS (
    SELECT pg_relation_size('pgsnap_numeric_width_skew') / current_setting('block_size')::bigint AS blocks
), counts AS (
    SELECT least(7, split_part(trim(both '()' FROM b.ctid::text), ',', 1)::bigint * 8 /
                    greatest(1, physical.blocks)) AS part,
           count(*) AS rows,
           sum(pg_column_size(b.*)::bigint) AS row_datum_bytes,
           min(b."column_1") AS min_key,max(b."column_1") AS max_key
    FROM ONLY pgsnap_numeric_width_skew AS b CROSS JOIN physical GROUP BY part
)
SELECT 'numeric_width_skew' AS profile,part,coalesce(counts.rows,0) AS rows,
       coalesce(row_datum_bytes,0) AS row_datum_bytes,min_key,max_key
FROM generate_series(0,7) AS parts(part) LEFT JOIN counts USING (part)
ORDER BY part;

COMMIT;
