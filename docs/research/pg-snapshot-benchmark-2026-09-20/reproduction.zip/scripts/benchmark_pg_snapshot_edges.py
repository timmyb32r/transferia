#!/usr/bin/env python3
"""Small, deterministic PostgreSQL snapshot-splitting correctness experiments.

Uses libpq PG* environment variables and psycopg 3. Only changes the dedicated
transferia_snapshot_edges_20260920 schema. Results contain no connection secrets.
This is a benchmark companion, not a production table-copy implementation.
"""
from __future__ import annotations
import argparse
from collections import Counter
from contextlib import contextmanager
import json
from pathlib import Path
import time
import psycopg
from psycopg import sql
SCHEMA = 'transferia_snapshot_edges_20260920'
TABLES = tuple('empty_table single_row stale_pages extreme_keys nullable_keys composite_keys key_moves tid_moves growth parted uuid_keys binary_keys date_keys timestamp_keys decimal_keys float_keys locale_keys mixed_composite null_patterns all_nulls stats_missing stats_stale stats_mcv wide_keys rls_keys array_keys enum_keys attach_candidate'.split())

def connect():
    conn = psycopg.connect(autocommit=True, connect_timeout=15, application_name='transferia_snapshot_edges_20260920')
    return conn

@contextmanager
def snapshot(exported=None):
    with connect() as conn:
        conn.execute('BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY')
        if exported:
            conn.execute(sql.SQL('SET TRANSACTION SNAPSHOT {}').format(sql.Literal(exported)))
        # Odyssey transaction pooling does not preserve session SET between
        # autocommit statements. Settings belong inside this pinned transaction.
        conn.execute("SET LOCAL statement_timeout = '60s'")
        conn.execute("SET LOCAL lock_timeout = '2s'")
        conn.execute('SET LOCAL max_parallel_workers_per_gather = 0')
        conn.execute('SET LOCAL extra_float_digits = 3')
        try:
            yield conn
        finally:
            conn.execute('ROLLBACK')

def scalar(conn, query, params=None):
    return conn.execute(query, params).fetchone()[0]

def values(conn, query, params=None):
    return [row[0] for row in conn.execute(query, params).fetchall()]

def pages(conn, table):
    return scalar(conn, "SELECT pg_relation_size(%s::regclass, 'main') / current_setting('block_size')::int", (f'{SCHEMA}.{table}',))

def table_query(table, suffix=''):
    return sql.SQL('SELECT id FROM ONLY {} ').format(sql.Identifier(SCHEMA, table)) + sql.SQL(suffix)

def ctid_parts(conn, table, number=8):
    size = pages(conn, table)
    step = max(1, (size + number - 1) // number)
    result = []
    for lower in range(0, max(size, 1), step):
        upper = lower + step
        result.extend(values(conn, table_query(table, 'WHERE ctid >= %s::tid AND ctid < %s::tid'), (f'({lower},0)', f'({upper},0)')))
    return result

def setup(conn):
    conn.execute(sql.SQL('CREATE SCHEMA IF NOT EXISTS {}').format(sql.Identifier(SCHEMA)))
    for name in TABLES:
        conn.execute(sql.SQL('DROP TABLE IF EXISTS {} CASCADE').format(sql.Identifier(SCHEMA, name)))
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.empty_table(id bigint PRIMARY KEY)')
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.single_row(id bigint PRIMARY KEY)')
    conn.execute('INSERT INTO transferia_snapshot_edges_20260920.single_row VALUES (1)')
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.stale_pages(id bigint PRIMARY KEY, payload text) WITH (autovacuum_enabled=false)')
    conn.execute("INSERT INTO transferia_snapshot_edges_20260920.stale_pages SELECT i, repeat('x', 250) FROM generate_series(1, 10000) i")
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.extreme_keys(id bigint PRIMARY KEY)')
    conn.execute('INSERT INTO transferia_snapshot_edges_20260920.extreme_keys VALUES (-9223372036854775808), (-9000000000000000000), (-1), (0), (1), (2), (9223372036854775807)')
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.nullable_keys(id bigint PRIMARY KEY, split_key integer)')
    conn.execute('INSERT INTO transferia_snapshot_edges_20260920.nullable_keys SELECT i, CASE WHEN i % 7 = 0 THEN NULL ELSE i % 3 END FROM generate_series(1, 100) i')
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.composite_keys(tenant text COLLATE "C", id bigint, PRIMARY KEY(tenant,id))')
    conn.execute("INSERT INTO transferia_snapshot_edges_20260920.composite_keys SELECT tenant, i FROM unnest(ARRAY['', 'A', 'a', 'ab', 'z', 'é', 'я', '😀']) tenant CROSS JOIN generate_series(-2,2) i")
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.key_moves(id bigint PRIMARY KEY, logical_id bigint UNIQUE NOT NULL)')
    conn.execute('INSERT INTO transferia_snapshot_edges_20260920.key_moves SELECT i,i FROM generate_series(1,100) i')
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.tid_moves(id bigint PRIMARY KEY, payload text) WITH(fillfactor=100, autovacuum_enabled=false)')
    conn.execute('ALTER TABLE transferia_snapshot_edges_20260920.tid_moves ALTER COLUMN payload SET STORAGE PLAIN')
    conn.execute("INSERT INTO transferia_snapshot_edges_20260920.tid_moves SELECT i, repeat('x', 1800) FROM generate_series(1,300) i")
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.growth(id bigint PRIMARY KEY, payload text) WITH(autovacuum_enabled=false)')
    conn.execute('ALTER TABLE transferia_snapshot_edges_20260920.growth ALTER COLUMN payload SET STORAGE PLAIN')
    conn.execute("INSERT INTO transferia_snapshot_edges_20260920.growth SELECT i, repeat('x',1800) FROM generate_series(1,10) i")
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.parted(part integer, id bigint, PRIMARY KEY(part,id)) PARTITION BY LIST(part)')
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.parted_a PARTITION OF transferia_snapshot_edges_20260920.parted FOR VALUES IN (1)')
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.parted_b PARTITION OF transferia_snapshot_edges_20260920.parted FOR VALUES IN (2)')
    conn.execute('INSERT INTO transferia_snapshot_edges_20260920.parted SELECT part, i FROM generate_series(1,2) part CROSS JOIN generate_series(1,10) i')
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.uuid_keys(row_id integer UNIQUE NOT NULL, k uuid PRIMARY KEY)')
    conn.execute("INSERT INTO transferia_snapshot_edges_20260920.uuid_keys VALUES (1,'00000000-0000-0000-0000-000000000000'),(2,'00000000-0000-0000-0000-000000000001'),(3,'00000000-0000-0000-0000-ffffffffffff'),(4,'10000000-0000-0000-0000-000000000000'),(5,'80000000-0000-0000-0000-000000000000'),(6,'ffffffff-ffff-ffff-ffff-ffffffffffff')")
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.binary_keys(row_id integer UNIQUE NOT NULL, k bytea PRIMARY KEY)')
    conn.execute("INSERT INTO transferia_snapshot_edges_20260920.binary_keys SELECT ord,decode(v,'hex') FROM unnest(ARRAY['','00','0000','0001','01','0100','7f','80','ff','ff00']) WITH ORDINALITY AS t(v,ord)")
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.date_keys(row_id integer UNIQUE NOT NULL, k date PRIMARY KEY)')
    conn.execute("INSERT INTO transferia_snapshot_edges_20260920.date_keys SELECT ord,v::date FROM unnest(ARRAY['-infinity','0001-01-01 BC','0001-01-01 AD','1900-03-01','2000-02-29','9999-12-31','infinity']) WITH ORDINALITY AS t(v,ord)")
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.timestamp_keys(row_id integer UNIQUE NOT NULL, k timestamptz PRIMARY KEY)')
    conn.execute("INSERT INTO transferia_snapshot_edges_20260920.timestamp_keys SELECT ord,v::timestamptz FROM unnest(ARRAY['-infinity','0001-01-01 00:00:00+00 BC','1969-12-31 23:59:59.999999+00','2024-03-31 01:59:59.999999+01','2024-03-31 03:00:00+02','2024-11-03 01:30:00-04','2024-11-03 01:30:00-05','infinity']) WITH ORDINALITY AS t(v,ord)")
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.decimal_keys(row_id integer UNIQUE NOT NULL, k numeric PRIMARY KEY)')
    conn.execute("INSERT INTO transferia_snapshot_edges_20260920.decimal_keys SELECT ord,v::numeric FROM unnest(ARRAY['-100000000000000000000000000000000000000000000000000.1','-0.00000000000000000001','0','0.00000000000000000001','1.00000000000000000001','1.00000000000000000002','100000000000000000000000000000000000000000000000000.1']) WITH ORDINALITY AS t(v,ord)")
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.float_keys(row_id integer UNIQUE NOT NULL, k double precision PRIMARY KEY)')
    conn.execute("INSERT INTO transferia_snapshot_edges_20260920.float_keys SELECT ord,v::double precision FROM unnest(ARRAY['-Infinity','-1','-0','1','Infinity','NaN']) WITH ORDINALITY AS t(v,ord)")
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.locale_keys(row_id integer UNIQUE NOT NULL, k text PRIMARY KEY)')
    conn.execute("INSERT INTO transferia_snapshot_edges_20260920.locale_keys SELECT ord,v FROM unnest(ARRAY['','A','a','aa','z','ä','é','é','я','😀']) WITH ORDINALITY AS t(v,ord)")
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.mixed_composite(row_id integer UNIQUE NOT NULL, tenant text COLLATE "C", sequence numeric, happened timestamptz, PRIMARY KEY(tenant,sequence,happened))')
    conn.execute("INSERT INTO transferia_snapshot_edges_20260920.mixed_composite SELECT row_number() OVER (),tenant,seq::numeric,stamp::timestamptz FROM unnest(ARRAY['','A','a','é','😀']) tenant CROSS JOIN unnest(ARRAY['-0.00000000000000000001','1.00000000000000000001','1.00000000000000000002']) seq CROSS JOIN unnest(ARRAY['2024-11-03 01:30:00-04','2024-11-03 01:30:00-05']) stamp")
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.null_patterns(id integer PRIMARY KEY,a integer,b integer)')
    conn.execute('INSERT INTO transferia_snapshot_edges_20260920.null_patterns SELECT i,CASE WHEN i%4=0 THEN NULL ELSE i%3 END,CASE WHEN i%5=0 THEN NULL ELSE i%2 END FROM generate_series(1,100) i')
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.all_nulls(id integer PRIMARY KEY,k integer)')
    conn.execute('INSERT INTO transferia_snapshot_edges_20260920.all_nulls SELECT i,NULL FROM generate_series(1,11) i')
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.stats_missing(id integer PRIMARY KEY,k integer) WITH(autovacuum_enabled=false)')
    conn.execute('INSERT INTO transferia_snapshot_edges_20260920.stats_missing SELECT i,i FROM generate_series(1,1000) i')
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.stats_stale(row_id integer UNIQUE NOT NULL,k integer PRIMARY KEY) WITH(autovacuum_enabled=false)')
    conn.execute('INSERT INTO transferia_snapshot_edges_20260920.stats_stale SELECT i,i FROM generate_series(1,1000) i')
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.stats_mcv(id integer PRIMARY KEY,k integer NOT NULL) WITH(autovacuum_enabled=false)')
    conn.execute('INSERT INTO transferia_snapshot_edges_20260920.stats_mcv SELECT i,CASE WHEN i<=9000 THEN 0 ELSE i-9000 END FROM generate_series(1,10000) i')
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.wide_keys(row_id integer UNIQUE NOT NULL,k text PRIMARY KEY)')
    conn.execute("INSERT INTO transferia_snapshot_edges_20260920.wide_keys SELECT i,repeat('x',1500)||lpad(i::text,6,'0') FROM generate_series(1,64) i")
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.rls_keys(id integer PRIMARY KEY,row_id integer UNIQUE NOT NULL,k integer UNIQUE NOT NULL)')
    conn.execute('INSERT INTO transferia_snapshot_edges_20260920.rls_keys SELECT i,i,i FROM generate_series(1,100) i')
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.array_keys(row_id integer UNIQUE NOT NULL,k integer[] PRIMARY KEY)')
    conn.execute("INSERT INTO transferia_snapshot_edges_20260920.array_keys SELECT ord,v::integer[] FROM unnest(ARRAY['{}','{-1}','{1}','{1,NULL}','{1,2}','[0:1]={1,2}','{2}','{2,1}','{NULL}']) WITH ORDINALITY AS t(v,ord)")
    conn.execute('DROP TYPE IF EXISTS transferia_snapshot_edges_20260920.edge_priority')
    conn.execute("CREATE TYPE transferia_snapshot_edges_20260920.edge_priority AS ENUM('z_low','a_middle','m_high')")
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.enum_keys(row_id integer UNIQUE NOT NULL,k transferia_snapshot_edges_20260920.edge_priority PRIMARY KEY)')
    conn.execute("INSERT INTO transferia_snapshot_edges_20260920.enum_keys VALUES(1,'z_low'),(2,'a_middle'),(3,'m_high')")
    conn.execute('CREATE TABLE transferia_snapshot_edges_20260920.attach_candidate(part integer NOT NULL,id bigint NOT NULL,PRIMARY KEY(part,id))')

def empty_and_tiny():
    with snapshot() as conn:
        empty = ctid_parts(conn, 'empty_table', 32)
        tiny = ctid_parts(conn, 'single_row', 32)
        assert empty == [] and tiny == [1]
        return {'empty_rows': len(empty), 'single_rows': len(tiny), 'requested_parts': 32}

def stale_catalog_pages():
    with snapshot() as conn:
        estimated = scalar(conn, "SELECT relpages FROM pg_class WHERE oid='transferia_snapshot_edges_20260920.stale_pages'::regclass")
        physical = pages(conn, 'stale_pages')
        truth = scalar(conn, 'SELECT count(*) FROM transferia_snapshot_edges_20260920.stale_pages')
        naive = scalar(conn, 'SELECT count(*) FROM transferia_snapshot_edges_20260920.stale_pages WHERE ctid < %s::tid', (f'({estimated},0)',))
        correct = ctid_parts(conn, 'stale_pages')
        assert estimated == 0 and physical > 0 and (naive == 0) and (len(set(correct)) == truth == len(correct))
        return {'pg_class_relpages': estimated, 'actual_pages': physical, 'truth_rows': truth, 'rows_using_relpages_as_bound': naive, 'rows_using_physical_size': len(correct)}

def bounds_outside_heap():
    with snapshot() as conn:
        table_pages = pages(conn, 'single_row')
        too_high = scalar(conn, "SELECT count(*) FROM transferia_snapshot_edges_20260920.single_row WHERE ctid >= '(4000000000,0)'::tid")
        reverse = scalar(conn, "SELECT count(*) FROM transferia_snapshot_edges_20260920.single_row WHERE ctid >= '(2,0)'::tid AND ctid < '(1,0)'::tid")
        full = scalar(conn, "SELECT count(*) FROM transferia_snapshot_edges_20260920.single_row WHERE ctid >= '(0,0)'::tid AND ctid < '(4000000000,0)'::tid")
        assert too_high == reverse == 0 and full == 1
        return {'table_pages': table_pages, 'past_end_rows': too_high, 'reversed_rows': reverse, 'oversized_upper_bound_rows': full}

def integer_overflow_and_tails():
    with connect() as conn:
        try:
            conn.execute('SELECT max(id) - min(id) + 1 FROM transferia_snapshot_edges_20260920.extreme_keys')
        except psycopg.errors.NumericValueOutOfRange as exc:
            overflow_sqlstate = exc.sqlstate
        else:
            raise AssertionError('expected bigint subtraction overflow')
        lo, hi = conn.execute('SELECT min(id), max(id) FROM transferia_snapshot_edges_20260920.extreme_keys').fetchone()
        cuts = [lo + (hi - lo + 1) * part // 4 for part in range(1, 4)]
        chunks = [values(conn, 'SELECT id FROM transferia_snapshot_edges_20260920.extreme_keys WHERE id < %s', (cuts[0],))]
        chunks.extend((values(conn, 'SELECT id FROM transferia_snapshot_edges_20260920.extreme_keys WHERE id >= %s AND id < %s', (a, b)) for a, b in zip(cuts, cuts[1:])))
        chunks.append(values(conn, 'SELECT id FROM transferia_snapshot_edges_20260920.extreme_keys WHERE id >= %s', (cuts[-1],)))
        all_rows = [x for part in chunks for x in part]
        truth = values(conn, 'SELECT id FROM transferia_snapshot_edges_20260920.extreme_keys ORDER BY id')
        assert sorted(all_rows) == truth and len(all_rows) == len(set(all_rows))
        return {'native_bigint_span_error': overflow_sqlstate, 'python_wide_integer_cuts': cuts, 'partition_counts': [len(p) for p in chunks], 'all_rows_exact': True}

def null_and_duplicate_values():
    with snapshot() as conn:
        truth = scalar(conn, 'SELECT count(*) FROM transferia_snapshot_edges_20260920.nullable_keys')
        without_null = sum((scalar(conn, 'SELECT count(*) FROM transferia_snapshot_edges_20260920.nullable_keys WHERE split_key >= %s AND split_key < %s', (i, i + 1)) for i in range(3)))
        nulls = scalar(conn, 'SELECT count(*) FROM transferia_snapshot_edges_20260920.nullable_keys WHERE split_key IS NULL')
        bad_ids, last = ([], -1)
        while True:
            rows = conn.execute('SELECT id,split_key FROM transferia_snapshot_edges_20260920.nullable_keys WHERE split_key > %s ORDER BY split_key,id LIMIT 10', (last,)).fetchall()
            if not rows:
                break
            bad_ids.extend((row[0] for row in rows))
            last = rows[-1][1]
        good_ids, last_pair = ([], None)
        while True:
            if last_pair is None:
                rows = conn.execute('SELECT id,split_key FROM transferia_snapshot_edges_20260920.nullable_keys WHERE split_key IS NOT NULL ORDER BY split_key,id LIMIT 10').fetchall()
            else:
                rows = conn.execute('SELECT id,split_key FROM transferia_snapshot_edges_20260920.nullable_keys WHERE (split_key,id) > (%s,%s) ORDER BY split_key,id LIMIT 10', last_pair).fetchall()
            if not rows:
                break
            good_ids.extend((row[0] for row in rows))
            last_pair = (rows[-1][1], rows[-1][0])
        good_ids.extend(values(conn, 'SELECT id FROM transferia_snapshot_edges_20260920.nullable_keys WHERE split_key IS NULL'))
        assert without_null + nulls == truth and len(bad_ids) < without_null
        assert len(good_ids) == len(set(good_ids)) == truth
        return {'truth_rows': truth, 'range_rows_without_null_bucket': without_null, 'null_bucket_rows': nulls, 'nonunique_keyset_rows': len(bad_ids), 'tuple_keyset_plus_null_bucket_rows': len(good_ids)}

def inclusive_boundary_overlap():
    with snapshot() as conn:
        bad = values(conn, 'SELECT id FROM transferia_snapshot_edges_20260920.extreme_keys WHERE id <= 0') + values(conn, 'SELECT id FROM transferia_snapshot_edges_20260920.extreme_keys WHERE id >= 0')
        good = values(conn, 'SELECT id FROM transferia_snapshot_edges_20260920.extreme_keys WHERE id < 0') + values(conn, 'SELECT id FROM transferia_snapshot_edges_20260920.extreme_keys WHERE id >= 0')
        assert len(bad) == 8 and len(set(bad)) == 7 and (len(good) == len(set(good)) == 7)
        return {'inclusive_both_rows': len(bad), 'half_open_rows': len(good), 'duplicated_boundary_key': 0}

def composite_collated_keys():
    with snapshot() as conn:
        truth = conn.execute('SELECT tenant,id FROM transferia_snapshot_edges_20260920.composite_keys ORDER BY tenant,id').fetchall()
        cuts = [truth[index] for index in (7, 19, 28)]
        parts = [conn.execute('SELECT tenant,id FROM transferia_snapshot_edges_20260920.composite_keys WHERE (tenant,id) < (%s,%s) ORDER BY tenant,id', cuts[0]).fetchall()]
        parts.extend((conn.execute('SELECT tenant,id FROM transferia_snapshot_edges_20260920.composite_keys WHERE (tenant,id) >= (%s,%s) AND (tenant,id) < (%s,%s) ORDER BY tenant,id', a + b).fetchall() for a, b in zip(cuts, cuts[1:])))
        parts.append(conn.execute('SELECT tenant,id FROM transferia_snapshot_edges_20260920.composite_keys WHERE (tenant,id) >= (%s,%s) ORDER BY tenant,id', cuts[-1]).fetchall())
        actual = [row for part in parts for row in part]
        assert actual == truth and len(set(actual)) == 40
        return {'rows': len(actual), 'partition_counts': [len(part) for part in parts], 'cuts_selected_in_server_collation': cuts, 'collation': 'C', 'non_ascii_and_empty_strings': True}

def partition_local_ctid():
    with snapshot() as conn:
        total, distinct_ctid, distinct_pair = conn.execute('SELECT count(*),count(DISTINCT ctid),count(DISTINCT (tableoid,ctid)) FROM transferia_snapshot_edges_20260920.parted').fetchone()
        parent_pages = pages(conn, 'parted')
        collected = []
        for leaf in ('parted_a', 'parted_b'):
            collected.extend(((leaf, row) for row in ctid_parts(conn, leaf)))
        assert total == distinct_pair == len(collected) == 20 and distinct_ctid < total and (parent_pages == 0)
        return {'rows': total, 'distinct_ctid_without_relation': distinct_ctid, 'distinct_tableoid_ctid': distinct_pair, 'parent_heap_pages': parent_pages, 'leaf_scan_rows': len(collected)}

def key_moves_snapshot():
    with snapshot() as coordinator:
        exported = scalar(coordinator, 'SELECT pg_export_snapshot()')
        truth = values(coordinator, 'SELECT logical_id FROM transferia_snapshot_edges_20260920.key_moves ORDER BY logical_id')
        lower = values(coordinator, 'SELECT logical_id FROM transferia_snapshot_edges_20260920.key_moves WHERE id < 50')
        with connect() as writer:
            writer.execute('BEGIN')
            writer.execute('UPDATE transferia_snapshot_edges_20260920.key_moves SET id=1001 WHERE id=1')
            writer.execute('UPDATE transferia_snapshot_edges_20260920.key_moves SET id=-99 WHERE id=99')
            writer.execute('COMMIT')
        with snapshot(exported) as reader:
            shared = lower + values(reader, 'SELECT logical_id FROM transferia_snapshot_edges_20260920.key_moves WHERE id >= 50')
        with connect() as reader:
            mixed = lower + values(reader, 'SELECT logical_id FROM transferia_snapshot_edges_20260920.key_moves WHERE id >= 50')
        counts = Counter(mixed)
        duplicated = sorted((key for key, count in counts.items() if count > 1))
        missing = sorted(set(truth) - set(mixed))
        assert sorted(shared) == truth and len(mixed) == len(truth) and (duplicated == [1]) and (missing == [99])
        return {'truth_rows': len(truth), 'shared_snapshot_rows': len(shared), 'mixed_snapshot_rows': len(mixed), 'mixed_duplicate_logical_ids': duplicated, 'mixed_missing_logical_ids': missing, 'row_count_alone_fails_to_detect_corruption': True}

def tid_moves_snapshot():
    with snapshot() as coordinator:
        exported = scalar(coordinator, 'SELECT pg_export_snapshot()')
        truth = values(coordinator, 'SELECT id FROM transferia_snapshot_edges_20260920.tid_moves ORDER BY id')
        boundary = pages(coordinator, 'tid_moves') // 2
        before = scalar(coordinator, 'SELECT ctid::text FROM transferia_snapshot_edges_20260920.tid_moves WHERE id=1')
        lower = values(coordinator, 'SELECT id FROM transferia_snapshot_edges_20260920.tid_moves WHERE ctid < %s::tid', (f'({boundary},0)',))
        with connect() as writer:
            after = scalar(writer, "UPDATE transferia_snapshot_edges_20260920.tid_moves SET payload=repeat('y',7000) WHERE id=1 RETURNING ctid::text")
        assert int(after[1:].split(',')[0]) >= boundary
        with snapshot(exported) as reader:
            shared = lower + values(reader, 'SELECT id FROM transferia_snapshot_edges_20260920.tid_moves WHERE ctid >= %s::tid', (f'({boundary},0)',))
        with connect() as reader:
            mixed = lower + values(reader, 'SELECT id FROM transferia_snapshot_edges_20260920.tid_moves WHERE ctid >= %s::tid', (f'({boundary},0)',))
        duplicated = sorted((key for key, count in Counter(mixed).items() if count > 1))
        assert sorted(shared) == truth and duplicated == [1] and (len(mixed) == len(truth) + 1)
        return {'ctid_before': before, 'ctid_after': after, 'boundary_block': boundary, 'truth_rows': len(truth), 'shared_snapshot_rows': len(shared), 'mixed_snapshot_rows': len(mixed), 'mixed_duplicate_ids': duplicated}

def stale_extent_before_snapshot():
    with connect() as conn:
        old_pages = pages(conn, 'growth')
        conn.execute("INSERT INTO transferia_snapshot_edges_20260920.growth SELECT i,repeat('y',1800) FROM generate_series(11,100) i")
    with snapshot() as conn:
        truth = scalar(conn, 'SELECT count(*) FROM transferia_snapshot_edges_20260920.growth')
        bounded = scalar(conn, 'SELECT count(*) FROM transferia_snapshot_edges_20260920.growth WHERE ctid < %s::tid', (f'({old_pages},0)',))
        tail = scalar(conn, 'SELECT count(*) FROM transferia_snapshot_edges_20260920.growth WHERE ctid >= %s::tid', (f'({old_pages},0)',))
        assert bounded < truth and bounded + tail == truth
        return {'size_sampled_before_new_snapshot_pages': old_pages, 'actual_pages': pages(conn, 'growth'), 'truth_rows': truth, 'old_upper_bound_rows': bounded, 'open_tail_recovered_rows': tail}

def expired_snapshot():
    with snapshot() as coordinator:
        exported = scalar(coordinator, 'SELECT pg_export_snapshot()')
    with connect() as conn:
        conn.execute('BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY')
        try:
            conn.execute(sql.SQL('SET TRANSACTION SNAPSHOT {}').format(sql.Literal(exported)))
        except psycopg.errors.UndefinedObject as exc:
            state = exc.sqlstate
        else:
            raise AssertionError('expired snapshot unexpectedly accepted')
        finally:
            conn.execute('ROLLBACK')
        return {'import_after_exporter_ends_sqlstate': state}

def held_table_lock_blocks_rewrite():
    with snapshot() as coordinator:
        coordinator.execute('LOCK TABLE transferia_snapshot_edges_20260920.single_row IN ACCESS SHARE MODE')
        with connect() as ddl:
            ddl.execute('BEGIN')
            ddl.execute("SET LOCAL lock_timeout='200ms'")
            try:
                ddl.execute('LOCK TABLE transferia_snapshot_edges_20260920.single_row IN ACCESS EXCLUSIVE MODE')
            except psycopg.errors.LockNotAvailable as exc:
                state = exc.sqlstate
            else:
                raise AssertionError('exclusive lock unexpectedly acquired')
            finally:
                ddl.execute('ROLLBACK')
        return {'exclusive_lock_while_coordinator_holds_access_share_sqlstate': state}

def plan_node_types(node):
    result = [node['Node Type']]
    for child in node.get('Plans', []):
        result.extend(plan_node_types(child))
    return result

def planner_predicate_shape():
    with connect() as conn:
        conn.execute('ANALYZE transferia_snapshot_edges_20260920.stale_pages')
    with snapshot() as conn:
        native = scalar(conn, "EXPLAIN (FORMAT JSON, ANALYZE, BUFFERS) SELECT * FROM transferia_snapshot_edges_20260920.stale_pages WHERE ctid >= '(2,0)'::tid AND ctid < '(4,0)'::tid")[0]
        extracted = scalar(conn, "EXPLAIN (FORMAT JSON, ANALYZE, BUFFERS) SELECT * FROM transferia_snapshot_edges_20260920.stale_pages WHERE split_part(trim(both '()' from ctid::text), ',', 1)::bigint >= 2 AND split_part(trim(both '()' from ctid::text), ',', 1)::bigint < 4")[0]
        native_types = plan_node_types(native['Plan'])
        extracted_types = plan_node_types(extracted['Plan'])
        assert 'Tid Range Scan' in native_types and 'Tid Range Scan' not in extracted_types
        return {'native_node_types': native_types, 'extracted_block_node_types': extracted_types, 'native_explain': native, 'extracted_explain': extracted}

def typed_server_ranges(table, pgtype):
    """Use server-produced textual literals only as lossless typed parameters.

    No Python ordering, timestamp conversion or floating-point arithmetic is
    involved; exact integer row identities prove coverage and multiplicity.
    """
    with snapshot() as conn:
        truth = conn.execute(sql.SQL('SELECT row_id,k::text AS boundary_text FROM {} AS t ORDER BY t.k').format(sql.Identifier(SCHEMA, table))).fetchall()
        cuts = [truth[i][1] for i in sorted(set((len(truth) // 4, len(truth) // 2, 3 * len(truth) // 4)))]
        base = sql.SQL('SELECT row_id FROM {} WHERE ').format(sql.Identifier(SCHEMA, table))
        cast = sql.SQL(pgtype)
        predicates = [(sql.SQL('k < %s::{} ORDER BY k').format(cast), (cuts[0],))]
        predicates += [(sql.SQL('k >= %s::{} AND k < %s::{} ORDER BY k').format(cast, cast), (a, b)) for a, b in zip(cuts, cuts[1:])]
        predicates.append((sql.SQL('k >= %s::{} ORDER BY k').format(cast), (cuts[-1],)))
        chunks = [values(conn, base + pred, params) for pred, params in predicates]
        actual = [row for chunk in chunks for row in chunk]
        assert actual == [row[0] for row in truth] and len(set(actual)) == len(truth)
        return {'pg_type': pgtype, 'rows': len(truth), 'server_order_values': [row[1] for row in truth], 'typed_boundaries': cuts, 'partition_counts': [len(chunk) for chunk in chunks], 'exact_identity_sequence': True}

def fractional_numeric():
    observed = typed_server_ranges('decimal_keys', 'numeric')
    exact = observed['server_order_values']
    approximate = [float(value) for value in exact]
    assert len(set(approximate)) < len(exact)
    observed['distinct_after_unsafe_float_conversion'] = len(set(approximate))
    observed['distinct_exact_numeric'] = len(exact)
    return observed

def float_special_values():
    observed = typed_server_ranges('float_keys', 'double precision')
    with connect() as conn:
        try:
            conn.execute("INSERT INTO transferia_snapshot_edges_20260920.float_keys VALUES(100,'+0')")
        except psycopg.errors.UniqueViolation as exc:
            state = exc.sqlstate
        else:
            raise AssertionError('positive and negative zero unexpectedly distinct PKs')
        nan_eq, nan_largest = conn.execute("SELECT 'NaN'::float8='NaN'::float8,'NaN'::float8>'Infinity'::float8").fetchone()
        assert nan_eq and nan_largest
        observed.update({'signed_zero_same_pk_sqlstate': state, 'postgres_nan_equals_nan': nan_eq, 'postgres_nan_larger_than_infinity': nan_largest})
    return observed

def default_locale_text():
    observed = typed_server_ranges('locale_keys', 'text')
    with connect() as conn:
        info=conn.execute("SELECT datcollate,to_jsonb(d)->>'datlocprovider',coalesce(to_jsonb(d)->>'datlocale',to_jsonb(d)->>'daticulocale'),to_jsonb(d)->>'datcollversion' FROM pg_database d WHERE datname=current_database()").fetchone()
        observed.update({'database_datcollate':info[0],'database_locale_provider':info[1],'database_provider_locale':info[2],'database_collation_version':info[3]})
    return observed

def heterogeneous_composite():
    with snapshot() as conn:
        truth = conn.execute('SELECT row_id,tenant,sequence::text AS sequence_text,happened::text AS happened_text FROM transferia_snapshot_edges_20260920.mixed_composite AS t ORDER BY t.tenant,t.sequence,t.happened').fetchall()
        cuts = [tuple(truth[i][1:]) for i in (7, 14, 22)]
        row_expr = '(tenant,sequence,happened)'
        bound_expr = '(%s::text,%s::numeric,%s::timestamptz)'
        ordered = ' ORDER BY tenant,sequence,happened'
        query = 'SELECT row_id FROM transferia_snapshot_edges_20260920.mixed_composite WHERE '
        parts = [values(conn, query + row_expr + ' < ' + bound_expr + ordered, cuts[0])]
        parts.extend((values(conn, query + row_expr + ' >= ' + bound_expr + ' AND ' + row_expr + ' < ' + bound_expr + ordered, a + b) for a, b in zip(cuts, cuts[1:])))
        parts.append(values(conn, query + row_expr + ' >= ' + bound_expr + ordered, cuts[-1]))
        actual = [value for part in parts for value in part]
        assert actual == [row[0] for row in truth] and len(set(actual)) == 30
        return {'types': ['text COLLATE C', 'numeric', 'timestamptz'], 'rows': 30, 'partition_counts': [len(part) for part in parts], 'typed_boundaries': cuts, 'exact_identity_sequence': True}

def nullable_composite_patterns():
    with snapshot() as conn:
        truth = values(conn, 'SELECT id FROM transferia_snapshot_edges_20260920.null_patterns ORDER BY id')
        naive = values(conn, 'SELECT id FROM transferia_snapshot_edges_20260920.null_patterns WHERE (a,b,id) > (-1,-1,0)')
        actual, counts = ([], {})
        for a_null in (False, True):
            for b_null in (False, True):
                condition = f"a IS {('NULL' if a_null else 'NOT NULL')} AND b IS {('NULL' if b_null else 'NOT NULL')}"
                columns = ([] if a_null else ['a']) + ([] if b_null else ['b']) + ['id']
                keys = ','.join(columns)
                last, part = (None, [])
                while True:
                    query = f'SELECT id,{keys} FROM transferia_snapshot_edges_20260920.null_patterns WHERE {condition}'
                    params = None
                    if last is not None:
                        query += f" AND ({keys}) > ({','.join(['%s'] * len(columns))})"
                        params = last
                    rows = conn.execute(query + f' ORDER BY {keys} LIMIT 3', params).fetchall()
                    if not rows:
                        break
                    part.extend((row[0] for row in rows))
                    last = tuple(rows[-1][1:])
                actual.extend(part)
                counts[condition] = len(part)
        assert len(naive) < len(truth) and sorted(actual) == truth and (len(set(actual)) == len(truth))
        return {'rows': len(truth), 'naive_tuple_comparison_rows': len(naive), 'null_pattern_keyset_counts': counts, 'exact_identity_set': True, 'pk_tie_breaker': 'id'}

def entirely_null_split_column():
    with snapshot() as conn:
        minimum, maximum = conn.execute('SELECT min(k),max(k) FROM transferia_snapshot_edges_20260920.all_nulls').fetchone()
        truth = values(conn, 'SELECT id FROM transferia_snapshot_edges_20260920.all_nulls ORDER BY id')
        actual = values(conn, 'SELECT id FROM transferia_snapshot_edges_20260920.all_nulls WHERE k IS NULL ORDER BY id')
        assert minimum is maximum is None and actual == truth and (len(actual) == 11)
        return {'rows': 11, 'minimum': minimum, 'maximum': maximum, 'explicit_null_task_rows': len(actual), 'exact_identity_set': True}

def absent_and_disabled_statistics():
    with connect() as conn:
        initial = scalar(conn, "SELECT count(*) FROM pg_stats WHERE schemaname=%s AND tablename='stats_missing' AND attname='k'", (SCHEMA,))
        conn.execute('ALTER TABLE transferia_snapshot_edges_20260920.stats_missing ALTER COLUMN k SET STATISTICS 0')
        conn.execute('ANALYZE transferia_snapshot_edges_20260920.stats_missing')
        hist = conn.execute("SELECT histogram_bounds::text,n_distinct FROM pg_stats WHERE schemaname=%s AND tablename='stats_missing' AND attname='k'", (SCHEMA,)).fetchone()
        truth = values(conn, 'SELECT id FROM transferia_snapshot_edges_20260920.stats_missing ORDER BY id')
        actual = values(conn, 'SELECT id FROM transferia_snapshot_edges_20260920.stats_missing WHERE k < 500') + values(conn, 'SELECT id FROM transferia_snapshot_edges_20260920.stats_missing WHERE k >= 500')
        assert initial == 0 and (hist is None or hist[0] is None) and (sorted(actual) == truth)
        return {'rows': len(truth), 'initial_pg_stats_rows': initial, 'statistics_target': 0, 'histogram_after_analyze': None if hist is None else hist[0], 'exact_server_ranges_without_stats': True}

def stale_histogram_after_writes():
    with connect() as conn:
        conn.execute('ALTER TABLE transferia_snapshot_edges_20260920.stats_stale ALTER COLUMN k SET STATISTICS 100')
        conn.execute('ANALYZE transferia_snapshot_edges_20260920.stats_stale')
        hist = scalar(conn, "SELECT histogram_bounds::text FROM pg_stats WHERE schemaname=%s AND tablename='stats_stale' AND attname='k'", (SCHEMA,))
        bounds = [int(value) for value in hist.strip('{}').split(',')]
        cuts = [bounds[len(bounds) * i // 4] for i in (1, 2, 3)]
        conn.execute('UPDATE transferia_snapshot_edges_20260920.stats_stale SET k=k+1000000 WHERE k>900')
        conn.execute('INSERT INTO transferia_snapshot_edges_20260920.stats_stale SELECT i,i+1000000 FROM generate_series(1001,1500) i')
        after = scalar(conn, "SELECT histogram_bounds::text FROM pg_stats WHERE schemaname=%s AND tablename='stats_stale' AND attname='k'", (SCHEMA,))
        truth = values(conn, 'SELECT row_id FROM transferia_snapshot_edges_20260920.stats_stale ORDER BY row_id')
        bounded = scalar(conn, 'SELECT count(*) FROM transferia_snapshot_edges_20260920.stats_stale WHERE k BETWEEN %s AND %s', (bounds[0], bounds[-1]))
        parts = [values(conn, 'SELECT row_id FROM transferia_snapshot_edges_20260920.stats_stale WHERE k < %s', (cuts[0],))]
        parts.extend((values(conn, 'SELECT row_id FROM transferia_snapshot_edges_20260920.stats_stale WHERE k >= %s AND k < %s', (a, b)) for a, b in zip(cuts, cuts[1:])))
        parts.append(values(conn, 'SELECT row_id FROM transferia_snapshot_edges_20260920.stats_stale WHERE k >= %s', (cuts[-1],)))
        actual = [value for part in parts for value in part]
        estimated = scalar(conn, "SELECT reltuples FROM pg_class WHERE oid='transferia_snapshot_edges_20260920.stats_stale'::regclass")
        assert hist == after and bounded == 900 and (len(truth) == 1500) and (sorted(actual) == truth)
        return {'rows': len(truth), 'stale_catalog_rows': estimated, 'stale_histogram_extrema': [bounds[0], bounds[-1]], 'bounded_by_stale_histogram_rows': bounded, 'open_tail_partition_counts': [len(part) for part in parts], 'exact_identity_set': True}

def mcv_duplicate_quantiles():
    with connect() as conn:
        conn.execute('ALTER TABLE transferia_snapshot_edges_20260920.stats_mcv ALTER COLUMN k SET STATISTICS 100')
        conn.execute('ANALYZE transferia_snapshot_edges_20260920.stats_mcv')
        cuts = scalar(conn, 'SELECT percentile_disc(ARRAY[0.25,0.5,0.75]::float8[]) WITHIN GROUP(ORDER BY k) FROM transferia_snapshot_edges_20260920.stats_mcv')
        ndistinct, mcv, freq = conn.execute("SELECT n_distinct,most_common_vals::text,most_common_freqs FROM pg_stats WHERE schemaname=%s AND tablename='stats_mcv' AND attname='k'", (SCHEMA,)).fetchone()
        truth = values(conn, 'SELECT id FROM transferia_snapshot_edges_20260920.stats_mcv ORDER BY id')
        unique = sorted(set(cuts))
        assert unique == [0]
        parts = [values(conn, 'SELECT id FROM transferia_snapshot_edges_20260920.stats_mcv WHERE k < %s', (unique[0],)), values(conn, 'SELECT id FROM transferia_snapshot_edges_20260920.stats_mcv WHERE k >= %s', (unique[0],))]
        actual = [value for part in parts for value in part]
        assert sorted(actual) == truth and len(set(actual)) == 10000
        return {'rows': 10000, 'requested_quantile_cuts': cuts, 'unique_cuts': unique, 'partition_counts': [len(part) for part in parts], 'n_distinct_statistic': ndistinct, 'most_common_values': mcv, 'most_common_frequencies': freq, 'exact_identity_set': True, 'equal_rows_by_this_nonunique_split_field_impossible': True}

def empty_sample_coverage():
    with snapshot() as conn:
        cuts = scalar(conn, 'SELECT percentile_disc(ARRAY[0.25,0.5,0.75]::float8[]) WITHIN GROUP(ORDER BY id) FROM transferia_snapshot_edges_20260920.single_row TABLESAMPLE SYSTEM(0)')
        truth = values(conn, 'SELECT id FROM transferia_snapshot_edges_20260920.single_row')
        actual = values(conn, 'SELECT id FROM transferia_snapshot_edges_20260920.single_row WHERE TRUE') if cuts is None else []
        assert cuts is None and actual == truth == [1]
        return {'forced_empty_sample_percent': 0, 'sample_cuts': cuts, 'fallback_predicate': 'TRUE', 'rows': len(actual), 'exact_identity_set': True}

def imported_snapshot_reexport():
    with connect() as original:
        original.execute('BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY')
        old_id = scalar(original, 'SELECT pg_export_snapshot()')
        with snapshot(old_id) as keeper:
            before = values(keeper, 'SELECT id FROM transferia_snapshot_edges_20260920.single_row ORDER BY id')
            original.execute('ROLLBACK')
            with connect() as writer:
                writer.execute('INSERT INTO transferia_snapshot_edges_20260920.single_row VALUES(2)')
                current = values(writer, 'SELECT id FROM transferia_snapshot_edges_20260920.single_row ORDER BY id')
            new_id = scalar(keeper, 'SELECT pg_export_snapshot()')
            with snapshot(new_id) as successor:
                adopted = values(successor, 'SELECT id FROM transferia_snapshot_edges_20260920.single_row ORDER BY id')
            assert old_id != new_id and before == adopted == [1] and (current == [1, 2])
            return {'original_exporter_ended': True, 'snapshot_identifier_changed': True, 'original_snapshot_rows': before, 'newly_committed_rows_visible_to_fresh_reader': current, 'reexported_snapshot_rows': adopted, 'exact_identity_set_preserved': True}

def statistics_diagnostics():
    """Read-only troubleshooting for managed-server statistics visibility."""
    with connect() as conn:
        return {'default_statistics_target': scalar(conn, 'SHOW default_statistics_target'), 'stats_rows': conn.execute("SELECT schemaname,tablename,attname,n_distinct,histogram_bounds::text,most_common_vals::text FROM pg_stats WHERE tablename IN ('stats_stale','stats_mcv')").fetchall(), 'tables': conn.execute("SELECT n.nspname,c.relname,c.reltuples,a.attname,a.attstattarget FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace JOIN pg_attribute a ON a.attrelid=c.oid AND a.attname='k' WHERE c.relname IN ('stats_stale','stats_mcv')").fetchall()}


def wide_key_omitted_from_statistics():
    with connect() as conn:
        conn.execute('ALTER TABLE transferia_snapshot_edges_20260920.wide_keys ALTER COLUMN k SET STATISTICS 100')
        conn.execute('ANALYZE transferia_snapshot_edges_20260920.wide_keys')
        hist,mcv,width,distinct=conn.execute("SELECT histogram_bounds::text,most_common_vals::text,avg_width,n_distinct FROM pg_stats WHERE schemaname=%s AND tablename='wide_keys' AND attname='k'",(SCHEMA,)).fetchone()
        lengths=conn.execute('SELECT min(octet_length(k)),max(octet_length(k)) FROM transferia_snapshot_edges_20260920.wide_keys').fetchone()
        assert lengths[0]>1024 and hist is None and mcv is None
    observed=typed_server_ranges('wide_keys','text')
    observed.pop('server_order_values')
    observed['boundary_bytes']=[len(value.encode()) for value in observed.pop('typed_boundaries')]
    observed.update({'minimum_key_bytes':lengths[0],'maximum_key_bytes':lengths[1],'histogram':hist,'most_common_values':mcv,'average_width_statistic':width,'n_distinct_statistic':distinct})
    return observed


def forced_rls_statistics_and_ranges():
    with connect() as conn:
        superuser,bypass=conn.execute('SELECT rolsuper,rolbypassrls FROM pg_roles WHERE rolname=current_user').fetchone()
        assert not superuser and not bypass, 'RLS experiment requires a role that does not bypass RLS'
        conn.execute('ALTER TABLE transferia_snapshot_edges_20260920.rls_keys ALTER COLUMN k SET STATISTICS 100')
        conn.execute('ANALYZE transferia_snapshot_edges_20260920.rls_keys')
        before=scalar(conn,"SELECT count(*) FROM pg_stats WHERE schemaname=%s AND tablename='rls_keys'",(SCHEMA,))
        conn.execute('ALTER TABLE transferia_snapshot_edges_20260920.rls_keys ENABLE ROW LEVEL SECURITY')
        conn.execute('ALTER TABLE transferia_snapshot_edges_20260920.rls_keys FORCE ROW LEVEL SECURITY')
        conn.execute('CREATE POLICY even_rows ON transferia_snapshot_edges_20260920.rls_keys USING (id % 2 = 0)')
        after=scalar(conn,"SELECT count(*) FROM pg_stats WHERE schemaname=%s AND tablename='rls_keys'",(SCHEMA,))
        active=scalar(conn,"SELECT row_security_active('transferia_snapshot_edges_20260920.rls_keys'::regclass)")
    with snapshot() as conn:
        truth=values(conn,'SELECT id FROM transferia_snapshot_edges_20260920.rls_keys ORDER BY id')
        physical=ctid_parts(conn,'rls_keys',4)
        assert truth==list(range(2,101,2)) and sorted(physical)==truth
    typed=typed_server_ranges('rls_keys','integer')
    assert active and before>0 and after==0 and typed['rows']==50
    return {'stored_rows_before_rls':100,'authorized_rows':50,'statistics_rows_before_rls':before,'statistics_rows_with_force_rls':after,'row_security_active':active,'ctid_exact_authorized_id_set':True,'typed_range_exact_authorized_id_set':typed['exact_identity_sequence'],'typed_partition_counts':typed['partition_counts']}


def enum_declared_order():
    observed=typed_server_ranges('enum_keys',SCHEMA+'.edge_priority')
    assert observed['server_order_values']==['z_low','a_middle','m_high']
    observed['lexical_order_differs']=observed['server_order_values']!=sorted(observed['server_order_values'])
    assert observed['lexical_order_differs']
    return observed


def partition_topology_lock_protocol():
    with snapshot() as reader:
        reader.execute('LOCK TABLE ONLY transferia_snapshot_edges_20260920.parted IN SHARE UPDATE EXCLUSIVE MODE')
    with connect() as coordinator:
        coordinator.execute('BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY')
        try:
            coordinator.execute('LOCK TABLE ONLY transferia_snapshot_edges_20260920.parted IN SHARE UPDATE EXCLUSIVE MODE')
            coordinator.execute('LOCK TABLE ONLY transferia_snapshot_edges_20260920.parted_a,ONLY transferia_snapshot_edges_20260920.parted_b IN ACCESS SHARE MODE')
            exported=scalar(coordinator,'SELECT pg_export_snapshot()')
            truth=coordinator.execute('SELECT part,id FROM transferia_snapshot_edges_20260920.parted ORDER BY part,id').fetchall()
            with connect() as writer:
                writer.execute('INSERT INTO transferia_snapshot_edges_20260920.parted VALUES(1,99)')
                current=scalar(writer,'SELECT count(*) FROM transferia_snapshot_edges_20260920.parted')
            blocked={}
            commands={
                'actual_attach_partition':'ALTER TABLE transferia_snapshot_edges_20260920.parted ATTACH PARTITION transferia_snapshot_edges_20260920.attach_candidate FOR VALUES IN (3)',
                'same_parent_lock_as_detach_concurrently':'LOCK TABLE ONLY transferia_snapshot_edges_20260920.parted IN SHARE UPDATE EXCLUSIVE MODE NOWAIT',
                'actual_analyze_parent':'ANALYZE transferia_snapshot_edges_20260920.parted',
            }
            for label,query in commands.items():
                with connect() as ddl:
                    ddl.execute('BEGIN')
                    ddl.execute("SET LOCAL lock_timeout='200ms'")
                    try:
                        ddl.execute(query)
                    except psycopg.errors.LockNotAvailable as exc:
                        blocked[label]=exc.sqlstate
                    else:
                        raise AssertionError('topology or maintenance operation unexpectedly acquired conflicting lock: '+label)
                    finally:
                        ddl.execute('ROLLBACK')
            with snapshot(exported) as reader:
                actual=reader.execute('SELECT part,id FROM ONLY transferia_snapshot_edges_20260920.parted_a UNION ALL SELECT part,id FROM ONLY transferia_snapshot_edges_20260920.parted_b ORDER BY part,id').fetchall()
            assert len(truth)==20 and current==21 and actual==truth and len(blocked)==3
            return {'coordinator_transaction':'REPEATABLE READ READ ONLY','readonly_sue_acquired':True,'lock_order':['parent SHARE UPDATE EXCLUSIVE','leaves ACCESS SHARE','export snapshot'],'new_insert_allowed':True,'snapshot_rows':len(truth),'fresh_reader_rows':current,'exact_leaf_identity_set':True,'blocked_sqlstates':blocked,'detach_concurrently_statement_itself_executed':False}
        finally:
            coordinator.execute('ROLLBACK')
EXPERIMENTS = [('empty_and_fewer_rows_than_workers', empty_and_tiny), ('stale_pg_class_relpages', stale_catalog_pages), ('empty_and_out_of_heap_ctid_bounds', bounds_outside_heap), ('bigint_extremes_sparse_ranges', integer_overflow_and_tails), ('null_split_field_and_duplicate_keyset', null_and_duplicate_values), ('half_open_boundary_coverage', inclusive_boundary_overlap), ('composite_text_pk_server_collation', composite_collated_keys), ('partition_ctid_scope', partition_local_ctid), ('moving_keys_same_snapshot_vs_mixed', key_moves_snapshot), ('moving_ctid_same_snapshot_vs_mixed', tid_moves_snapshot), ('extent_captured_before_snapshot', stale_extent_before_snapshot), ('exported_snapshot_lifetime', expired_snapshot), ('coordinator_lock_blocks_rewrite', held_table_lock_blocks_rewrite), ('native_tid_predicate_vs_extracted_block', planner_predicate_shape), ('uuid_server_order_ranges', lambda: typed_server_ranges('uuid_keys', 'uuid')), ('bytea_server_order_ranges', lambda: typed_server_ranges('binary_keys', 'bytea')), ('date_bc_infinity_server_ranges', lambda: typed_server_ranges('date_keys', 'date')), ('timestamptz_dst_microseconds_infinity', lambda: typed_server_ranges('timestamp_keys', 'timestamptz')), ('fractional_numeric_without_float_rounding', fractional_numeric), ('float_nan_infinity_signed_zero', float_special_values), ('default_database_text_collation', default_locale_text), ('heterogeneous_composite_pk', heterogeneous_composite), ('nullable_composite_patterns_and_ties', nullable_composite_patterns), ('all_null_split_column', entirely_null_split_column), ('missing_and_disabled_column_statistics', absent_and_disabled_statistics), ('stale_histogram_after_key_updates_and_inserts', stale_histogram_after_writes), ('mcv_skew_duplicate_quantile_boundaries', mcv_duplicate_quantiles), ('empty_tablesample_preserves_coverage', empty_sample_coverage), ('live_importer_reexports_after_original_exporter_ends', imported_snapshot_reexport)]


EXPERIMENTS.extend([
    ('wide_text_key_omitted_from_histogram', wide_key_omitted_from_statistics),
    ('forced_rls_hides_stats_preserves_authorized_ranges', forced_rls_statistics_and_ranges),
    ('array_elements_nulls_dimensions_server_order', lambda: typed_server_ranges('array_keys','integer[]')),
    ('enum_declared_order_not_lexical_order', enum_declared_order),
    ('partition_topology_sue_allows_dml_blocks_attach', partition_topology_lock_protocol),
])

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    report = {'schema': SCHEMA, 'started_unix': time.time(), 'experiments': []}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with connect() as conn:
        report['postgres_version'] = scalar(conn, 'SELECT version()')
        report['server_version_num'] = scalar(conn, 'SHOW server_version_num')
        setup(conn)
        report['fixture_tables'] = values(conn,"SELECT c.relname FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname=%s AND c.relkind IN ('r','p') ORDER BY c.relname",(SCHEMA,))
        assert report['fixture_tables'] == sorted(TABLES + ('parted_a','parted_b')), 'fixture schema isolation failed'
    for name, function in EXPERIMENTS:
        started = time.perf_counter()
        result = {'name': name}
        try:
            result.update({'status': 'passed', 'observations': function()})
        except Exception as exc:
            result.update({'status': 'failed', 'exception_type': type(exc).__name__, 'sqlstate': getattr(exc, 'sqlstate', None)})
        result['seconds'] = time.perf_counter() - started
        report['experiments'].append(result)
        args.output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
        print(json.dumps({key: value for key, value in result.items() if key != 'observations'}), flush=True)
    report['finished_unix'] = time.time()
    report['passed'] = sum((item['status'] == 'passed' for item in report['experiments']))
    report['failed'] = sum((item['status'] == 'failed' for item in report['experiments']))
    args.output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
    return bool(report['failed'])
if __name__ == '__main__':
    raise SystemExit(main())
