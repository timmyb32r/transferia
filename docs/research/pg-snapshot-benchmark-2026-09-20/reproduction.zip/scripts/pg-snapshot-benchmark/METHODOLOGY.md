# Measurement contract and review

Only the standalone **Rust RELEASE** executable is a performance measurement
source. It rejects debug builds and records `consumer=rust_release`,
`release_build=true`, `debug_assertions=false`, and 16 Tokio worker threads.
Python/C exploratory runs are excluded from the final performance comparison.

## What is measured

The source emits every column of every selected row through PostgreSQL binary
COPY. Rust parses framing and field lengths, counts complete rows and bytes,
and discards field payloads. It does not decode Arrow values, perform
transformations, send records through Transferia's pipeline, or write a sink.
The result compares snapshot partition planning and source reading; it is not a
measurement of complete Transferia delivery throughput.

All strategies use the same column projection, TLS settings, snapshot and
connection implementation. COPY byte counts include its headers/trailers but
exclude TCP/TLS framing. Each additional chunk has its own COPY framing and
SQL prepare/bind/startup work; these costs remain in scan time. This matters
when comparing one large query with many short queued queries.

| Metric | Includes | Excludes |
| --- | --- | --- |
| `planning_seconds` | SQL discovery specific to the chosen strategy and predicate construction | Fixture validation, reader connection setup |
| `scan_seconds` | Dispatch, source scans, transfer, Rust framing parser, reader scheduling | Result-file writes, EXPLAIN, destination work |
| `total_seconds` | Planning plus scan | The explicitly separate setup and reference-validation costs |
| `worker_startup_seconds` | Opening/importing the snapshot into this run's reader connections | Planning and reads |
| `client_cpu_seconds` | Whole-process CPU during the timed scan, including TLS, parser and Tokio work | PostgreSQL CPU, setup, planning |

Per-chunk CPU is null: async tasks can move between threads, so attributing a
thread's CPU clock to one task would be misleading. Per-chunk wall duration,
rows, bytes and first-data latency are retained.

## Correctness and isolation

One coordinator takes an ACCESS SHARE lock, exports a repeatable-read snapshot,
and keeps it alive for every run on that table. Each reader imports the snapshot
before reading. This keeps a common visibility boundary and blocks DDL that
would invalidate physical row locations. Scans use `ONLY` and explicitly
require the heap table access method; inherited/partitioned parents are rejected.

Each fixture has a primary key and a unique, non-null, integral selected split
column. The harness validates these properties once under the same snapshot.
That validation includes full count/distinct scans and can warm indexes. It is
benchmark correctness preflight, not a proposed requirement for a production
split planner. Mixed, nullable and nonunique keys need separate strategies and
are not silently coerced into this performance matrix.

Integer bounds use checked i128 arithmetic. Exact selected numeric values are
parsed without floating-point conversion. Keyset queries cast results to text
under a distinct output alias, so their `ORDER BY` still uses the source's
numeric ordering. Every range plan keeps unbounded outer tails. Stats and
sampling only suggest boundaries; their stale estimates cannot create a hole
in coverage. CTID bounds use actual heap size instead of catalog estimates.

The binary COPY parser validates signature, lengths, row framing and trailer.
Six RELEASE unit tests cover NULL/empty fields, empty streams, every split point
of a representative stream, small blocks, malformed/truncated streams, exact
large integer conversion and duplicate cuts. Each measured run checks the exact
number of complete COPY rows against the snapshot's reference count. A count
match alone does not prove set equality; separate small edge fixtures must
compare row identities and test the interval contracts.

## Comparability and interpretation

- Strategy, reader count and repetition order are shuffled deterministically.
  Randomization reduces ordering bias; it does not make the server isolated.
- Server parallel query and JIT are disabled by default. Reader count controls
  database concurrency, while the client runtime always has 16 workers.
- No cache eviction is performed. Reference validation may warm indexes and
  earlier runs may warm heap pages. Results are mixed/warm-cache observations,
  not cold-disk throughput.
- Equal ranges use value distance; exact quantiles use actual selected values;
  sampled quantiles use heap block samples. None is inherently byte-balanced.
- `stats` uses `pg_stats.histogram_bounds`. It excludes most-common values and
  does not prove balanced work. Missing/empty histograms explicitly yield one
  unrestricted chunk. Stale statistics affect efficiency, not range coverage.
- `ctid_queue`, `stats`, `sample` and `keyset` use a shared queue with a default
  target of eight chunks per reader. This is work sharing, not adaptive online
  splitting. Keyset boundary discovery is completed before COPY begins.
- Modulo/hash predicates may require a full scan per reader. Parallel speedup
  alone cannot show that source work decreased; inspect executor plans and
  buffer counts alongside wall time.
- `--explain-analyze` executes extra source scans outside reported times. Run it
  separately from the primary matrix when preserving cache conditions matters.
- Tiny scans can be dominated by query startup, TLS, scheduling and network
  jitter. Compare repeated medians/ranges and avoid interpreting small percentage
  differences as a stable winner.

Read-only review found no remaining blocker in the measured integral-key plans
after the exact-boundary, heap-method and keyset-ordering fixes. Runtime SQL and
TLS smoke verification is performed by the coordinating task before the matrix.
No conclusion about arbitrary key types, restart durability, sink throughput or
global production optimality follows from this experiment alone.

## Additional source checks: lock ordering and COPY completion

PostgreSQL 17 explicitly exempts transaction-control, LOCK and SET commands
from taking a transaction snapshot in `PlannedStmtRequiresSnapshot`; their
parse-analysis path does not request one either. Therefore the benchmark's
`BEGIN REPEATABLE READ; SET LOCAL ...; LOCK TABLE ...; SELECT pg_export_snapshot()`
sequence acquires the ordinary heap lock before the first transaction MVCC
snapshot, provided no earlier SELECT is inserted. Catalog lookups performed to
resolve the lock target are not a reason to claim that this transaction snapshot
was already frozen. [PG17 pquery.c](https://github.com/postgres/postgres/blob/REL_17_STABLE/src/backend/tcop/pquery.c#L1623),
[PG17 analyze.c](https://github.com/postgres/postgres/blob/REL_17_STABLE/src/backend/parser/analyze.c#L417).

`tokio-postgres` 0.7.18 ends `CopyOutStream` on protocol `CopyDone`. PostgreSQL
17 sends the binary trailer and `CopyDone` before the final executor cleanup
and command-completion message. Consequently this benchmark measures complete
payload drainage, not a checked post-query/transaction completion barrier.
Data-stream errors and missing trailers fail the scan; a hypothetical error
after CopyDone is outside the stream's completion guarantee. This does not
provide evidence that the successful ordinary-heap runs lost data or should be
discarded. A production durable-delivery protocol must additionally check final
command status, or a suitable same-transaction success barrier, before committing
the sink. Successful ROLLBACK is not such a barrier.
[PG17 COPY TO](https://github.com/postgres/postgres/blob/REL_17_STABLE/src/backend/commands/copyto.c#L828),
[PG17 COPY cleanup order](https://github.com/postgres/postgres/blob/REL_17_STABLE/src/backend/commands/copy.c#L330).
