-- Separate byte-skew fixture derived from the real Transferia numeric load.
-- 200,000 rows: 198,000 x 32-byte payload, last 2,000 x 65,536-byte payload.
-- Payload bytes = 137,408,000 (~131.04 MiB), before numeric columns/COPY framing.
-- Wide rows form a contiguous key/physical region, not an evenly mixed sample.
-- EXTERNAL storage forces out-of-line uncompressed text for the large values.
-- Original source remains intact; repeat() explicitly adds synthetic payload.
\set ON_ERROR_STOP on
\set bench_schema public
\timing on
SET search_path TO :"bench_schema", pg_catalog;

BEGIN;
LOCK TABLE pgsnap_numeric IN SHARE MODE;
DO $body$
DECLARE n bigint;
BEGIN
    SELECT count(*) INTO n FROM pgsnap_numeric WHERE column_1 >= 0 AND column_1 < 200000;
    IF n <> 200000 THEN
        RAISE EXCEPTION 'width skew fixture requires generator rows with keys [0,200000)';
    END IF;
END
$body$;
CREATE TABLE pgsnap_numeric_width_skew (LIKE pgsnap_numeric INCLUDING ALL);
ALTER TABLE pgsnap_numeric_width_skew ADD COLUMN payload text NOT NULL;
ALTER TABLE pgsnap_numeric_width_skew ALTER COLUMN payload SET STORAGE EXTERNAL;
INSERT INTO pgsnap_numeric_width_skew
SELECT src.*, CASE WHEN column_1 >= 198000 THEN repeat('w',65536) ELSE repeat('n',32) END
FROM pgsnap_numeric AS src
WHERE column_1 >= 0 AND column_1 < 200000
ORDER BY column_1;
COMMIT;
ANALYZE pgsnap_numeric_width_skew;

-- These checks fail explicitly if the requested fixture shape did not materialize.
DO $body$
DECLARE n bigint; wide bigint; payload_bytes bigint; storage "char";
BEGIN
    SELECT count(*),count(*) FILTER (WHERE octet_length(payload)=65536),sum(octet_length(payload))
      INTO n,wide,payload_bytes FROM pgsnap_numeric_width_skew;
    SELECT attstorage INTO storage FROM pg_attribute
      WHERE attrelid='pgsnap_numeric_width_skew'::regclass AND attname='payload';
    IF n <> 200000 OR wide <> 2000 OR payload_bytes <> 137408000 OR storage <> 'e' THEN
        RAISE EXCEPTION 'width skew fixture shape/storage mismatch';
    END IF;
    IF pg_total_relation_size('pgsnap_numeric_width_skew') > 1073741824 THEN
        RAISE EXCEPTION 'width skew fixture unexpectedly exceeds 1 GiB';
    END IF;
END
$body$;

SELECT count(*) AS rows,
       count(*) FILTER (WHERE octet_length(payload)=65536) AS wide_rows,
       sum(octet_length(payload)) AS text_payload_bytes,
       pg_relation_size('pgsnap_numeric_width_skew') AS heap_bytes,
       pg_indexes_size('pgsnap_numeric_width_skew') AS index_bytes,
       pg_total_relation_size('pgsnap_numeric_width_skew') AS total_bytes
FROM pgsnap_numeric_width_skew;

SELECT pg_relation_size(reltoastrelid) AS toast_heap_bytes,
       pg_total_relation_size(reltoastrelid) AS toast_total_bytes
FROM pg_class WHERE oid='pgsnap_numeric_width_skew'::regclass;

-- Exact payload distribution in eight equal key ranges, excluding tuple framing.
SELECT floor(column_1 / 25000)::integer AS part,
       count(*) AS rows,sum(octet_length(payload)) AS text_payload_bytes
FROM pgsnap_numeric_width_skew
GROUP BY floor(column_1/25000)
ORDER BY part;
