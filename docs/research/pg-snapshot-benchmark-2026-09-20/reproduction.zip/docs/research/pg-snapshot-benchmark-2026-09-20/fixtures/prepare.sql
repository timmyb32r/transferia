-- Execute with psql after all three finite Transferia loads completed.
-- psql -v ON_ERROR_STOP=1 -f prepare.sql
-- Defaults to public; replace this one value if the loads used another schema.
\set bench_schema public
\set ON_ERROR_STOP on
\timing on
SET search_path TO :"bench_schema", pg_catalog;

-- No duplicate index on ClickBench: WatchID already leads its composite PK.
-- This index is explicitly part of fixture preparation, not benchmark timing.
CREATE INDEX pgsnap_transfer_logs_offset_idx
    ON pgsnap_transfer_logs (_system_offset);

ANALYZE pgsnap_numeric;
ANALYZE pgsnap_transfer_logs;
ANALYZE pgsnap_clickbench;

-- Keep the original generator fixture intact. Derived fixture: same row payload
-- with a deliberately remapped PK, 90% of rows in the first ~1% of key space.
-- For a source with N rows numbered 0..N-1 and N divisible by 10:
--   cutoff = 9N/10
--   key = old key,                                         old key < cutoff
--   key = cutoff + (old key - cutoff + 1) * 891,             otherwise
-- Thus max(new key) = 90N and cutoff/max(new key) = 1%.
-- The mapping is injective, integer-valued, and stays below numeric(20,0) for
-- the actual benchmark fixture sizes. Lower and upper groups do not overlap.
-- Intentionally fails if table/index already exists; does not overwrite data.
BEGIN;
LOCK TABLE pgsnap_numeric IN SHARE MODE;
DO $block$
DECLARE
    row_count bigint;
    min_key numeric;
    max_key numeric;
BEGIN
    SELECT count(*), min(column_1), max(column_1)
      INTO row_count, min_key, max_key FROM pgsnap_numeric;
    IF row_count < 10 OR row_count % 10 <> 0
       OR min_key <> 0 OR max_key <> row_count - 1 THEN
        RAISE EXCEPTION 'skew fixture requires N>=10, N divisible by 10, and original dense PK range [0,N)';
    END IF;
    IF row_count::numeric * 90 >= 100000000000000000000::numeric THEN
        RAISE EXCEPTION 'skew fixture mapped key would exceed numeric(20,0)';
    END IF;
END
$block$;

CREATE TABLE pgsnap_numeric_skew (LIKE pgsnap_numeric INCLUDING ALL);
INSERT INTO pgsnap_numeric_skew
WITH size AS (
    SELECT (count(*) * 9 / 10)::numeric AS cutoff FROM pgsnap_numeric
)
SELECT CASE WHEN src.column_1 < size.cutoff THEN src.column_1
            ELSE size.cutoff + (src.column_1 - size.cutoff + 1) * 891 END,
       src.column_2, src.column_3, src.column_4,
       src.column_5, src.column_6, src.column_7, src.column_8
FROM pgsnap_numeric AS src CROSS JOIN size
ORDER BY src.column_1;
COMMIT;
ANALYZE pgsnap_numeric_skew;

-- Record these rows and psql timing lines with preparation provenance.
SELECT 'numeric' AS profile, count(*) AS rows, min(column_1) AS min_key,
       max(column_1) AS max_key FROM pgsnap_numeric
UNION ALL
SELECT 'numeric_skew', count(*), min(column_1), max(column_1)
FROM pgsnap_numeric_skew;

SELECT count(*) AS total_rows,
       count(*) FILTER (WHERE column_1 < (SELECT count(*) * 9 / 10 FROM pgsnap_numeric)) AS dense_rows,
       count(*) FILTER (WHERE column_1 >= (SELECT count(*) * 9 / 10 FROM pgsnap_numeric)) AS sparse_rows
FROM pgsnap_numeric_skew;

SELECT relname, pg_relation_size(c.oid) AS heap_bytes,
       pg_indexes_size(c.oid) AS index_bytes, reltuples, relpages
FROM pg_class AS c JOIN pg_namespace AS n ON n.oid = c.relnamespace
WHERE n.nspname = :'bench_schema'
  AND relname IN ('pgsnap_numeric', 'pgsnap_numeric_skew',
                  'pgsnap_transfer_logs', 'pgsnap_clickbench')
ORDER BY relname;
