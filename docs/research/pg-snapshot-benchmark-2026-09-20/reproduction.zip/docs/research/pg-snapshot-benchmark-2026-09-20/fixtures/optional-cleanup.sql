-- Optional cleanup of early benchmark fixtures. NOT executed: approval review blocked it.
-- Six public.pgsnap_* performance tables and the final dedicated edge schema are retained.
BEGIN;
SET LOCAL lock_timeout = '2s';
DROP TABLE IF EXISTS
  public."empty_table",
  public."single_row",
  public."stale_pages",
  public."extreme_keys",
  public."nullable_keys",
  public."composite_keys",
  public."key_moves",
  public."tid_moves",
  public."growth",
  public."parted",
  public."uuid_keys",
  public."binary_keys",
  public."date_keys",
  public."timestamp_keys",
  public."decimal_keys",
  public."float_keys",
  public."locale_keys",
  public."mixed_composite",
  public."null_patterns",
  public."all_nulls",
  public."stats_missing",
  public."stats_stale",
  public."stats_mcv";
COMMIT;
