#!/usr/bin/env python3
"""Summarize Rust RELEASE EXPLAIN ANALYZE events without touching PostgreSQL.

Root node buffer counters already include descendant work: never sum them over
the tree. Executor-only diagnostic timings are kept apart from COPY throughput.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def event_paths(inputs):
    paths = set()
    for item in inputs:
        if item.is_file():
            paths.add(item.resolve())
        elif item.is_dir():
            paths.update(path.resolve() for path in item.rglob("events.jsonl"))
        else:
            raise FileNotFoundError(item)
    return sorted(paths)


def read_events(path):
    content = path.read_text(encoding="utf-8")
    lines = content.splitlines()
    events = []
    partial_line = False
    for index, line in enumerate(lines):
        if not line.strip():
            continue
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            if index == len(lines) - 1 and not content.endswith("\n"):
                partial_line = True
                continue
            raise ValueError(f"Malformed JSON at {path}:{index + 1}")
    return events, partial_line


def node_details(node, path="root"):
    loops = node.get("Actual Loops")
    rows = node.get("Actual Rows")
    result = {
        "path": path,
        "node_type": node.get("Node Type"),
        "relation": node.get("Relation Name"),
        "index": node.get("Index Name"),
        "actual_rows_per_loop": rows,
        "actual_loops": loops,
        "actual_rows_times_loops": rows * loops if rows is not None and loops is not None else None,
    }
    for name, field in (
        ("Rows Removed by Filter", "rows_removed_by_filter_per_loop"),
        ("Rows Removed by Index Recheck", "rows_removed_by_index_recheck_per_loop"),
        ("Rows Removed by Join Filter", "rows_removed_by_join_filter_per_loop"),
    ):
        if name in node:
            result[field] = node[name]
            result[field.replace("_per_loop", "_times_loops")] = node[name] * loops if loops is not None else None
    return result


def traverse(node, path="root"):
    yield node, path
    for index, child in enumerate(node.get("Plans", [])):
        yield from traverse(child, f"{path}.{index}")


def extract(path, events):
    experiment = next((event for event in events if event.get("kind") == "experiment"), None)
    if not experiment or experiment.get("consumer") != "rust_release" or experiment.get("release_build") is not True:
        return [], {"source": str(path), "reason": "not_explicitly_verified_rust_release"}
    if experiment.get("debug_assertions") is True:
        return [], {"source": str(path), "reason": "debug_assertions_enabled"}
    plans = {event["run_id"]: event for event in events if event.get("kind") == "plan"}
    runs = {event["run_id"]: event for event in events if event.get("kind") == "run"}
    output = []
    for event in events:
        if event.get("kind") != "explain_analyze":
            continue
        run_id = event["run_id"]
        if run_id not in plans or run_id not in runs:
            raise ValueError(f"Diagnostic has no matching plan and completed run: {path}/{run_id}")
        plan_event, run = plans[run_id], runs[run_id]
        if run.get("row_count_matches") is not True:
            raise ValueError(f"Diagnostic belongs to failed row-count verification: {path}/{run_id}")
        for entry in event["plans"]:
            documents = entry["plan"]
            if not isinstance(documents, list) or len(documents) != 1 or "Plan" not in documents[0]:
                raise ValueError(f"Unexpected EXPLAIN document shape: {path}/{run_id}")
            document = documents[0]
            root = document["Plan"]
            nodes = list(traverse(root))
            leaves = [node_details(node, node_path) for node, node_path in nodes if not node.get("Plans")]
            filters = [node_details(node, node_path) for node, node_path in nodes
                       if any(key.startswith("Rows Removed") for key in node)]
            root_info = node_details(root)
            chunk_id = entry["chunk_id"]
            predicates = plan_event.get("predicates", [])
            predicate = predicates[chunk_id] if chunk_id < len(predicates) else None
            row = {
                "source": str(path), "experiment": path.parent.name,
                "table": plan_event["table"], "strategy": plan_event["strategy"],
                "parallelism": plan_event["parallelism"], "repetition": run.get("repetition"),
                "run_id": run_id, "chunk_id": chunk_id, "predicate": predicate,
                "root_node_type": root.get("Node Type"),
                "root_plan_rows": root.get("Plan Rows"),
                "root_actual_rows_per_loop": root_info["actual_rows_per_loop"],
                "root_actual_loops": root_info["actual_loops"],
                "root_actual_rows_times_loops": root_info["actual_rows_times_loops"],
                "root_shared_hit_blocks": root.get("Shared Hit Blocks"),
                "root_shared_read_blocks": root.get("Shared Read Blocks"),
                "root_local_hit_blocks": root.get("Local Hit Blocks"),
                "root_local_read_blocks": root.get("Local Read Blocks"),
                "root_temp_read_blocks": root.get("Temp Read Blocks"),
                "root_temp_written_blocks": root.get("Temp Written Blocks"),
                "executor_planning_ms": document.get("Planning Time"),
                "executor_execution_ms": document.get("Execution Time"),
                "copy_run_scan_seconds": run.get("scan_seconds"),
                "copy_run_planning_seconds": run.get("planning_seconds"),
                "leaf_node_types": "; ".join(node["node_type"] or "unknown" for node in leaves),
                "leaf_nodes_json": json.dumps(leaves, ensure_ascii=False, separators=(",", ":")),
                "filter_nodes_json": json.dumps(filters, ensure_ascii=False, separators=(",", ":")),
            }
            output.append(row)
    return output, None


def number(value):
    if value is None:
        return "—"
    if isinstance(value, float):
        return f"{value:.3f}".rstrip("0").rstrip(".")
    return str(value)


def markdown(rows):
    lines = [
        "# Диагностика PostgreSQL executor: Rust RELEASE",
        "",
        "Это отдельные EXPLAIN ANALYZE запросы после COPY. Они не участвуют в throughput-гистограмме.",
        "Указаны только выбранные первый/последний chunk каждого диагностического запуска; это не сумма работы всех readers.",
        "",
        "`Shared hit/read` взяты только с корневого узла: PostgreSQL уже включает дочерние узлы в эти счётчики. "
        "Их нельзя суммировать по дереву. Это обращения к buffers, не число уникальных страниц и не прямое измерение дискового I/O.",
        "",
        "EXPLAIN SELECT может не извлекать/сериализовывать все TOAST payloads, которые COPY отправляет клиенту. "
        "Executor milliseconds нельзя подставлять вместо времени COPY или полного Transferia pipeline. "
        "Rows × loops восстановлены из EXPLAIN; при нескольких loops исходное среднее может быть округлено PostgreSQL.",
        "",
        "| Таблица | Механизм | P | Chunk | Root / leaves | Actual rows × loops | Shared hit | Shared read | Executor ms |",
        "|---|---|---:|---:|---|---:|---:|---:|---:|",
    ]
    for row in rows:
        node = row["root_node_type"]
        if row["leaf_node_types"] != node:
            node += " / " + row["leaf_node_types"]
        cells = [row["table"], row["strategy"], row["parallelism"], row["chunk_id"], node,
                 row["root_actual_rows_times_loops"], row["root_shared_hit_blocks"],
                 row["root_shared_read_blocks"], row["executor_execution_ms"]]
        lines.append("| " + " | ".join(number(cell).replace("|", "\\|") for cell in cells) + " |")
    lines += ["", "Полные предикаты, счётчики каждого leaf и Rows Removed сохранены в `diagnostics.csv` и `diagnostics.json`. "
              "Rows Removed сохранены на своём узле с отдельно указанными loops; они не объявляются количеством уникальных отброшенных строк во всём плане.", ""]
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", action="append", required=True, type=Path, help="Rust experiment directory, parent directory, or events.jsonl; repeatable")
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    rows, skipped, partial = [], [], []
    for path in event_paths(args.input):
        events, has_partial_line = read_events(path)
        if has_partial_line:
            partial.append(str(path))
        found, reason = extract(path, events)
        rows.extend(found)
        if reason:
            skipped.append(reason)
    rows.sort(key=lambda row: (row["table"], row["strategy"], row["parallelism"], row["experiment"], row["run_id"], row["chunk_id"]))
    args.output.mkdir(parents=True, exist_ok=True)
    if rows:
        with (args.output / "diagnostics.csv").open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    (args.output / "diagnostics.json").write_text(json.dumps({"records": rows, "skipped": skipped,
        "partial_trailing_events": partial, "measurement": "executor-only diagnostic queries, not COPY throughput",
        "buffers": "root counters only; descendants never added"}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (args.output / "DIAGNOSTICS.md").write_text(markdown(rows), encoding="utf-8")
    print(json.dumps({"diagnostic_plans": len(rows), "skipped": len(skipped), "partial_inputs": partial, "output": str(args.output)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
