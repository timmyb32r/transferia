-- Controlled second kind of skew: live rows are concentrated in the last 10%
-- of heap pages. Original Transferia numeric fixture is preserved.
-- Expected for N=2,000,000: 200,000 surviving rows, roughly the original heap
-- size, 90% mostly empty pages at the beginning. No TOAST or random widths.
-- Input schema is eight-column numeric generator fixture, keys [0,N).
-- Run only after regular benchmark fixtures are loaded; timings are preparation.
\set ON_ERROR_STOP on
\set bench_schema public
\timing on
SET search_path TO :"bench_schema", pg_catalog;

BEGIN;
LOCK TABLE pgsnap_numeric IN SHARE MODE;
DO $body$
DECLARE n bigint; lo numeric; hi numeric;
BEGIN
    SELECT count(*),min(column_1),max(column_1) INTO n,lo,hi FROM pgsnap_numeric;
    IF n < 10 OR n % 10 <> 0 OR lo <> 0 OR hi <> n-1 THEN
        RAISE EXCEPTION 'physical skew fixture requires dense [0,N) generator keys and N divisible by 10';
    END IF;
    IF pg_relation_size('pgsnap_numeric') > 1073741824 THEN
        RAISE EXCEPTION 'physical skew preparation expected source heap <= 1 GiB';
    END IF;
END
$body$;
CREATE TABLE pgsnap_numeric_bloat (LIKE pgsnap_numeric INCLUDING ALL);
ALTER TABLE pgsnap_numeric_bloat SET (autovacuum_enabled=false);
INSERT INTO pgsnap_numeric_bloat SELECT * FROM pgsnap_numeric ORDER BY column_1;
COMMIT;

SELECT 'before_delete' AS phase, count(*) AS rows,
       pg_relation_size('pgsnap_numeric_bloat') AS heap_bytes
FROM pgsnap_numeric_bloat;
DELETE FROM pgsnap_numeric_bloat
WHERE column_1 < (SELECT count(*) * 9 / 10 FROM pgsnap_numeric);
-- Plain VACUUM does not move live rows or compact the non-tail empty pages.
-- Live rows remain in the tail, preventing wholesale tail truncation.
VACUUM (ANALYZE) pgsnap_numeric_bloat;

SELECT 'after_delete_vacuum' AS phase, count(*) AS rows,
       pg_relation_size('pgsnap_numeric_bloat') AS heap_bytes,
       min(column_1) AS min_key,max(column_1) AS max_key
FROM pgsnap_numeric_bloat;

-- Exact live-row distribution over eight equal physical block intervals.
WITH physical AS (
    SELECT pg_relation_size('pgsnap_numeric_bloat') /
           current_setting('block_size')::bigint AS blocks
), counts AS (
    SELECT least(7, split_part(trim(both '()' FROM b.ctid::text), ',', 1)::bigint * 8 /
                    greatest(1, physical.blocks)) AS part,
           count(*) AS rows
    FROM pgsnap_numeric_bloat AS b CROSS JOIN physical GROUP BY part
)
SELECT part,coalesce(counts.rows,0) AS live_rows
FROM generate_series(0,7) AS parts(part) LEFT JOIN counts USING (part)
ORDER BY part;

-- No production setting is altered; this benchmark table alone disables
-- autovacuum to keep the controlled shape stable while measurements run.
