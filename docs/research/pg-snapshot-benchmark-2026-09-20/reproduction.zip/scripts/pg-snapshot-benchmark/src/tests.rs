use super::*;

fn header(extension: &[u8]) -> Vec<u8> {
    let mut bytes=b"PGCOPY\n\xff\r\n\0".to_vec();
    bytes.extend_from_slice(&0i32.to_be_bytes());
    bytes.extend_from_slice(&(extension.len() as i32).to_be_bytes());
    bytes.extend_from_slice(extension);
    bytes
}
fn add_row(bytes: &mut Vec<u8>, fields: &[Option<&[u8]>]) {
    bytes.extend_from_slice(&(fields.len() as i16).to_be_bytes());
    for field in fields {
        match field {
            Some(value)=> {bytes.extend_from_slice(&(value.len() as i32).to_be_bytes());bytes.extend_from_slice(value);}
            None=>bytes.extend_from_slice(&(-1i32).to_be_bytes()),
        }
    }
}
#[test]
fn counts_across_every_split_and_small_chunks() {
    let mut bytes=header(&[10,20,30]);
    add_row(&mut bytes,&[Some(b"payload\n\0"),None]);
    add_row(&mut bytes,&[Some(b""),Some(b"other")]);
    add_row(&mut bytes,&[None,None]);
    bytes.extend_from_slice(&(-1i16).to_be_bytes());
    for split in 0..=bytes.len() {
        let mut parser=BinaryCounter::new(); parser.feed(&bytes[..split]).unwrap();parser.feed(&bytes[split..]).unwrap();assert_eq!(parser.finish().unwrap(),3);
    }
    for width in 1..=32 {
        let mut parser=BinaryCounter::new();for chunk in bytes.chunks(width) {parser.feed(chunk).unwrap();}assert_eq!(parser.finish().unwrap(),3);
    }
}
#[test]
fn counts_empty_copy() {
    let mut bytes=header(&[]);bytes.extend_from_slice(&(-1i16).to_be_bytes());
    let mut parser=BinaryCounter::new();parser.feed(&bytes).unwrap();assert_eq!(parser.finish().unwrap(),0);
}
#[test]
fn rejects_bad_signature_trailer_and_truncation() {
    let mut bytes=header(&[]);bytes[0]=0;assert!(BinaryCounter::new().feed(&bytes).is_err());
    let mut bytes=header(&[]);bytes.extend_from_slice(&(-2i16).to_be_bytes());assert!(BinaryCounter::new().feed(&bytes).is_err());
    let mut bytes=header(&[]);add_row(&mut bytes,&[Some(b"123")]);
    let mut parser=BinaryCounter::new();parser.feed(&bytes).unwrap();assert!(parser.finish().is_err());
    bytes.extend_from_slice(&(-1i16).to_be_bytes());bytes.push(1);assert!(BinaryCounter::new().feed(&bytes).is_err());
}
#[test]
fn rejects_inconsistent_column_count_and_field_length() {
    let mut bytes=header(&[]);add_row(&mut bytes,&[None]);add_row(&mut bytes,&[None,None]);assert!(BinaryCounter::new().feed(&bytes).is_err());
    let mut bytes=header(&[]);bytes.extend_from_slice(&1i16.to_be_bytes());bytes.extend_from_slice(&(-2i32).to_be_bytes());assert!(BinaryCounter::new().feed(&bytes).is_err());
}
#[test]
fn parses_large_integral_numeric_exactly() {
    assert_eq!(integer("9223372036854775807.000").unwrap(),i64::MAX as i128);
    assert_eq!(integer("18446744073709551615").unwrap(),u64::MAX as i128);
    assert!(integer("1.1").is_err());
    assert!(integer("NaN").is_err());
}
#[test]
fn duplicate_range_cuts_keep_unbounded_tails() {
    assert_eq!(ranges("k",vec![3,3,-1]),vec!["k < -1","k >= -1 AND k < 3","k >= 3"]);
}
