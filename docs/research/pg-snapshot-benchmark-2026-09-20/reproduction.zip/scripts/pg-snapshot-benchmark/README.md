# PostgreSQL snapshot benchmark (Rust RELEASE)

This standalone experiment compares source-table partition plans. It consumes
complete PostgreSQL binary COPY streams and discards field payloads. It is not a
Transferia destination benchmark. Debug binaries explicitly refuse to run.

```sh
cargo build --release --manifest-path scripts/pg-snapshot-benchmark/Cargo.toml
cargo test --release --manifest-path scripts/pg-snapshot-benchmark/Cargo.toml

scripts/pg-snapshot-benchmark/target/release/pg-snapshot-benchmark \
  --table snapshot_bench.numeric --key column_1 \
  --strategies single,equal,quantile,sample,stats,modulo,hash,ctid,ctid_queue,keyset \
  --parallelism 1,2,4,8 --repetitions 3 --max-minutes 30 \
  --explain --output /tmp/pg-snapshot-rust-results
```

Set `PGHOST`, `PGPORT`, `PGDATABASE`, `PGUSER`, `PGPASSWORD`, `PGSSLMODE`, and
`PGSSLROOTCERT` in the environment. Credentials never enter result metadata.
`verify-full` is the default TLS mode. Certificate and host validation are
enabled in that mode. An explicit `require` selects encryption without certificate
verification, matching the requested environment mode; use `verify-full` for
verified connections.

Every table has one read-only repeatable-read coordinator transaction. It locks
the heap against conflicting DDL, exports its snapshot, validates the fixture,
and imports that exact snapshot into every reader. All timed scans use identical
`SELECT * FROM ONLY table` projections. Reader count is 1/2/4/8; the Tokio runtime
has a fixed 16 workers. Server parallel query and JIT are disabled by default.

The COPY framing parser holds a 19-byte scratch area and counters. It handles
arbitrary input block boundaries, NULL and empty fields, COPY headers/extensions,
and the trailer without decoding or copying field payloads. A malformed or
truncated stream fails the benchmark. Successful streams provide exact row
counts, checked against the reference table count. Tests cover every split point
of a representative stream and malformed framing.

The measured fixtures require an ordinary **heap** table, a primary key, and a
unique, non-null, exactly integral numeric split column. That column can be a
leading composite-key component or a secondary indexed column. This restriction
describes the benchmark matrix; it is not a claim that other types cannot be
partitioned. Boundary arithmetic is checked i128, never floating point. Floating
point quantile probabilities do not change the precision of selected keys.

Mechanisms:

| Strategy | Work division |
| --- | --- |
| `single` | One unrestricted COPY. |
| `equal` | Exact MIN/MAX domain intervals, one per reader. |
| `quantile` | Exact `percentile_disc` boundaries; planning cost included. |
| `sample` | `TABLESAMPLE SYSTEM` quantiles, 8 chunks per reader by default. |
| `stats` | Existing `pg_stats.histogram_bounds`, 8 queued chunks per reader by default. Missing/empty histograms explicitly produce one unrestricted chunk. |
| `modulo` | Normalized modulo, safe for negative and minimum signed keys. |
| `hash` | PostgreSQL `hash_numeric` or `hashint8`, then normalized modulo. |
| `hash_ctid` | PostgreSQL `hashtid(ctid)`, then normalized modulo. A separate candidate: independent of logical key values, but each reader filters the full heap. |
| `ctid` | Heap-page intervals using native TID range predicates. |
| `ctid_queue` | Same physical mechanism with 8 queued chunks per reader. |
| `keyset` | Precompute boundaries by bounded ordered index scans, then queue ranges. |
| `weighted_ctid` | Separate candidate: BERNOULLI row sample, whole-row datum byte weights, cumulative-weight quantiles in native TID order, then queued physical intervals. Sampling scans the heap and its entire cost is included in planning. |
| `weighted_ctid_linear` | Same sample/weights and exact cuts, selected in one pass over cumulative weights after sorting, using exact numeric integer division. Avoids the original weighted planner's per-target rescans. |

Range strategies always retain unbounded outer tails. Histogram/sampling
boundaries affect balance, not coverage. Histograms exclude most-common values;
their distribution is not a universal row-balance guarantee. Keyset planning is
performed before the timed COPY phase, and its full cost is included in planning.
This is not adaptive online subdivision. CTID bounds use actual relation size,
not estimated `relpages`; they are valid only inside the shared snapshot.
`hash_ctid` does not use hashes as identity: collisions simply assign different
rows to the same reader. Its physical-address assignment is valid only within
the shared snapshot and for this one physical relation. It is not persisted
resumable identity. Although the mechanism does not need an integer logical key,
the common benchmark fixture validator retains its numeric-key restriction.
`weighted_ctid` uses `pg_column_size(whole-row datum)` as a byte-cost estimate,
not exact COPY size or measured detoasting time. An empty sample explicitly falls
back to a complete single scan. Neither candidate changes the original ten-
strategy matrix; its reproduction script lists those ten strategies explicitly.
The original `weighted_ctid` SQL remains unchanged for reproduction. With S
sampled rows and K requested chunks, its lateral lookups can rescan the sample
K times. `weighted_ctid_linear` selects crossing rows in O(S) after the common
TID sort; it still incurs the heap sampling and row-size estimation costs.

`events.jsonl` and `runs.csv` are written incrementally without overwriting an
existing experiment. The schedule is deterministically shuffled from `--seed`.
`planning_seconds + scan_seconds = total_seconds`. Reader connection startup,
reference validation, and EXPLAIN are measured/reported separately or explicitly
excluded. The reference count/distinct/integrality query can warm indexes and is
a benchmark correctness preflight, not a required production planning algorithm.
No cold-cache claim is made. Payload bytes include COPY framing and exclude
TCP/TLS overhead. Run CPU is process CPU across all Tokio tasks; per-chunk CPU is
left null because asynchronous tasks do not have isolated thread CPU clocks.

`--explain` captures estimated plans outside timing. `--explain-analyze` performs
additional first/last-chunk executor scans after every run, also outside timing;
use it in a separate diagnostic pass to avoid changing the main matrix's cache
conditions. Overall timeout wraps the entire experiment, including setup and
planning. SQL timeout and worker failures preserve completed events and return
failure. Matching total row counts are useful evidence, not a complete proof of
set equality; small edge-case fixtures should compare full row identities.
