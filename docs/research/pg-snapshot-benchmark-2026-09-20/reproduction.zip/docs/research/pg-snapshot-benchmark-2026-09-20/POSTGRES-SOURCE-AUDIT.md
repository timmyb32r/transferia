# PostgreSQL: что действительно делает CTID range scan

Аудит 2026-09-20. Локальное дерево `/Users/timmyb32r/tmp/postgres`:
`9fa2c1ebd1757db6032cf81b53f973941be77747`, 2026-07-29,
**PostgreSQL 20devel**, что прямо записано в `configure.ac:20`.
Сервер бенчмарка — PostgreSQL 17; различия сверены с официальной веткой
`REL_17_STABLE`. Нельзя приписывать серверу возможности локального checkout.

## Подтверждённые механизмы

| Факт | Доказательство | Следствие для бенчмарка/алгоритма |
|---|---|---|
| Planner распознаёт сравнения непосредственно `ctid` с `tid`: `<`, `<=`, `>`, `>=` и их AND. | Локальный `src/backend/optimizer/path/tidpath.c:26`, `:151`, `:398`; [PG17 tidpath.c](https://github.com/postgres/postgres/blob/REL_17_STABLE/src/backend/optimizer/path/tidpath.c#L142). | Запрос `ctid >= '(a,0)'::tid AND ctid < '(b,0)'::tid`. Извлечение номера блока через `ctid::text` превращает условие в обычный filter; проверить EXPLAIN. |
| Executor передаёт snapshot транзакции в table AM. | Локальный `src/backend/executor/nodeTidrangescan.c:250`; [PG17 nodeTidrangescan.c](https://github.com/postgres/postgres/blob/REL_17_STABLE/src/backend/executor/nodeTidrangescan.c#L226). | Физический диапазон не обходит MVCC. Общий экспортированный snapshot делает независимые диапазоны согласованными. |
| Heap AM сужает именно диапазон читаемых страниц. | Локальный `src/backend/access/heap/heapam.c:1505`, `:1564`, `:1570`, `:1600`; [PG17 heapam.c](https://github.com/postgres/postgres/blob/REL_17_STABLE/src/backend/access/heap/heapam.c). | В отличие от hash filter, не требуется полный проход по таблице для каждого worker. |
| Пустой heap, перевёрнутые границы и границы за концом обрабатываются безопасно. | Локальный `heapam.c:1514`, `:1526`, `:1548`. | Пустая/маленькая таблица не требует особых SQL-сентинелов, но не стоит создавать десятки пустых задач. |
| Стоимость диапазона считается как одна случайная страница и остальные последовательные. Seq scan имеет отдельные преимущества. | Локальный `src/backend/optimizer/path/costsize.c:1398`, `:1424`. | CTID не должен автоматически заменять один простой seq scan; небольшие таблицы и один reader нужно измерить отдельно. |
| Локальный PG20 умеет строить partial parallel Tid Range Scan; PG17 в соответствующей функции добавляет только обычный path. | Локальный `tidpath.c:559`; [PG17 create_tidscan_paths](https://github.com/postgres/postgres/blob/REL_17_STABLE/src/backend/optimizer/path/tidpath.c#L480). | Наша параллельность — несколько подключений. В измерениях отключить внутренние parallel workers, чтобы не сравнивать разные суммарные ресурсы. |
| Видимость версии строки проверяется snapshot-ом; CTID — адрес версии, а не постоянная идентичность строки. | Локальный `heapam.c:1019`, `doc/src/sgml/ddl.sgml:1567`; [system columns PG17](https://www.postgresql.org/docs/17/ddl-system-columns.html). | UPDATE может переместить новую версию в другой диапазон. С разными snapshot одна логическая строка может пропасть/повториться; PK нужен для проверки результата, CTID не заменяет PK. |
| `pg_class.relpages` — оценка planner, обновляемая ANALYZE/VACUUM и некоторым DDL. | Локальный `doc/src/sgml/catalogs.sgml:2052`; [pg_class PG17](https://www.postgresql.org/docs/17/catalog-pg-class.html). | Нельзя использовать relpages как доказательство конца таблицы: после загрузки значение бывает нулевым. Размер main fork нужен после фиксации snapshot и защиты relation; открытый последний диапазон дополнительно упрощает полное покрытие. |
| Import snapshot должен предшествовать первому запросу новой RR/SERIALIZABLE транзакции; импорт ограничен той же БД. | Локальный `src/backend/utils/time/snapmgr.c:1401`, `:1418`, `:1550`; [SET TRANSACTION](https://www.postgresql.org/docs/17/sql-set-transaction.html). | Каждый reader: BEGIN REPEATABLE READ READ ONLY; SET TRANSACTION SNAPSHOT; SET LOCAL; затем чтение. Через transaction pooler session SET до BEGIN нельзя считать сохранённым. Не подключать часть readers к другому серверу/реплике. |
| Выданный export snapshot ID доступен для новых импортов только пока жив экспортировавший его transaction. | [Snapshot synchronization PG17](https://www.postgresql.org/docs/17/functions-admin.html#FUNCTIONS-SNAPSHOT-SYNCHRONIZATION). | Потеря coordinator делает его ID недоступным. Уже импортировавшие snapshot транзакции сохраняют его; повторный export от такого keeper успешно проверен отдельным экспериментом. Если живых владельцев старого snapshot не осталось, restart требует нового epoch и повторного чтения. |

## Границы применимости

- Для partitioned/inherited таблиц task идентифицирует **physical relation + CTID interval**. CTID локален для relation; одинаковые `(0,1)` в двух leaf — две разные строки. Обходить leaves и читать `ONLY leaf`, иначе легко повторно включить descendants. У partitioned parent своего heap нет.
- Зафиксировать состав leaves и удерживать `ACCESS SHARE` на нужных relations до конца snapshot. Для заранее известных ordinary tables безопасная последовательность: `BEGIN REPEATABLE READ`, `LOCK ... IN ACCESS SHARE MODE`, export snapshot, получение размеров. Блокировка нужна **до** фиксации snapshot: `TRUNCATE` между snapshot и первым доступом к table не является MVCC-safe и способен сделать таблицу пустой для старого snapshot. Это допускает обычный DML, но мешает операциям, требующим `ACCESS EXCLUSIVE`. Сам export snapshot не блокирует изменение физической структуры. [TRUNCATE PG17](https://www.postgresql.org/docs/17/sql-truncate.html).
- `ACCESS SHARE` не означает запрет любого partition DDL. Например, concurrent detach сначала использует `SHARE UPDATE EXCLUSIVE`, затем ожидает старых читателей и финализирует detach с `ACCESS EXCLUSIVE` на leaf (локальный `src/backend/commands/tablecmds.c:21734`, `:21818`). Финальный эксперимент проверил parent SUE + leaf ACCESS SHARE до export: read-only keeper владельца разрешил INSERT, actual ATTACH и ANALYZE получили `55P03`. Сам DETACH CONCURRENTLY не выполнялся, проверен конфликт его parent mode. Полная DDL-матрица и многоуровневая topology не проверены; сильный lock требует дополнительных прав и блокирует maintenance.
- Зафиксировать snapshot **до** получения верхнего физического размера. Если получить размер раньше, между этими действиями могут появиться видимые новому snapshot строки за границей. Невошедшие в snapshot новые страницы читать необязательно, но их наличие не нарушает MVCC.
- Затяжной snapshot удерживает старые версии и мешает их удалению VACUUM. Это цена point-in-time согласованности; данный короткий тест не измеряет накопление bloat при часах записи.
- Равные heap pages не гарантируют равное время. Влияют плотность live tuples, bloat, TOAST, ширина сериализованной строки, кэш и фильтры. Очередь более мелких chunks — кандидат при дисбалансе, но дополнительные запросы имеют стоимость: основной Rust benchmark показал как пользу, так и проигрыш такой очереди. Безусловно назначать 8P частей не следует.
- Порядок вывода между concurrent readers не определён. Snapshot обеспечивает один набор видимых строк, а не глобальную сортировку.
- Для filtered extract селективный PK/index scan может выиграть у CTID, читающего все heap pages. Для полного snapshot широких строк CTID экономит проход по индексу; конкретный выигрыш устанавливает измерение.
- CTID-диапазоны требуют table AM с поддержкой range scan. Foreign tables, views и альтернативные AM нельзя включать автоматически только по имени PostgreSQL.

## Выполняемый набор краевых случаев

[`scripts/benchmark_pg_snapshot_edges.py`](../../../scripts/benchmark_pg_snapshot_edges.py)
читает стандартные PG* переменные, создаёт только схему
`transferia_snapshot_edges_20260920` и сохраняет JSON с наблюдениями.
В начале каждого повторного запуска заменяет только свои именованные таблицы.

Первые 14 сценариев: empty/tiny; stale relpages; диапазоны вне heap; extrema BIGINT;
NULL + неуникальный split field; пересечение включённых границ;
составной текстовый PK с серверной collation; локальность CTID в partitions;
движение ключей и движение CTID при UPDATE с общим/разными snapshots;
размер до snapshot; истечение export; защита relation lock; форма TID predicate.

Расширение до 34 сценариев добавляет UUID/bytea/array/enum/date/timestamptz,
fractional numeric, float specials, default collation, разнородный составной
PK, nullable tuple, all-NULL, missing/stale/disabled statistics, MCV skew,
пустой sample, wide-key omission, FORCE RLS, re-export живым keeper и
partition topology locking. **Все 34 сценария прошли**;
[фактические наблюдения](EDGE-ANALYSIS.md) и [raw JSON](raw/edge-results.json)
сохранены отдельно. Python использован только для функциональных проверок.

В случаях с намеренно неправильным алгоритмом `passed` означает, что
воспроизведена и проверена ожидаемая потеря/дублирование, а правильный вариант
вернул точное множество. Сам по себе COUNT недостаточен: сценарий движения
ключей специально сохраняет число результатов, одновременно теряя одну
логическую строку и дублируя другую.

Статус выполнения и фактические числа берутся из JSON результатов; этот
документ не подменяет запуск утверждением об успешной проверке.
