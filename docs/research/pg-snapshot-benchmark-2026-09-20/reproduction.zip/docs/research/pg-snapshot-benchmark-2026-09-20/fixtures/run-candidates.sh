#!/usr/bin/env bash
set -euo pipefail
base=target/benchmarks/pg-snapshot-2026-09-20
binary="${PG_SNAPSHOT_BENCHMARK_BIN:-scripts/pg-snapshot-benchmark/target/release/pg-snapshot-benchmark}"
for profile in numeric numeric_skew transfer_logs clickbench numeric_bloat numeric_width_skew; do
  key=column_1
  if [[ "$profile" == transfer_logs ]]; then key=_system_offset; fi
  if [[ "$profile" == clickbench ]]; then key=WatchID; fi
  printf 'Starting candidate/scaling cohort: %s\n' "$profile"
  "$binary" --table "public.pgsnap_$profile" --key "$key" \
    --strategies ctid,ctid_queue,stats,hash,weighted_ctid \
    --parallelism 8,16,32 --repetitions 3 --max-minutes 8 --explain \
    --output "$base/rust-candidate-$profile" > "$base/rust-candidate-$profile.log" 2>&1 || {
      tail -n 25 "$base/rust-candidate-$profile.log"
      exit 1
    }
  printf 'Completed candidate/scaling cohort: %s\n' "$profile"
done
