#!/usr/bin/env python3
"""Aggregate completed snapshot benchmark runs and plot measured results only.

Reads runs.csv/events.jsonl beneath one or more experiment directories. Events
are authoritative when both exist. Different tables/row counts never aggregate
together. Default plotting chooses the largest measured fixture for each known
profile and the best observed Rust release parallelism, not a prediction.
"""

from __future__ import annotations

import argparse
import csv
import fnmatch
import json
import math
from pathlib import Path
import statistics
from collections import Counter, defaultdict
from datetime import datetime, timezone

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


PROFILE_NAMES = {
    "numeric": "Numeric · плотный ключ",
    "transfer_logs": "Transfer logs · составной PK",
    "clickbench": "ClickBench · случайный WatchID",
    "numeric_skew": "Numeric skew · 90% строк / 1% ключей",
    "numeric_bloat": "Bloat · живые строки в последних 10% heap",
    "numeric_width_skew": "TOAST skew · 1% строк с payload 64 KiB",
}
STRATEGY_NAMES = {
    "single": "Single scan", "equal": "MIN/MAX", "quantile": "Точные квантили",
    "sample": "Сэмпл + очередь", "stats": "Гистограмма pg_stats", "modulo": "Modulo", "hash": "Hash",
    "ctid": "CTID", "ctid_queue": "CTID + очередь", "keyset": "Keyset boundaries", "weighted_ctid": "CTID по весу строк", "hash_ctid": "Hash(CTID)", "weighted_ctid_linear": "CTID по весу · linear",
}
COLORS = {"single": "#64748b", "equal": "#d97706", "quantile": "#7c3aed", "stats": "#a16207",
          "sample": "#0891b2", "modulo": "#be123c", "hash": "#dc2626",
          "ctid": "#0f766e", "ctid_queue": "#059669", "keyset": "#4f46e5", "weighted_ctid": "#0369a1", "hash_ctid": "#be185d", "weighted_ctid_linear": "#0284c7"}
METRICS = ("total_seconds", "with_startup_seconds", "planning_seconds", "scan_seconds", "rows_per_second", "mib_per_second",
           "client_cpu_seconds", "worker_startup_seconds", "client_cpu_cores")
BALANCE_METRICS = ("max_worker_byte_share", "max_worker_row_share", "empty_workers",
                   "worker_service_time_imbalance", "max_chunk_byte_share", "max_chunk_row_share")


def profile_for(table):
    name = table.split(".")[-1].strip('"').lower()
    for suffix in ("numeric_width_skew", "numeric_bloat", "numeric_physical_skew", "numeric_skew", "transfer_logs", "clickbench", "numeric", "skew", "logs"):
        if name == suffix or name.endswith("_" + suffix):
            return {"skew": "numeric_skew", "logs": "transfer_logs"}.get(suffix, suffix)
    return name


def truth(value):
    return value is True or (isinstance(value, str) and value.lower() == "true")


def consumer_for(directory, experiment):
    # User explicitly excluded all Python/C timing experiments from final data.
    if experiment and (experiment.get("release_build") is False or experiment.get("debug_assertions") is True):
        return "excluded_non_release"
    for part in reversed(directory.parts):
        if part.startswith("rust-") or part == "rust":
            return "rust_release"
    if experiment and experiment.get("consumer") == "rust_release":
        return "rust_release"
    return "excluded_non_rust"


def read_events(path, warnings):
    events = []
    content = path.read_text()
    lines = content.splitlines()
    for index, line in enumerate(lines):
        if not line.strip():
            continue
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError as error:
            if index == len(lines) - 1 and not content.endswith("\n"):
                warnings.append(f"Incomplete trailing event ignored: {path}")
            else:
                raise ValueError(f"Malformed event at {path}:{index + 1}") from error
    return events


def discover(paths):
    directories = set()
    for path in paths:
        if path.is_file() and path.name in ("runs.csv", "events.jsonl"):
            directories.add(path.parent.resolve())
        elif path.is_dir():
            for filename in ("runs.csv", "events.jsonl"):
                directories.update(item.parent.resolve() for item in path.rglob(filename))
    return sorted(directories)


def load_runs(paths, include_patterns):
    runs, experiments, warnings = [], [], []
    skipped = Counter()
    for directory in discover(paths):
        if not any(fnmatch.fnmatchcase(directory.name, pattern) for pattern in include_patterns):
            skipped["excluded_experiment_cohort"] += 1
            continue
        event_path = directory / "events.jsonl"
        events = read_events(event_path, warnings) if event_path.exists() else []
        experiment = next((event for event in events if event.get("kind") == "experiment"), None)
        metadata = {event["table"]: event for event in events if event.get("kind") == "table"}
        chunks_by_run = defaultdict(list)
        for event in events:
            if event.get("kind") == "chunk":
                chunks_by_run[event["run_id"]].append(event)
        invalid_ids = {event["run_id"] for event in events
                       if event.get("kind") == "aggregate_verification" and not event.get("matches")}
        aggregate_ids = {event["run_id"] for event in events
                         if event.get("kind") == "aggregate_verification" and event.get("matches")}
        consumer = consumer_for(directory, experiment)
        if consumer != "rust_release":
            skipped["excluded_non_rust_experiment"] += 1
            continue
        if event_path.exists():
            candidates = [event for event in events if event.get("kind") == "run"]
        else:
            with (directory / "runs.csv").open() as stream:
                candidates = list(csv.DictReader(stream))
        experiments.append({
            "directory": str(directory), "consumer": consumer, "completed_runs": len(candidates),
            "experiment_complete": any(event.get("kind") == "complete" for event in events),
            "errors": [{"error_type": event.get("error_type"), "runs_started": event.get("runs_started")}
                       for event in events if event.get("kind") == "error"],
            "arguments": experiment.get("arguments") if experiment else None,
        })
        for candidate in candidates:
            if candidate.get("release_build") is False:
                skipped["excluded_non_release_run"] += 1
                continue
            if not truth(candidate.get("row_count_matches")) or candidate.get("run_id") in invalid_ids:
                skipped["failed_correctness"] += 1
                continue
            try:
                table = candidate["table"]
                rows = int(candidate["rows"])
                expected = int(candidate["expected_rows"])
                parallelism = int(candidate["parallelism"])
                scan = float(candidate["scan_seconds"])
                planning = float(candidate["planning_seconds"])
                total = float(candidate["total_seconds"])
                if rows != expected or scan <= 0 or planning < 0 or not all(map(math.isfinite, (scan, planning, total))):
                    raise ValueError("invalid count or timing")
                if not math.isclose(total, planning + scan, rel_tol=1e-8, abs_tol=1e-8):
                    raise ValueError("total must equal planning + scan")
                cpu = float(candidate["client_cpu_seconds"])
                payload = int(candidate["copy_payload_bytes"])
                startup = float(candidate.get("worker_startup_seconds", 0))
                run = {
                    "profile": profile_for(table), "consumer": consumer, "table": table,
                    "expected_rows": expected, "strategy": candidate["strategy"], "parallelism": parallelism,
                    "run_id": candidate["run_id"], "repetition": int(candidate["repetition"]),
                    "source_directory": str(directory), "total_seconds": total, "planning_seconds": planning,
                    "with_startup_seconds": total + startup,
                    "scan_seconds": scan, "rows_per_second": rows / scan,
                    "mib_per_second": payload / scan / 2**20, "client_cpu_seconds": cpu,
                    "worker_startup_seconds": startup,
                    "client_cpu_cores": cpu / scan, "copy_payload_bytes": payload,
                    "aggregate_verified": candidate["run_id"] in aggregate_ids,
                    "heap_bytes": metadata.get(table, {}).get("heap_bytes"),
                    "chunks": int(candidate["chunks"]),
                }
            except (ValueError, TypeError, KeyError):
                skipped["incomplete_or_invalid_record"] += 1
                continue
            chunks = chunks_by_run[candidate["run_id"]]
            if len(chunks) == run["chunks"] and chunks and rows and payload:
                worker_bytes = [0] * parallelism
                worker_rows = [0] * parallelism
                worker_service = [0.0] * parallelism
                for chunk in chunks:
                    worker = int(chunk["worker"])
                    if not 0 <= worker < parallelism:
                        raise ValueError(f"Invalid worker in {directory}/{candidate['run_id']}")
                    worker_bytes[worker] += int(chunk["copy_payload_bytes"])
                    worker_rows[worker] += int(chunk["rows"])
                    worker_service[worker] += float(chunk["seconds"])
                if sum(worker_bytes) != payload or sum(worker_rows) != rows:
                    raise ValueError(f"Chunk totals disagree in {directory}/{candidate['run_id']}")
                run["balance"] = {
                    "max_worker_byte_share": max(worker_bytes) / payload,
                    "max_worker_row_share": max(worker_rows) / rows,
                    "empty_workers": sum(value == 0 for value in worker_rows),
                    "worker_service_time_imbalance": max(worker_service) / statistics.mean(worker_service),
                    "max_chunk_byte_share": max(int(chunk["copy_payload_bytes"]) for chunk in chunks) / payload,
                    "max_chunk_row_share": max(int(chunk["rows"]) for chunk in chunks) / rows,
                }
            else:
                run["balance"] = None
            runs.append(run)
    return runs, experiments, warnings, dict(skipped)


def aggregate(runs):
    groups = defaultdict(list)
    dimensions = ("profile", "consumer", "table", "expected_rows", "strategy", "parallelism")
    for run in runs:
        groups[tuple(run[name] for name in dimensions)].append(run)
    output = []
    for key, values in sorted(groups.items()):
        row = dict(zip(dimensions, key))
        row.update(n=len(values), aggregate_verified_n=sum(run["aggregate_verified"] for run in values),
                   source_directories=sorted({run["source_directory"] for run in values}))
        for metric in METRICS:
            data = [run[metric] for run in values]
            row[metric + "_median"] = statistics.median(data)
            row[metric + "_min"] = min(data)
            row[metric + "_max"] = max(data)
        output.append(row)
    return output


def aggregate_balance(runs):
    groups = defaultdict(list)
    dimensions = ("profile", "consumer", "table", "expected_rows", "strategy", "parallelism")
    for run in runs:
        if run["balance"] is not None:
            groups[tuple(run[name] for name in dimensions)].append(run["balance"])
    output = []
    for key, values in sorted(groups.items()):
        row = dict(zip(dimensions, key), n=len(values))
        for metric in BALANCE_METRICS:
            data = [value[metric] for value in values]
            row[metric + "_median"] = statistics.median(data)
            row[metric + "_min"] = min(data)
            row[metric + "_max"] = max(data)
        output.append(row)
    return output


def selected_fixtures(groups):
    choices = defaultdict(dict)
    for group in groups:
        key = (group["table"], group["expected_rows"])
        old = choices[group["profile"]].setdefault(key, [0, 0])
        old[0] += group["n"] if group["consumer"] == "rust_release" else 0
        old[1] += group["n"]
    selected = {}
    for profile, fixtures in choices.items():
        selected[profile] = max(fixtures, key=lambda key: (key[1], fixtures[key][0], fixtures[key][1], key[0]))
    return selected


def save_figure(figure, output, stem):
    figure.savefig(output / (stem + ".png"), dpi=175, bbox_inches="tight", facecolor="white")
    figure.savefig(output / (stem + ".svg"), bbox_inches="tight", facecolor="white")
    plt.close(figure)


def panel_title(profile, selected):
    fixture = selected.get(profile)
    return PROFILE_NAMES.get(profile, profile) + (f"\n{fixture[1]:,} строк" if fixture else "\nнет данных")


def matches(group, profile, selected, consumer="rust_release"):
    return (group["profile"] == profile and group["consumer"] == consumer
            and (group["table"], group["expected_rows"]) == selected.get(profile))


def best_chart(groups, selected, output):
    measured_parallelism = sorted({group["parallelism"] for group in groups})
    profiles = [name for name in PROFILE_NAMES if name in selected] + sorted(set(selected) - set(PROFILE_NAMES))
    profiles = profiles or list(PROFILE_NAMES)
    rows = math.ceil(len(profiles) / 2)
    figure, axes = plt.subplots(rows, 2, figsize=(16, rows * 6.4), squeeze=False)
    for axis in list(axes.flat)[len(profiles):]:
        axis.set_axis_off()
    best = []
    for axis, profile in zip(axes.flat, profiles):
        candidates = defaultdict(list)
        for group in groups:
            if matches(group, profile, selected):
                candidates[group["strategy"]].append(group)
        winners = [min(values, key=lambda group: group["total_seconds_median"]) for values in candidates.values()]
        winners.sort(key=lambda group: group["total_seconds_median"])
        best.extend(winners)
        axis.set_title(panel_title(profile, selected), loc="left", pad=14)
        if not winners:
            axis.text(.5, .5, "Измерений Rust release пока нет", ha="center", va="center", transform=axis.transAxes)
            axis.set_axis_off()
            continue
        values = [group["total_seconds_median"] for group in winners]
        errors = [[value - group["total_seconds_min"] for value, group in zip(values, winners)],
                  [group["total_seconds_max"] - value for value, group in zip(values, winners)]]
        axis.barh(range(len(winners)), values, xerr=errors, capsize=3,
                  color=[COLORS.get(group["strategy"], "#64748b") for group in winners], alpha=.9)
        axis.set_yticks(range(len(winners)), [STRATEGY_NAMES.get(group["strategy"], group["strategy"]) for group in winners])
        axis.invert_yaxis()
        right = max(group["total_seconds_max"] for group in winners)
        axis.set_xlim(0, max(.01, right) * 1.52)
        for index, group in enumerate(winners):
            axis.text(group["total_seconds_max"] + right * .025, index,
                      f"{group['total_seconds_median']:.3g} с · P{group['parallelism']} · n={group['n']}",
                      va="center", fontsize=9)
        axis.set_xlabel("Планирование + COPY scan, секунды · меньше лучше")
        axis.grid(axis="x", alpha=.18)
        axis.set_axisbelow(True)
    parallelism_label = ", ".join(str(value) for value in measured_parallelism) or "нет данных"
    figure.suptitle(f"Лучший измеренный P ∈ {{{parallelism_label}}} для каждого механизма\nRust release · медиана, полоски min–max", fontsize=16, y=1.01)
    figure.text(.01, -.005, "Показаны только выполненные прогоны. n — число измерений выбранной комбинации. Запуск workers исключён; это не прогноз оптимального P.", fontsize=10)
    figure.tight_layout()
    save_figure(figure, output, "rust-best-observed")
    return best


def scaling_chart(groups, selected, output):
    strategies = (("ctid", "o"), ("equal", "s"), ("sample", "D"), ("hash", "^"))
    if any(group["strategy"] == "weighted_ctid_linear" for group in groups):
        strategies = (("ctid", "o"), ("hash", "^"), ("hash_ctid", "D"), ("weighted_ctid_linear", "P"))
    elif any(group["strategy"] == "weighted_ctid" for group in groups):
        strategies = (("ctid", "o"), ("ctid_queue", "s"), ("stats", "D"), ("hash", "^"), ("weighted_ctid", "P"))
    elif any(group["strategy"] == "hash_ctid" for group in groups):
        strategies = (("ctid", "o"), ("hash", "^"), ("hash_ctid", "D"))
    profiles = [name for name in PROFILE_NAMES if name in selected] + sorted(set(selected) - set(PROFILE_NAMES))
    profiles = profiles or list(PROFILE_NAMES)
    rows = math.ceil(len(profiles) / 2)
    figure, axes = plt.subplots(rows, 2, figsize=(15, rows * 5.4), squeeze=False)
    for axis in list(axes.flat)[len(profiles):]:
        axis.set_axis_off()
    for axis, profile in zip(axes.flat, profiles):
        axis.set_title(panel_title(profile, selected), loc="left")
        found = False
        ticks = set()
        for strategy, marker in strategies:
            values = sorted((group for group in groups if matches(group, profile, selected)
                             and group["strategy"] == strategy), key=lambda group: group["parallelism"])
            if not values:
                continue
            found = True
            x = [group["parallelism"] for group in values]
            ticks.update(x)
            y = [group["total_seconds_median"] for group in values]
            error = [[median - group["total_seconds_min"] for median, group in zip(y, values)],
                     [group["total_seconds_max"] - median for median, group in zip(y, values)]]
            counts = {group["n"] for group in values}
            n_label = f"n={next(iter(counts))} для каждой точки" if len(counts) == 1 else ", ".join(f"P{group['parallelism']}:n={group['n']}" for group in values)
            axis.errorbar(x, y, yerr=error, marker=marker, capsize=3, linewidth=2,
                          color=COLORS[strategy], label=STRATEGY_NAMES[strategy] + " · " + n_label)
        if found:
            axis.set_xscale("log", base=2)
            axis.set_xticks(sorted(ticks), [str(value) for value in sorted(ticks)])
            axis.set_ylim(bottom=0)
            axis.legend(fontsize=9)
        else:
            axis.text(.5, .5, "Нет измерений", ha="center", transform=axis.transAxes)
        axis.set_xlabel("Число readers P")
        axis.set_ylabel("Планирование + scan, с")
        axis.grid(alpha=.18)
    figure.suptitle("Как меняется время при увеличении числа readers\nRust release · медиана и min–max; показаны только измеренные P", fontsize=15, y=1.01)
    figure.tight_layout()
    save_figure(figure, output, "rust-scaling")


def write_csv(path, rows):
    if not rows:
        path.write_text("")
        return
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        for row in rows:
            writer.writerow({key: json.dumps(value) if isinstance(value, (dict, list)) else value for key, value in row.items()})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, action="append", required=True, help="Directory recursively containing rust-* experiments; Python/C data excluded")
    parser.add_argument("--include", action="append", help="Experiment directory name/glob; repeatable. Default is the six approved main-matrix directories; smoke/diagnostic/scale data excluded.")
    parser.add_argument("--output", type=Path, default=Path("docs/research/pg-snapshot-benchmark-2026-09-20/results"))
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    include_patterns = args.include or ["rust-" + profile for profile in PROFILE_NAMES]
    runs, experiments, warnings, skipped = load_runs(args.input, include_patterns)
    groups = aggregate(runs)
    balance_groups = aggregate_balance(runs)
    selected = selected_fixtures(groups)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
    best = best_chart(groups, selected, args.output)
    one_shot_candidates = defaultdict(list)
    for group in groups:
        if matches(group, group["profile"], selected):
            one_shot_candidates[(group["profile"], group["strategy"])].append(group)
    best_one_shot = [min(values, key=lambda group: group["with_startup_seconds_median"])
                     for _, values in sorted(one_shot_candidates.items())]
    profile_summary = []
    for profile in selected:
        available = [group for group in groups if matches(group, profile, selected)]
        baseline = next((group for group in available if group["strategy"] == "single" and group["parallelism"] == 1), None)
        if not available:
            continue
        winner = min(available, key=lambda group: group["total_seconds_median"])
        one_shot = min(available, key=lambda group: group["with_startup_seconds_median"])
        profile_summary.append({
            "profile": profile, "table": winner["table"], "rows": winner["expected_rows"],
            "baseline_n": baseline["n"] if baseline else None,
            "baseline_seconds": baseline["total_seconds_median"] if baseline else None,
            "observed_best_strategy": winner["strategy"], "observed_best_parallelism": winner["parallelism"],
            "best_n": winner["n"], "best_seconds": winner["total_seconds_median"],
            "best_min_seconds": winner["total_seconds_min"], "best_max_seconds": winner["total_seconds_max"],
            "steady_speedup": baseline["total_seconds_median"] / winner["total_seconds_median"] if baseline else None,
            "observed_best_with_startup_strategy": one_shot["strategy"],
            "observed_best_with_startup_parallelism": one_shot["parallelism"],
            "one_shot_n": one_shot["n"], "best_with_startup_seconds": one_shot["with_startup_seconds_median"],
            "baseline_with_startup_seconds": baseline["with_startup_seconds_median"] if baseline else None,
            "one_shot_speedup": baseline["with_startup_seconds_median"] / one_shot["with_startup_seconds_median"] if baseline else None,
        })
    scaling_chart(groups, selected, args.output)
    summary = {
        "generated_utc": datetime.now(timezone.utc).isoformat(), "verified_completed_runs": len(runs),
        "aggregated_groups": len(groups), "input_directories": [str(path) for path in args.input],
        "included_experiment_names": include_patterns,
        "metric": "total_seconds = planning_seconds + scan_seconds; worker startup excluded",
        "one_shot_metric": "with_startup_seconds = planning_seconds + scan_seconds + worker_startup_seconds per individual run, aggregated afterward. Metadata/reference validation and EXPLAIN remain excluded.",
        "uncertainty": "Median/min/max of actual completed runs; n is reported, no confidence intervals or extrapolation",
        "worker_balance_semantics": "Shares sum actual COPY bytes or rows assigned to each worker across all its chunks. Empty means zero rows. Service-time imbalance is max(sum chunk seconds per worker) / mean across P workers, including empty workers; it is not CPU utilization. Binary COPY framing is included in byte shares.",
        "plot_selection": "Largest expected_rows per profile; ties prefer more Rust release runs. Different tables/row counts never pool. Best strategy bar chooses smallest observed median among actually measured P in the selected cohort.",
        "selected_fixtures": {key: {"table": value[0], "expected_rows": value[1]} for key, value in selected.items()},
        "warnings": warnings, "skipped": skipped, "experiments": experiments,
        "groups": groups, "best_observed_rust_release": best,
        "best_observed_with_worker_startup": best_one_shot,
        "profile_summary": profile_summary,
        "worker_balance": balance_groups,
    }
    (args.output / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    write_csv(args.output / "summary.csv", groups)
    write_csv(args.output / "completed-runs.csv", runs)
    write_csv(args.output / "best-observed-rust-release.csv", best)
    write_csv(args.output / "best-observed-with-startup.csv", best_one_shot)
    write_csv(args.output / "profile-summary.csv", profile_summary)
    write_csv(args.output / "worker-balance.csv", balance_groups)
    print(json.dumps({"runs": len(runs), "groups": len(groups), "warnings": warnings, "skipped": skipped,
                      "output": str(args.output)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
