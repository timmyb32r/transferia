#![allow(dead_code)]

#[path = "crates/transferia-connector-postgres/src/connectors/postgres/src_batch/planner.rs"]
mod v4;
#[path = "v5-planner.rs"]
mod v5;

use std::num::NonZeroU32;
use std::time::Instant;

#[derive(Clone, Debug)]
struct Case {
    pages: u64,
    rows: Option<f64>,
    bytes_per_row: Option<f64>,
    latency: f64,
    cap: Option<u32>,
    observed: usize,
    columns: u32,
    index_cuts: u32,
    correlation: Option<f64>,
    native: bool,
    guarded_heap: bool,
}

#[derive(Debug, PartialEq)]
struct Cost {
    // Bitwise equality includes every public cost component, not merely its
    // printed rounded value or selected total.
    bits: [u64; 9],
    critical: Option<(u64, u64)>,
}

#[derive(Debug, PartialEq)]
struct Candidate {
    strategy: &'static str,
    lanes: u32,
    parts: u32,
    eligible: bool,
    reason: &'static str,
    cost: Option<Cost>,
}

#[derive(Debug, PartialEq)]
struct Decision {
    strategy: &'static str,
    lanes: u32,
    parts: u32,
    cap: Option<u32>,
    reason: &'static str,
    candidates: Vec<Candidate>,
}

macro_rules! capture {
    ($decision:expr) => {{
        let d = $decision;
        Decision {
            strategy: d.strategy().label(), lanes: d.lanes(), parts: d.initial_parts(),
            cap: d.max_parts(), reason: d.reason(),
            candidates: d.candidates().iter().map(|c| Candidate {
                strategy: c.strategy.label(), lanes: c.lanes, parts: c.parts,
                eligible: c.eligible, reason: c.reason,
                cost: c.cost.as_ref().map(|v| Cost {
                    bits: [v.heap_seconds, v.row_seconds, v.output_seconds, v.setup_seconds,
                        v.coordination_seconds, v.planning_seconds, v.total_seconds,
                        v.heap_passes, v.largest_output_fraction].map(f64::to_bits),
                    critical: v.critical_range.map(|r| (r.heap_pages(), r.output_fraction().to_bits())),
                }),
            }).collect(),
        }
    }};
}

fn weights(kind: usize) -> Vec<f64> {
    match kind {
        1 => vec![1.0; 16],
        2 => { let mut w = vec![0.0; 16]; w[15] = 100.0; w },
        3 => { let mut w = vec![0.0; 16]; w[7] = 100.0; w },
        4 => vec![0.0, 1.0, 0.0, 19.0, 0.0, 2.0, 0.0, 3.0],
        _ => panic!("no observation weights for UniformPrior"),
    }
}

fn inputs(case: &Case) -> Result<(v4::TableFacts, v5::TableFacts), String> {
    let output = case.bytes_per_row.map(|width| width * case.rows.unwrap_or(case.pages as f64 * 32.0));
    let (old_distribution, new_distribution) = if case.observed == 0 {
        (None, v5::OutputDistribution::UniformPrior)
    } else {
        let sample_pages = case.pages.min(16);
        (Some(v4::PhysicalDistribution::new(weights(case.observed), 1600, sample_pages).map_err(|e| e.to_string())?),
         v5::OutputDistribution::Observed(v5::PhysicalDistribution::new(weights(case.observed), 1600, sample_pages).map_err(|e| e.to_string())?))
    };
    let old = v4::TableFacts::try_from(v4::RawTableFacts {
        physical_access: if case.guarded_heap { v4::PhysicalAccess::GuardedHeap } else { v4::PhysicalAccess::CompleteQueryOnly },
        native_tid_ranges: case.native, heap_pages: case.pages, block_bytes: 8192,
        estimated_rows: case.rows, estimated_output_bytes: output,
        metadata_seconds: 0.017, request_seconds: case.latency,
        indexed_cuts: case.index_cuts, index_correlation: case.correlation,
        physical_distribution: old_distribution,
        rates: v4::CostRates::priors_for_columns(NonZeroU32::new(case.columns).unwrap()),
    }).map_err(|e| e.to_string())?;
    let new = v5::TableFacts::try_from(v5::RawTableFacts {
        physical_access: if case.guarded_heap { v5::PhysicalAccess::GuardedHeap } else { v5::PhysicalAccess::CompleteQueryOnly },
        native_tid_ranges: case.native, heap_pages: case.pages, block_bytes: 8192,
        estimated_rows: case.rows, estimated_output_bytes: output,
        metadata_seconds: 0.017, request_seconds: case.latency,
        indexed_cuts: case.index_cuts, index_correlation: case.correlation,
        output_distribution: new_distribution,
        rates: v5::CostRates::priors_for_columns(NonZeroU32::new(case.columns).unwrap()),
    }).map_err(|e| e.to_string())?;
    Ok((old, new))
}

fn check(case: &Case, forced: Option<(usize, u32)>) -> Result<usize, String> {
    let (old, new) = inputs(case)?;
    let old_constraints = v4::Constraints::new(case.cap.and_then(NonZeroU32::new));
    let new_constraints = v5::Constraints::new(case.cap.and_then(NonZeroU32::new));
    let (left, right) = if let Some((strategy, parts)) = forced {
        let old_strategy = [v4::Strategy::Single, v4::Strategy::Ctid, v4::Strategy::WeightedCtid, v4::Strategy::Indexed, v4::Strategy::HashCtid][strategy];
        let new_strategy = [v5::Strategy::Single, v5::Strategy::Ctid, v5::Strategy::WeightedCtid, v5::Strategy::Indexed, v5::Strategy::HashCtid][strategy];
        (v4::decide_for_evaluation(old, old_constraints, old_strategy, NonZeroU32::new(parts).unwrap()).map(|d| capture!(d)),
         v5::decide_for_evaluation(new, new_constraints, new_strategy, NonZeroU32::new(parts).unwrap()).map(|d| capture!(d)))
    } else {
        (v4::decide(old, old_constraints).map(|d| capture!(d)), v5::decide(new, new_constraints).map(|d| capture!(d)))
    };
    match (left, right) {
        (Ok(left), Ok(right)) if left == right => Ok(left.candidates.len()),
        (Err(left), Err(right)) if left.to_string() == right.to_string() => Ok(0),
        (left, right) => Err(format!("case={case:?}\nforced={forced:?}\nv4={left:?}\nv5={right:?}")),
    }
}

fn main() {
    assert!(!cfg!(debug_assertions), "replay must be compiled with rustc -O");
    let started = Instant::now();
    let mut cases = Vec::new();
    for pages in [0, 1, 31, 2048, 65_536] {
        for rows in [None, Some(0.0), Some(100.0), Some(1_000_000.0)] {
            for bytes_per_row in [None, Some(0.0), Some(8.0), Some(4096.0)] {
                for latency in [0.0001, 0.005, 0.025, 0.1] {
                    for cap in [Some(1), Some(2), Some(8), Some(32), None] {
                        for observed in 0..5 {
                            if pages == 0 && observed != 0 { continue; }
                            cases.push(Case { pages, rows, bytes_per_row, latency, cap, observed,
                                columns: 8, index_cuts: 0, correlation: None, native: true, guarded_heap: true });
                        }
                    }
                }
            }
        }
    }
    let matrix_count = cases.len();
    // Separate finite capability/rate matrix avoids an unnecessarily huge
    // Cartesian product while covering every eligibility branch and key cuts.
    for observed in 0..5 {
        for columns in [1, 26, 105] {
            for (index_cuts, correlation) in [(0, None), (3, Some(-1.0)), (31, Some(0.0)), (100, Some(1.0))] {
                for (native, guarded_heap) in [(true, true), (false, true), (true, false)] {
                    for cap in [Some(1), Some(8), Some(32), None] {
                        cases.push(Case { pages: 20_000, rows: Some(2_000_000.0), bytes_per_row: Some(512.0),
                            latency: 0.012, cap, observed, columns, index_cuts, correlation, native, guarded_heap });
                    }
                }
            }
        }
    }
    let mut mismatches = 0;
    let mut candidate_comparisons = 0;
    let mut uniform = 0;
    let mut observed = 0;
    for case in &cases {
        if case.observed == 0 { uniform += 1; } else { observed += 1; }
        match check(case, None) {
            Ok(count) => candidate_comparisons += count,
            Err(error) => {
                mismatches += 1;
                if mismatches <= 10 { println!("MISMATCH\n{error}"); }
            }
        }
    }
    let mut forced_count = 0;
    for observed in 0..5 {
        for cap in [Some(1), Some(8), None] {
            let case = Case { pages: 2048, rows: Some(100_000.0), bytes_per_row: Some(1024.0),
                latency: 0.005, cap, observed, columns: 26, index_cuts: 15,
                correlation: Some(0.5), native: true, guarded_heap: true };
            for strategy in 0..5 {
                for parts in [1, 2, 4, 8, 16, 32] {
                    forced_count += 1;
                    match check(&case, Some((strategy, parts))) {
                        Ok(count) => candidate_comparisons += count,
                        Err(error) => {
                            mismatches += 1;
                            if mismatches <= 10 { println!("MISMATCH\n{error}"); }
                        }
                    }
                }
            }
        }
    }
    println!("matrix_automatic_cases={matrix_count}");
    println!("capability_rate_automatic_cases={}", cases.len() - matrix_count);
    println!("uniform_prior_automatic_cases={uniform}");
    println!("observed_automatic_cases={observed}");
    println!("forced_cases_including_rejected_constraints={forced_count}");
    println!("total_case_pairs={}", cases.len() + forced_count);
    println!("exact_candidate_comparisons={candidate_comparisons}");
    println!("mismatches={mismatches}");
    println!("elapsed_seconds={:.6}", started.elapsed().as_secs_f64());
    println!("comparison=bitwise_f64_full_decision_and_candidates_or_exact_error");
    println!("scope=matched_pure_policy_inputs_only; excludes_UnobservedConcentration_and_adapter_IO_and_end_to_end_timing");
    if mismatches != 0 { std::process::exit(1); }
}
