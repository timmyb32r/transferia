# PostgreSQL snapshot planner evidence — 2026-09-21

Base Git revision: **5e5fd608d6dc572d0c1c68ce10e867941d26275b**.

All six predeclared original v6 cases completed: four passes, one inconclusive
result and one regression. Implementation and focused correctness checks exist;
**the agreed 5% performance acceptance has not passed**.
The archived v6 benchmark sources and timings **precede the final native SQL
`search_path` hardening**. They do not establish performance acceptance for the
later hardened implementation. Keep failed and inconclusive cohorts. Do not
pool revisions or replace a failed result with a later result silently.

Each completed v6 case contains 31 preselected paired rounds. Exact total-time
medians and the evaluator's unchanged statistical verdicts are:

| Original case | Auto (s) | Best measured candidate | Best (s) | Auto / best | Verdict |
| --- | ---: | --- | ---: | ---: | --- |
| Empty-prefix bloat | 0.200447477 | hash P8 | 0.156711576 | 1.2790853242392255 | regression |
| Numeric | 0.438150202 | CTID P8 | 0.418590571 | 1.0467273568854467 | inconclusive |
| TOAST width skew | 0.325578464 | hash P8 | 0.314357318 | 1.0356955138547148 | pass |
| Logs | 0.655097772 | CTID P8 | 0.641226996 | 1.021631615771835 | pass |
| ClickBench | 0.764632130 | CTID P8 | 0.757791094 | 1.0090276014777233 | pass |
| Numeric key skew | 0.411827758 | CTID P8 | 0.413285627 | 0.9964724904406124 | pass |

Numeric's point estimate is within 5%, but the statistical evidence remains
inconclusive. Empty-prefix bloat fails the acceptance target.

## Contents and provenance

- `sources/`: exact v4/v5/v6 source tarballs captured for the release runs.
  These are small source overlays, **not complete repository checkouts**.
  Apply one to a fresh checkout of the base revision to recover its benchmark
  sources. They omit UI artifacts and are not complete overlays for rerunning
  every implementation check; use the final implementation overlay for that.
- `raw/`: unmodified completed report JSON, separated by revision/cohort.
  Per-run timings, server/client settings, source and binary Murmur3-128
  fingerprints, candidate eligibility and projected type OIDs remain there.
- `summary.json`: exact median timings, recorded gate labels, sample counts,
  selected plans and links to every completed report. Labels are copied from
  the Rust evaluator; the summary does not rerun or weaken the statistical gate.
- `verification/`: focused compiler/test logs, including a historical failure.
- `policy-replay/`: Rust sources and output for the bounded v4/v5 policy replay;
  no compiled executable is included.
- `summarize.py`: standard-library-only bookkeeping to refresh the sidecar
  after copying additional completed reports into `raw/`.

v2/v3 used native binary `COPY (SELECT *)`; their NUMERIC representation and
server encoding work differ from the production reader. They are exploratory
history and are not packaged as production acceptance results. v4 onward use
the exact production snapshot projection, including NUMERIC-to-text, and
report schema version 3. v4 added weighted observations; v5 added the
information-value decision for dominant external storage. v6 adds exact
integer/NUMERIC histogram cuts in the first metadata query, single-charged
boundary costs and an explicitly uncertain type-projection processing prior.
The v6 source tarball is the pre-hardening benchmark snapshot, not the final
implementation overlay. Subsequent SQL qualification is covered by the later
focused correctness log, not by these v6 timing reports.

The SQL analogue fixtures are deliberately separate datasets. In particular,
`profiles.sql` uniform numeric and derived profiles use **BIGINT**, while the
original generator's eight numeric columns are **NUMERIC(20,0)**. The SQL
analogues do not reproduce the original text-conversion cost or exact bloat
timings. Original-case reports here read the preloaded generator tables via
`--table`. Their preparation material is already in the repository at
`docs/research/pg-snapshot-benchmark-2026-09-20/reproduction.zip`; the larger
archive is not duplicated here. The histogram E2E checks correctness, not
performance equivalence to either dataset family.

## Measurement contract

All timed database measurements were made by the Rust release evaluator.
Each listed production cohort preselected 31 randomized paired rounds and an
eight-part ceiling. Auto competes with every eligible strategy over an
independent part grid and the model's proposed counts. Weighted applicability
is probed independently if necessary; each timed weighted run pays again for
its required observation. Ordinary Auto is never given that extra observation.

Timing covers production planning, actual projected binary COPY, the production
queue and checked SQL completion, with immediate discard acknowledgements.
It excludes Arrow decoding and destinations. Shared snapshot export, reference
COUNT, projection/applicability preflight and report writes are excluded.
Cache state is uncontrolled after reference reads; no source CPU, physical I/O
or cache residency was measured.

Pass requires one-sided exact sign-test evidence for every candidate at the
1.05 ratio threshold, plus observed Auto/best median time at most 1.05.
Regression uses Holm correction within each table and a significance budget
split across the invocation's tables. Ties/insufficient evidence are
inconclusive. Independent round signs are assumed. Separate `--table` commands
are separate inference families, not one joint 95% regression statement.
Do not append rounds or restart unchanged experiments until they pass.

## Recorded command forms

Run from the appropriate source-overlay checkout with connection settings
provided privately through the documented PG environment variables. No
credentials or host values are needed in this archive. Commands below are
normalized reproducibility forms reconstructed from reports/logs, rather than
a claim to preserve the original shell environment or literal shell history.

```sh
cargo build --release -p transferia-connector-postgres --example snapshot_planner_benchmark

./target/release/examples/snapshot_planner_benchmark --schema public --table pgsnap_numeric_bloat --case-id original_bloat --max-parts 8 --repetitions 31 --output target/planner-results
./target/release/examples/snapshot_planner_benchmark --schema public --table pgsnap_numeric_width_skew --case-id original_toast --max-parts 8 --repetitions 31 --output target/planner-results
./target/release/examples/snapshot_planner_benchmark --schema public --table pgsnap_numeric --case-id original_numeric --max-parts 8 --repetitions 31 --output target/planner-results
./target/release/examples/snapshot_planner_benchmark --schema public --table pgsnap_transfer_logs --case-id original_logs --max-parts 8 --repetitions 31 --output target/planner-results
./target/release/examples/snapshot_planner_benchmark --schema public --table pgsnap_clickbench --case-id original_clickbench --max-parts 8 --repetitions 31 --output target/planner-results
./target/release/examples/snapshot_planner_benchmark --schema public --table pgsnap_numeric_skew --case-id original_key_skew --max-parts 8 --repetitions 31 --output target/planner-results

cargo test -p transferia-connector-postgres --lib --test e2e_snapshot_planner
just check-affected
```

The SQL analogue corpus uses a separate fresh schema and explicit `--prepare`;
it must keep distinct case IDs. All fixture preparation is outside timing.
The source fixture README contains its preparation and counterexample recipe.
The replay README preserves its exact `rustc -O` invocation. Standalone v6
policy checks used the same std-only planner with Rust's test harness:

```sh
rustc --edition=2021 --test crates/transferia-connector-postgres/src/connectors/postgres/src_batch/planner.rs -o target/planner-policy-tests
./target/planner-policy-tests
```

## Verification chronology

Saved v4 logs record 191 library and 14 planner-target tests passing; v5 records
197 and 14. `v6-tests.log` records 204 library passes and a historical E2E
failure caused by the test fixture's `anyarray` histogram assignment, not a
reported production-data failure. Preserve it. After the fixture was corrected,
`v6-e2e-final.log` records all 14 target tests passing, including the added
histogram helper inside the existing exactness test. No test was dropped.
`v6-standalone-policy.log` records 28 pure-policy test passes, and
`check-affected-v6.log` records the compile-only affected-package check for that
revision. After native SQL `search_path` hardening,
`final-hardened-tests.log` records 205 library and 14 planner-target tests
passing. Its production source differs from the archived v6 timing source;
correctness results do not transfer the performance verdict. `final-check-affected.log` records the hardened-tree compile-only gate passing
in 10.34 seconds; `final-affected-plan.log` preserves its selected packages.
These are focused checks, not a workspace release gate.

The v4/v5 replay compared 7,890 matched policy inputs and 38,295 candidate
comparisons with zero differences, including bitwise floating cost fields.
It excludes the new uncertainty branch, SQL I/O and end-to-end timing; it does
not transfer performance acceptance from one revision to another.

To independently recompute the summary from the unchanged archived reports,
run the included bookkeeping script:

```sh
python3 summarize.py
```

The benchmark loop returned failure because the retained regression and
inconclusive case did not meet acceptance. No extra rounds were appended.
The complete implementation overlay and manifest include the final hardening;
apply that overlay to the base revision for the focused implementation checks.
Use the separate v6 overlay to reproduce the measured version.
