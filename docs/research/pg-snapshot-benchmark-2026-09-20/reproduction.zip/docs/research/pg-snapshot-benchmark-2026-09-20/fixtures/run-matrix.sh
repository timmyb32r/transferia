#!/usr/bin/env bash
set -euo pipefail
base=target/benchmarks/pg-snapshot-2026-09-20
binary="${PG_SNAPSHOT_BENCHMARK_BIN:-scripts/pg-snapshot-benchmark/target/release/pg-snapshot-benchmark}"
for profile in numeric numeric_skew transfer_logs clickbench numeric_bloat numeric_width_skew; do
  key=column_1
  if [[ "$profile" == transfer_logs ]]; then key=_system_offset; fi
  if [[ "$profile" == clickbench ]]; then key=WatchID; fi
  printf 'Starting Rust release: %s\n' "$profile"
  "$binary" --table "public.pgsnap_$profile" --key "$key" \
    --strategies single,equal,quantile,sample,stats,modulo,hash,ctid,ctid_queue,keyset \
    --parallelism 1,2,4,8 --repetitions 3 --max-minutes 10 --explain \
    --output "$base/rust-$profile" > "$base/rust-$profile.log" 2>&1 || {
      tail -n 25 "$base/rust-$profile.log"
      exit 1
    }
  printf 'Completed Rust release: %s\n' "$profile"
done
