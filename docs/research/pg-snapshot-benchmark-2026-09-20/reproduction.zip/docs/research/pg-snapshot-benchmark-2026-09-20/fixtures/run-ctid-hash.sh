#!/usr/bin/env bash
set -euo pipefail
base=target/benchmarks/pg-snapshot-2026-09-20
binary="${PG_SNAPSHOT_BENCHMARK_BIN:-scripts/pg-snapshot-benchmark/target/release/pg-snapshot-benchmark}"
for profile in numeric_skew numeric_bloat numeric_width_skew; do
  "$binary" --table "public.pgsnap_$profile" --key column_1 \
    --strategies hash,hash_ctid,ctid,weighted_ctid_linear --parallelism 4,8,16 --repetitions 3 \
    --max-minutes 5 --explain --output "$base/rust-ctidhash-$profile" \
    > "$base/rust-ctidhash-$profile.log" 2>&1 || { tail -n 25 "$base/rust-ctidhash-$profile.log"; exit 1; }
  printf 'Completed CTID hash comparison: %s\n' "$profile"
done
