# v4 / v5 pure-policy replay

Result: **7,890 case pairs; 38,295 exact candidate comparisons; zero differences**.
The Rust replay itself took 0.259089 seconds. This is verification runtime, not
a PostgreSQL performance measurement.

Compiled with `rustc 1.96.0 (ac68faa20 2026-05-25) (Homebrew)`:

```sh
rustc --edition=2024 -O target/benchmarks/pg-snapshot-planner/policy-replay/replay.rs -o target/benchmarks/pg-snapshot-planner/policy-replay/replay
target/benchmarks/pg-snapshot-planner/policy-replay/replay > target/benchmarks/pg-snapshot-planner/policy-replay/report.txt
```

The archived v4 module is under this directory's `crates/` subtree. The exact
v5 module compiled by this run is `v5-planner.rs`; `cmp` against the production
module succeeded immediately after the run. `replay.rs` defines the entire
matrix, and `report.txt` contains its output. These files are ignored artifacts;
no production source was changed by this verification.

The main Cartesian matrix varies heap pages (0, 1, 31, 2048, 65536), unknown /
zero / 100 / one million estimated rows, unknown / zero / 8 / 4096 bytes per
row, 0.1 / 5 / 25 / 100 ms request latency, and maximum parts 1 / 2 / 8 / 32 /
uncapped. It compares former missing observations with `UniformPrior`, plus
observed uniform, tail, middle and mixed physical histograms. Observations on
zero-page heaps are omitted because their construction is invalid.

A separate matrix varies 1 / 26 / 105 columns, indexed-cut availability and
correlation, native-TID support and physical access eligibility. There are 7,440
automatic comparisons: 1,744 `UniformPrior` and 5,696 observed. Another 450
forced-strategy cases include 219 accepted plans and 231 identically rejected
constraints.

Comparisons include selected strategy, lanes, initial parts, maximum parts,
decision/candidate reasons, eligibility, and every public cost component using
`f64::to_bits`, including critical-range page count and output fraction.

This proves equivalence over the recorded **matched pure-policy inputs**. It
does not exercise the new `UnobservedConcentration` branch, SQL observation
decisions, database I/O, concurrency, destination behavior or end-to-end timing.
Retained v4 PostgreSQL measurements must keep their original cohort provenance.
