#!/usr/bin/env bash
set -euo pipefail
base=target/benchmarks/pg-snapshot-2026-09-20
binary="${PG_SNAPSHOT_BENCHMARK_BIN:-scripts/pg-snapshot-benchmark/target/release/pg-snapshot-benchmark}"
for profile in numeric clickbench numeric_bloat numeric_width_skew; do
  key=column_1
  if [[ "$profile" == clickbench ]]; then key=WatchID; fi
  "$binary" --table "public.pgsnap_$profile" --key "$key" \
    --strategies equal,ctid,hash,modulo,weighted_ctid --parallelism 8 --repetitions 1 \
    --max-minutes 3 --explain-analyze --output "$base/rust-diagnostic-$profile" \
    > "$base/rust-diagnostic-$profile.log" 2>&1 || { tail -n 25 "$base/rust-diagnostic-$profile.log"; exit 1; }
  printf 'Completed EXPLAIN ANALYZE diagnostics: %s\n' "$profile"
done
