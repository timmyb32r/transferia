#!/usr/bin/env python3
"""Summarize completed Rust release reports; this script runs no benchmarks."""
import collections
import datetime
import json
import math
import pathlib
import statistics

ROOT = pathlib.Path(__file__).resolve().parent
BASE_REVISION = "5e5fd608d6dc572d0c1c68ce10e867941d26275b"
cases = []
for path in sorted((ROOT / "raw").glob("**/*.json")):
    report = json.loads(path.read_text())
    repetitions = report["repetitions"]
    for case in report["cases"]:
        groups = collections.defaultdict(list)
        for run in case["runs"]:
            groups[run["variant"]].append(run)
        for variant, runs in groups.items():
            assert sorted(run["round"] for run in runs) == list(range(repetitions)), (path, variant)
            assert all(run["rows"] == case["expected_rows"] for run in runs), (path, variant)
            assert all(math.isfinite(run["total_seconds"]) and run["total_seconds"] > 0 for run in runs)

        def aggregate(variant):
            runs = groups[variant]
            plans = collections.Counter((r["selected_strategy"], r["lanes"], r["parts"]) for r in runs)
            return {
                "variant": variant,
                "samples": len(runs),
                "median_total_seconds": statistics.median(r["total_seconds"] for r in runs),
                "median_planning_seconds": statistics.median(r["planning_seconds"] for r in runs),
                "median_startup_seconds": statistics.median(r["startup_seconds"] for r in runs),
                "median_scan_seconds": statistics.median(r["scan_seconds"] for r in runs),
                "plans": [{"strategy": strategy, "lanes": lanes, "initial_parts": parts, "runs": count}
                          for (strategy, lanes, parts), count in sorted(plans.items())],
            }

        automatic = aggregate("auto")
        best = aggregate(case["gate"]["best_measured_candidate"])
        regret = automatic["median_total_seconds"] / best["median_total_seconds"]
        assert math.isclose(regret, case["gate"]["median_time_regret"], rel_tol=1e-12)
        cases.append({
            "cohort": path.parent.name,
            "report": str(path.relative_to(ROOT)),
            "started_unix": report["started_unix"],
            "id": case["id"],
            "schema": case["schema"], "table": case["table"],
            "rows": case["expected_rows"], "columns": case["columns"],
            "repetitions": repetitions,
            "variants": len(groups), "timed_runs": len(case["runs"]),
            "maximum_parts": report["maximum_parts"],
            "copy_projection": case.get("copy_projection", report.get("copy_projection")),
            "report_schema_version": report["schema_version"],
            "auto": automatic, "best_measured": best,
            "median_time_regret": case["gate"]["median_time_regret"],
            "verdict": case["gate"]["verdict"],
            "statistical_method": case["gate"]["method"],
            "regression_family_count": case["gate"]["regression_family_count"],
            "binary_murmur3_x64_128": report["binary_murmur3_x64_128"],
        })

verification = []
for path in sorted((ROOT / "verification").glob("*.log")):
    lines = path.read_text().splitlines()
    results = [line for line in lines if line.startswith("test result:") or "group completed" in line]
    verification.append({"log": str(path.relative_to(ROOT)), "recorded_results": results})

expected_v6 = {"original_bloat", "original_numeric", "original_toast", "original_logs", "original_clickbench", "original_key_skew"}
v6 = [case for case in cases if case["cohort"] == "v6-original-results"]
v6_complete = len(v6) == len(expected_v6) and {case["id"] for case in v6} == expected_v6
v6_accepted = v6_complete and all(case["verdict"] == "pass" for case in v6)

summary = {
    "schema_version": 1,
    "base_git_revision": BASE_REVISION,
    "generated_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "publication_status": "complete v6 cohort" if v6_complete else "staging; v6 cases remain absent",
    "v6_source_scope": "archived benchmark sources before final native SQL search_path hardening",
    "v6_performance_accepted": v6_accepted,
    "final_tree_performance_acceptance": "not established; final native SQL search_path hardening is outside the measured v6 source",
    "v6_original_cases_pending": sorted(expected_v6 - {case["id"] for case in v6}),
    "v6_verdict_counts": dict(sorted(collections.Counter(case["verdict"] for case in v6).items())),
    "measurement_language": "Rust release; Python computes summaries only",
    "scope": "production projection/planning/COPY/queue with immediate discard acknowledgements; no Arrow decoding or destination",
    "cohort_counts": dict(sorted(collections.Counter(c["cohort"] for c in cases).items())),
    "completed_reports": len(list((ROOT / "raw").glob("**/*.json"))),
    "completed_cases": len(cases),
    "verdict_counts": dict(sorted(collections.Counter(c["verdict"] for c in cases).items())),
    "v6_original_cases_present": sorted(c["id"] for c in cases if c["cohort"] == "v6-original-results"),
    "cases": cases,
    "verification": verification,
}
(ROOT / "summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
print(f"summarized {len(cases)} completed cases: {summary['verdict_counts']}")
