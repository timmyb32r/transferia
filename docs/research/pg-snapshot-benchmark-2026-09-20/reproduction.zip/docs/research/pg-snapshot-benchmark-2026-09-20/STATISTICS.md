# PostgreSQL 17: где статистика помогает и где ей нельзя доверять

**Гистограмма — дешёвая подсказка для баланса, а не доказательство полноты,
уникальности ключа или одинаковой стоимости частей.** Универсальный planner
должен сохранять корректность при отсутствии, устаревании и ошибке статистики.
Это исследование документации и исходников без дополнительной нагрузки на БД.
Числа производительности берутся только из основного Rust RELEASE benchmark.

Локальное дерево PostgreSQL — **20devel**, commit
`9fa2c1ebd1757db6032cf81b53f973941be77747`. Ниже особенности, существенные для
сервера **17.11**, дополнительно сверены с официальной документацией 17 и
веткой `REL_17_STABLE`; новые возможности 20devel не приписываются PG17.

| Ситуация | Что известно | Решение для planner |
|---|---|---|
| Частые одинаковые значения, MCV | `histogram_bounds` исключает значения из `most_common_vals`; при покрытии всей популяции MCV гистограмма отсутствует. | Учитывать массы MCV отдельно. Большую группу одинакового split value делить дополнительным уникальным ключом, а не повторять одинаковую границу. [PG17 pg_stats](https://www.postgresql.org/docs/17/view-pg-stats.html). |
| NULL | `null_frac` — отдельная оценка; обычный предикат диапазона NULL не включает. | Отдельная NULL-часть либо явный полный порядок с документированной NULL-семантикой. В текущей performance-матрице split key проверяется как NOT NULL. [PG17 pg_stats](https://www.postgresql.org/docs/17/view-pg-stats.html). |
| Высокая кардинальность или редкие значения | `n_distinct` — оценка, иногда неточная даже при максимальном target; отрицательное число означает долю от числа строк. `-1` не заменяет ограничение UNIQUE. | Уникальность cursor key выводить из действительного ключевого контракта; оценки использовать только для размера задач. [ANALYZE](https://www.postgresql.org/docs/17/sql-analyze.html), [pg_stats](https://www.postgresql.org/docs/17/view-pg-stats.html). |
| Мало histogram bins, большие выбросы | Точность ограничена sample и target. Для обычного scalar-анализатора целевой минимум sample — `300 × target`, а не все строки. | Не выдавать bins за точные квантили; иметь очередь частей и корректный способ дробить оставшийся тяжёлый диапазон. [PG17 analyze.c](https://github.com/postgres/postgres/blob/REL_17_STABLE/src/backend/commands/analyze.c#L1750). |
| Строки/bytea большой длины | Стандартный PG17-анализатор не включает varlena datums с сырым размером больше **1024 байт** в сравнение значений для обычных MCV/histogram. Проверка выполняется по detoasted размеру до дорогого detoast. Это не ограничение допустимых пользовательских значений. | Отсутствие histogram у длинного ключа не лечить усечением или хешированием данных. Использовать исходный серверный порядок, bounded sampling/keyset либо допустимый физический scan. [PG17 analyze.c](https://github.com/postgres/postgres/blob/REL_17_STABLE/src/backend/commands/analyze.c#L1670). |
| `STATISTICS 0`, ещё нет ANALYZE | Target 0 выключает сбор для столбца; MCV/histogram также могут отсутствовать из-за неподдерживаемых операторов. Повторный ANALYZE со старым target не обязан это исправить. | Отсутствие — нормальный результат discovery с явной причиной; выбирать другой способ. Не запускать полный ANALYZE автоматически ради одного snapshot. [ANALYZE](https://www.postgresql.org/docs/17/sql-analyze.html). |
| Статистика есть, но нет доступа | `pg_stats` проверяет SELECT на столбец и скрывает строки при активной для пользователя RLS. Extended stats имеют более строгую проверку роли владельца. | Не путать скрытую статистику с пустой таблицей; не обходить RLS ради планирования. Оценивать и читать то же разрешённое пользователю множество. [PG17 system_views.sql](https://github.com/postgres/postgres/blob/REL_17_STABLE/src/backend/catalog/system_views.sql#L256). |
| Security-barrier view, пользовательские operators | Некоторые оценки не используют значения статистики без нужных прав либо LEAKPROOF-оператора. В EXPLAIN это может выглядеть как обычная грубая оценка. | Не считать оценку строк надёжной только потому, что EXPLAIN успешен. [Planner statistics and security](https://www.postgresql.org/docs/17/planner-stats-security.html). |
| Составной ключ, корреляция столбцов | Одноколоночные гистограммы не описывают распределение tuple key. Extended `dependencies` не применяются к range conditions; поддерживаемые extended kinds не дают готовой универсальной tuple-гистограммы. | Получать составные границы серверным ORDER BY по полному ключу; statistics использовать как дополнительную оценку, не как замену корректного tuple cursor. [Planner statistics](https://www.postgresql.org/docs/17/planner-stats.html), [CREATE STATISTICS](https://www.postgresql.org/docs/17/sql-createstatistics.html). |
| Выражение вместо столбца, произвольный JOIN | Expression statistics относятся к определённому выражению; статистика базового столбца не описывает любую функцию от него. В PG17 extended statistics не используются для join selectivity. | Планировать фактическую выборку и выражение; произвольный SQL не превращать автоматически в простые диапазоны базовой таблицы. [CREATE STATISTICS](https://www.postgresql.org/docs/17/sql-createstatistics.html). |
| Строковый ключ, collation | Сравнение и ORDER BY зависят от серверной collation. Клиентский byte/Unicode-порядок может быть другим. | Передавать исходные typed boundaries и сравнивать на сервере тем же оператором/collation; не пересортировывать histogram в Rust как строки. [Collation support](https://www.postgresql.org/docs/17/collation.html). |
| SYSTEM sample и физически сгруппированные значения | SYSTEM выбирает блоки и все строки в выбранных блоках; это дешевле полного прохода BERNOULLI, но clustering ухудшает случайность выборки. | Оценивать фактически полученный sample; пустой/односторонний sample не объявлять равномерным. Сохранять открытые хвосты и ограничивать стоимость повторного sampling. [SELECT/TABLESAMPLE](https://www.postgresql.org/docs/17/sql-select.html). |
| Parent/leaf, partitioned/inherited table | `inherited` различает статистику собственной relation и иерархии. Изменения только в children не гарантируют своевременный auto-analyze parent. | Discovery физических leaves и выбор соответствующей статистики выполняются отдельно; не считать parent одним пространством CTID. [ANALYZE](https://www.postgresql.org/docs/17/sql-analyze.html). |
| Равное число строк, но разные payload sizes | TOAST может хранить данные сжатыми и вне heap. Равное количество heap pages или строк не означает равные переданные байты и detoast CPU. | Балансировать следующие части по наблюдаемым bytes/time, а не только по row count. При необходимости иметь отдельную оценку ширины именно выбранной проекции. [TOAST](https://www.postgresql.org/docs/17/storage-toast.html). |
| Bloat, низкая key/heap correlation | В модели PG17 TidRangeScan стоимость зависит от предполагаемых страниц/tuples; первая страница считается random access, следующие — sequential. Эта модель не измеряет конкретный cache/TOAST skew. | Проверять реальный access path и buffers. Для разреженного heap/index-only projection индекс может быть выгоднее; CTID — кандидат, не универсальный победитель. [PG17 costsize.c](https://github.com/postgres/postgres/blob/REL_17_STABLE/src/backend/optimizer/path/costsize.c#L1262). |

## Как использовать статистику безопасно

1. Сначала установить корректность: topology, права, snapshot, тип/порядок
   ключа, NULL и уникальный tie-breaker. Эти свойства не выводятся из histogram.
2. Читать доступную статистику как hint: histogram + MCV + null fraction,
   достаточно свежие row/page estimates, correlation, projection width.
3. Выбирать **серверные значения** границ; повторяющиеся cuts убирать, наружные
   хвосты оставлять открытыми. Для нестандартных типов нужен серверный comparator,
   а не сериализация в строку с последующей клиентской сортировкой.
4. Для missing/недостаточной статистики пробовать ограниченное sampling или
   индексный keyset. Не требовать полного COUNT/DISTINCT/точных квантилей перед
   каждым переносом: в harness это контроль эксперимента, не идеальный planner.
5. Сначала несколько небольших частей; по bytes/time уточнять размер будущих.
   Уже назначенные интервалы не менять. Повторное дробление сохраняет точное
   покрытие и непересечение; каждый task читает тот же snapshot.

Это проектный вывод из механизмов, а не измеренное доказательство эффективности
адаптивного алгоритма: в текущем Rust harness очередь статических частей.

## Pooler, master и snapshot

У transaction pooler серверное соединение закреплено за клиентом только на
время транзакции; session-level SET до BEGIN нельзя считать сохранённым.
Statement pooling не поддерживает нужные многокомандные транзакции. Наш путь
использует квалифицированные имена, BEGIN, затем SET LOCAL и импорт snapshot
до первого запроса читателя. Для pooler нужно отдельно проверить поддержку
используемого prepared-statement протокола. [PgBouncer features](https://www.pgbouncer.org/features.html).

Все readers и exporter должны использовать **одну БД на одном сервере** и
сохранять транзакции открытыми. Идентификатор export snapshot не является
переносимым cluster-wide checkpoint: PG хранит export локально и проверяет
совпадение database при import. Для этого benchmark маршрут закреплён за
master; автоматическое переключение на другой host/failover не может незаметно
продолжить старый epoch. Это ограничение проверенного маршрута, **не утверждение,
что PostgreSQL вообще запрещает экспорт на standby**.
[PG17 snapmgr.c](https://github.com/postgres/postgres/blob/REL_17_STABLE/src/backend/utils/time/snapmgr.c),
[snapshot synchronization](https://www.postgresql.org/docs/17/functions-admin.html#FUNCTIONS-SNAPSHOT-SYNCHRONIZATION-TABLE),
[SET TRANSACTION](https://www.postgresql.org/docs/17/sql-set-transaction.html).

## Предел доказательств

Функциональные проверки и их raw-результаты перечислены отдельно в
[EDGE-ANALYSIS.md](EDGE-ANALYSIS.md). В расширенном прогоне фактически проверены
missing statistics, `STATISTICS 0`, stale histogram после UPDATE/INSERT,
90% MCV с совпавшими quantile cuts, отсутствие histogram для ключей по 1506 B,
FORCE RLS с исчезновением строк `pg_stats`, NULL, дубликаты и typed/composite
границы. Например, устаревшая histogram [1,1000] при 1500 строках сохранила
только 900 строк при закрытых пределах; открытые хвосты вернули точные 1500.
При FORCE RLS физические 100 строк превратились в разрешённые 50, и оба способа
разбиения вернули именно эти 50, сохранив policy.

Bloat после удаления 90% строк и TOAST skew измерены **Rust release** в
[основной матрице](../../pg-snapshot-benchmark-2026-09-20.md): равные физические
интервалы не обеспечили баланс. Эти результаты относятся к прогретым данным,
помещающимся в RAM, и не доказывают поведение холодного диска или многотерабайтных
таблиц. Отдельной проверки всех ошибок `n_distinct`, extended statistics,
пользовательских operator classes и всех collation не было. Рекомендованный
адаптивный selector остаётся проектом, а не реализованным универсальным решением.
