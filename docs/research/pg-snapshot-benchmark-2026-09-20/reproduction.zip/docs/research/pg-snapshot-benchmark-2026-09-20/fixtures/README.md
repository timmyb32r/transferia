# Воспроизведение данных PostgreSQL

Исходные три таблицы загружены настоящим источником `data_generator` и
PostgreSQL sink Transferia. SQL `generate_series` не заменяет генератор данных.
Три дополнительные таблицы — явно описанные производные fixtures для разных
видов перекоса. Таблицы из генератора сохраняются без изменений.

| Таблица в `public` | Строк | Что проверяет |
|---|---:|---|
| `pgsnap_numeric` | 2 000 000 | Восемь UInt64 → PostgreSQL `numeric(20,0)`; плотный возрастающий PK `column_1`. |
| `pgsnap_transfer_logs` | 1 000 000 | 26 полей, строки/числа/NULL; составной PK из четырёх `_system_*` полей. Для измерений добавлен индекс на `_system_offset`. |
| `pgsnap_clickbench` | 500 000 | 105 полей, переменная ширина, бинарные строки, даты; случайный `WatchID` первым в составном PK. |
| `pgsnap_numeric_skew` | 2 000 000 | Те же восемь полей; 90% строк попадают в первый 1% диапазона ключей. |
| `pgsnap_numeric_bloat` | 200 000 | Копия numeric после удаления первых 90% строк и обычного VACUUM; живые строки сосредоточены в последних 10% heap. |
| `pgsnap_numeric_width_skew` | 200 000 | Восемь числовых полей + явный `text payload`: первые 198 000 строк по 32 байта, последние 2 000 по 65 536 байт; внешний несжатый TOAST. |

Количество строк исходных таблиц подтверждается `load-results.json` и
`preparation-results.json` в каталоге исходных результатов. Для производных
таблиц SQL содержит отдельные проверки и вывод распределений. `row_datum_bytes`
из диагностики — размер PostgreSQL row datum; это **не** размер heap или COPY.
Фактически переданные байты фиксирует измерительный Rust harness.

## Загрузка из генератора

Команды выполняются из корня репозитория на машине с доступом к PostgreSQL.
Нужны `PGHOST`, `PGPASSWORD` и при необходимости `PGSSLROOTCERT` в окружении.
По умолчанию выбраны `PGDATABASE=db1`, `PGUSER=user1`, `PGPORT=6432`; TLS и
проверка сертификата включены. Пароля в шаблонах нет.

```sh
python3 docs/research/pg-snapshot-benchmark-2026-09-20/fixtures/render.py \
  --profile numeric --rows 2000000 --run target/debug/transferia
python3 docs/research/pg-snapshot-benchmark-2026-09-20/fixtures/render.py \
  --profile transfer_logs --rows 1000000 --run target/debug/transferia
python3 docs/research/pg-snapshot-benchmark-2026-09-20/fixtures/render.py \
  --profile clickbench --rows 500000 --run target/debug/transferia
```

`render.py` только собирает конфигурацию и запускает production Transferia.
Значения данных создаёт Rust-генератор. Можно указать другой готовый бинарник.
Сравнение способов чтения выполняется отдельным Rust harness, собранным в
`release`; загрузка fixtures не включена во время чтения.

`--run` передаёт секретную конфигурацию через stdin (`--config /dev/stdin`), без
записи файла и без пароля в аргументах. В окружении дочернего процесса
`PGPASSWORD` удалён. Альтернатива `--output` создаёт файл режима 0600; такой файл
нельзя включать в публичные артефакты.

После загрузки нужно дождаться нормального завершения CLI и проверить число
строк. Повторная загрузка того же диапазона создаст конфликт PK. `--table` и
`--start-row` позволяют явно выбрать другое имя или непересекающийся диапазон;
данный набор SQL предполагает стандартные имена и начало с нуля.

## Производные fixtures и статистика

В новой тестовой БД, после завершения трёх загрузок, выполнить последовательно:

```sh
psql -v ON_ERROR_STOP=1 -f docs/research/pg-snapshot-benchmark-2026-09-20/fixtures/prepare.sql
psql -v ON_ERROR_STOP=1 -f docs/research/pg-snapshot-benchmark-2026-09-20/fixtures/prepare-physical-skew.sql
psql -v ON_ERROR_STOP=1 -f docs/research/pg-snapshot-benchmark-2026-09-20/fixtures/prepare-width-skew.sql
psql -v ON_ERROR_STOP=1 -f docs/research/pg-snapshot-benchmark-2026-09-20/fixtures/diagnose-fixtures.sql
```

Создающие SQL завершаются ошибкой при уже существующей таблице или индексе.
Они не удаляют и не перезаписывают прежние данные. Для уже созданных fixtures
повторяется только `diagnose-fixtures.sql`; повторная загрузка не нужна.

`prepare.sql` добавляет индекс logs, обновляет статистику и создаёт перекос
ключей. Для N=2 000 000 нижние 1 800 000 ключей остаются прежними, остальные
преобразованы формулой `1 800 000 + (old_key - 1 800 000 + 1) * 891`; максимум
равен 180 000 000. Отображение однозначно, PK сохраняется.

`prepare-physical-skew.sql` копирует numeric в порядке ключа, удаляет первые
90% строк и выполняет `VACUUM (ANALYZE)` без FULL. Живой хвост не позволяет
отрезать пустые страницы в начале. Отключение autovacuum относится только к
этой производной таблице и сохраняет форму эксперимента.

`prepare-width-skew.sql` перед вставкой задаёт `payload SET STORAGE EXTERNAL`,
поэтому большие тексты хранятся вне heap без TOAST-сжатия. Только текстовые
payload занимают 137 408 000 байт, около 131 MiB. Широкие строки расположены
рядом: равные количества строк не означают равное количество передаваемых байт.

SQL включает `\timing on`; подготовка и диагностика учитываются отдельно от
сравнения чтения. Локальная настройка schema находится в начале каждого SQL.
Второй индекс на ClickBench не нужен: `WatchID` уже первая колонка PK.
`all_arrow_datatypes` не используется: этот preset содержит типы, которые
PostgreSQL sink отклоняет при discovery.

## Запуск трёх серий измерений

Из корня репозитория собрать только отдельный измеритель:

```sh
cargo build --release --locked --manifest-path scripts/pg-snapshot-benchmark/Cargo.toml
mkdir -p target/benchmarks/pg-snapshot-2026-09-20
export PGPORT=6432 PGDATABASE=db1 PGUSER=user1 PGSSLMODE=verify-full
```

`PGHOST`, `PGPASSWORD` и доверенный `PGSSLROOTCERT` берутся из окружения.
Все wrappers по умолчанию запускают
`scripts/pg-snapshot-benchmark/target/release/pg-snapshot-benchmark`.
Если бинарник собран в другом каталоге, явно задать
`PG_SNAPSHOT_BENCHMARK_BIN=/absolute/path/to/pg-snapshot-benchmark`.
Сам измеритель отклоняет запуск debug-сборки.

Последовательно, без конкурирующей нагрузки между сериями:

```sh
bash docs/research/pg-snapshot-benchmark-2026-09-20/fixtures/run-matrix.sh
bash docs/research/pg-snapshot-benchmark-2026-09-20/fixtures/run-candidates.sh
bash docs/research/pg-snapshot-benchmark-2026-09-20/fixtures/run-ctid-hash.sh
```

| Wrapper | Отдельные каталоги результатов | Состав |
|---|---|---|
| `run-matrix.sh` | `rust-{profile}` | Шесть fixtures, десять исходных стратегий, P=1/2/4/8; `single` только P1. 666 прогонов. |
| `run-candidates.sh` | `rust-candidate-{profile}` | Шесть fixtures; CTID, CTID queue, stats, hash, исходный weighted CTID; P=8/16/32. 270 прогонов. |
| `run-ctid-hash.sh` | `rust-ctidhash-{profile}` | Три skew-fixtures; CTID, hash, hash(CTID), linear weighted CTID; P=4/8/16. 108 прогонов. |

В каждой комбинации три повторения; seed `20260920`, sample `1%`, до восьми
chunks на reader для стратегий с очередью. Эти параметры и фактические границы
сохранены в `events.jsonl`. Повторения используют тот же seed, поэтому сами по
себе не проверяют устойчивость к выбору другой случайной выборки.
Каталоги с существующими `events.jsonl` или `runs.csv` измеритель не перезаписывает;
для нового эксперимента нужно явно выбрать новое место для результатов.

Необязательная отдельная диагностика:

```sh
bash docs/research/pg-snapshot-benchmark-2026-09-20/fixtures/run-diagnostics.sh
```

Она делает дополнительные `EXPLAIN ANALYZE` после чтения; её результаты не
добавляются к трём сравнительным сериям. Подробности происхождения данных,
версий измерителя и повторного offline-анализа — в [PROVENANCE.md](../PROVENANCE.md).
