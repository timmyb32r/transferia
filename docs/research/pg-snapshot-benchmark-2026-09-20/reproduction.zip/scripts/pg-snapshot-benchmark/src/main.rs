use anyhow::{anyhow, bail, Context, Result};
use futures_util::{future::try_join_all, TryStreamExt};
use native_tls::{Certificate, TlsConnector};
use postgres_native_tls::MakeTlsConnector;
use serde_json::{json, Value};
use std::{collections::HashMap, env, fs::{self, File, OpenOptions}, io::Write, path::PathBuf, sync::{Arc, atomic::{AtomicUsize, Ordering}}, time::{Duration, Instant, SystemTime, UNIX_EPOCH}};
use tokio_postgres::{Client, Config, config::SslMode};

const STRATEGIES: &[&str] = &["single", "equal", "quantile", "sample", "stats", "modulo", "hash", "ctid", "ctid_queue", "keyset", "weighted_ctid", "hash_ctid", "weighted_ctid_linear"];

#[derive(Clone)]
struct Args {
    tables: Vec<String>, key: String, strategies: Vec<String>, parallelism: Vec<usize>,
    repetitions: usize, chunks_per_worker: usize, sample_percent: f64, seed: u64,
    max_minutes: f64, statement_timeout_ms: u64, lock_timeout_ms: u64,
    connect_timeout: u64, server_parallel_workers: usize, explain: bool, explain_analyze: bool, output: PathBuf,
}
impl Args {
    fn parse() -> Result<Self> {
        let mut values = HashMap::new();
        let mut tables = Vec::new();
        let mut explain = false;
        let mut explain_analyze = false;
        let mut input = env::args().skip(1);
        while let Some(key) = input.next() {
            if key == "--help" {
                println!("pg-snapshot-benchmark --table schema.table --key column --output NEW_DIRECTORY\n  --strategies single,equal,quantile,sample,stats,modulo,hash,ctid,ctid_queue,keyset,weighted_ctid,hash_ctid,weighted_ctid_linear\n  --parallelism 1,2,4,8 --repetitions 3 --chunks-per-worker 8\n  --sample-percent 1 --seed 20260920 --max-minutes 60 --explain\n  --statement-timeout-ms 180000 --lock-timeout-ms 5000 --connect-timeout 15\n  --server-parallel-workers 0 --explain-analyze (extra scans outside timing)\nConnection: PGHOST PGPORT PGDATABASE PGUSER PGPASSWORD PGSSLMODE PGSSLROOTCERT.\nRun a RELEASE build. This reads binary COPY into a bounded-memory Rust parser and discards payloads.");
                std::process::exit(0);
            }
            if key == "--explain" { explain = true; continue; }
            if key == "--explain-analyze" { explain_analyze = true; continue; }
            let value = input.next().with_context(|| format!("Missing value for {key}"))?;
            if key == "--table" { tables.push(value); } else { values.insert(key, value); }
        }
        let mut get = |name: &str, default: &str| values.remove(name).unwrap_or_else(|| default.to_string());
        let key = get("--key", "id");
        let strategies = get("--strategies", &STRATEGIES.join(",")).split(',').map(str::to_string).collect::<Vec<_>>();
        let parallelism = get("--parallelism", "1,2,4,8").split(',').map(str::parse).collect::<std::result::Result<Vec<usize>, _>>()?;
        let args = Self { tables, key, strategies, parallelism,
            repetitions: get("--repetitions", "3").parse()?, chunks_per_worker: get("--chunks-per-worker", "8").parse()?,
            sample_percent: get("--sample-percent", "1").parse()?, seed: get("--seed", "20260920").parse()?,
            max_minutes: get("--max-minutes", "60").parse()?, statement_timeout_ms: get("--statement-timeout-ms", "180000").parse()?,
            lock_timeout_ms: get("--lock-timeout-ms", "5000").parse()?, connect_timeout: get("--connect-timeout", "15").parse()?,
            server_parallel_workers: get("--server-parallel-workers", "0").parse()?, explain, explain_analyze,
            output: PathBuf::from(get("--output", "")) };
        if !values.is_empty() { bail!("Unknown arguments: {:?}", values.keys()); }
        if args.tables.is_empty() || args.output.as_os_str().is_empty() || args.parallelism.is_empty()
            || args.parallelism.contains(&0) || args.repetitions == 0 || args.chunks_per_worker == 0
            || !args.sample_percent.is_finite() || !(0.0 < args.sample_percent && args.sample_percent <= 100.0)
            || !args.max_minutes.is_finite() || args.max_minutes <= 0.0 || args.statement_timeout_ms == 0
            || args.lock_timeout_ms == 0 || args.connect_timeout == 0 { bail!("Invalid or missing benchmark arguments"); }
        if args.strategies.iter().any(|s| !STRATEGIES.contains(&s.as_str())) { bail!("Unknown strategy"); }
        Ok(args)
    }
}
fn identifier(value: &str) -> String { format!("\"{}\"", value.replace('"', "\"\"")) }
fn literal(value: &str) -> String { format!("'{}'", value.replace('\'', "''")) }
fn relation(table: &str) -> Result<String> {
    let parts = table.split('.').collect::<Vec<_>>();
    if parts.len() != 2 || parts.iter().any(|p| p.is_empty()) { bail!("Table must be schema.table"); }
    Ok(format!("{}.{}", identifier(parts[0]), identifier(parts[1])))
}
fn integer(value: &str) -> Result<i128> {
    let (whole, fraction) = value.split_once('.').unwrap_or((value, ""));
    if fraction.bytes().any(|b| b != b'0') { bail!("Nonintegral numeric boundary"); }
    whole.parse().context("Numeric boundary is not an exact i128 integer")
}
async fn connect(args: &Args, snapshot: Option<&str>) -> Result<Client> {
    let mut config = Config::new();
    config.host(&env::var("PGHOST").context("PGHOST required")?);
    config.port(env::var("PGPORT").unwrap_or_else(|_| "5432".into()).parse()?);
    config.user(&env::var("PGUSER").context("PGUSER required")?);
    config.dbname(&env::var("PGDATABASE").context("PGDATABASE required")?);
    if let Ok(password) = env::var("PGPASSWORD") { config.password(password); }
    config.connect_timeout(Duration::from_secs(args.connect_timeout));
    config.application_name("transferia_snapshot_benchmark_rust_release");
    let ssl_mode = env::var("PGSSLMODE").unwrap_or_else(|_| "verify-full".into());
    let mut tls = TlsConnector::builder();
    match ssl_mode.as_str() {
        "verify-full" => { config.ssl_mode(SslMode::Require); }
        "verify-ca" => { config.ssl_mode(SslMode::Require); tls.danger_accept_invalid_hostnames(true); }
        "require" => { config.ssl_mode(SslMode::Require); tls.danger_accept_invalid_certs(true); }
        "disable" => { config.ssl_mode(SslMode::Disable); }
        _ => bail!("Supported PGSSLMODE: verify-full, verify-ca, require, disable"),
    }
    if let Ok(path) = env::var("PGSSLROOTCERT") { tls.add_root_certificate(Certificate::from_pem(&fs::read(path)?)?); }
    let (client, connection) = config.connect(MakeTlsConnector::new(tls.build()?)).await?;
    tokio::spawn(async move { if let Err(error) = connection.await { eprintln!("PostgreSQL connection ended: {error}"); } });
    client.batch_execute("BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY").await?;
    if let Some(snapshot) = snapshot { client.batch_execute(&format!("SET TRANSACTION SNAPSHOT {}", literal(snapshot))).await?; }
    client.batch_execute(&format!("SET LOCAL statement_timeout = {}; SET LOCAL lock_timeout = {}; SET LOCAL max_parallel_workers_per_gather = {}; SET LOCAL jit = off", args.statement_timeout_ms, args.lock_timeout_ms, args.server_parallel_workers)).await?;
    Ok(client)
}

struct Output { events: File, csv: File }
impl Output {
    fn new(path: &PathBuf) -> Result<Self> {
        fs::create_dir_all(path)?;
        let events = OpenOptions::new().write(true).create_new(true).open(path.join("events.jsonl"))?;
        let mut csv = OpenOptions::new().write(true).create_new(true).open(path.join("runs.csv"))?;
        writeln!(csv, "{}", CSV_FIELDS.join(","))?;
        Ok(Self { events, csv })
    }
    fn write(&mut self, value: &Value) -> Result<()> {
        serde_json::to_writer(&mut self.events, value)?; writeln!(self.events)?; self.events.flush()?;
        if value["kind"] == "run" {
            let cells = CSV_FIELDS.iter().map(|field| {
                let text = match &value[*field] { Value::String(s) => s.clone(), Value::Null => String::new(), v => v.to_string() };
                format!("\"{}\"", text.replace('"', "\"\""))
            }).collect::<Vec<_>>();
            writeln!(self.csv, "{}", cells.join(","))?; self.csv.flush()?;
        }
        Ok(())
    }
}
const CSV_FIELDS: &[&str] = &["table", "strategy", "parallelism", "repetition", "run_id", "planning_seconds", "scan_seconds", "total_seconds", "worker_startup_seconds", "rows", "copy_payload_bytes", "rows_per_second", "mib_per_second", "chunks", "client_cpu_seconds", "chunk_max_seconds", "chunk_median_seconds", "chunk_rows_min", "chunk_rows_max", "expected_rows", "row_count_matches"];

struct Metadata { table: String, relation: String, key: String, key_type: String, rows: u64, minimum: Option<i128>, block_size: u64, value: Value }
async fn metadata(client: &Client, table: &str, args: &Args) -> Result<Metadata> {
    let relation = relation(table)?; let key = identifier(&args.key); let started = Instant::now();
    let info = client.query_one("SELECT c.relkind::text, pg_relation_size(c.oid), pg_total_relation_size(c.oid), current_setting('block_size')::bigint, EXISTS (SELECT FROM pg_inherits WHERE inhparent=c.oid), EXISTS (SELECT FROM pg_index WHERE indrelid=c.oid AND indisprimary), c.relpages, c.reltuples::float8, am.amname::text FROM pg_class c JOIN pg_am am ON am.oid=c.relam WHERE c.oid=$1::text::regclass", &[&relation]).await?;
    if info.get::<_, String>(0) != "r" || info.get::<_, bool>(4) || !info.get::<_, bool>(5) || info.get::<_,String>(8) != "heap" { bail!("Fixture must be an ordinary heap with a primary key and without children"); }
    let key_type: String = client.query_one("SELECT t.typname::text FROM pg_attribute a JOIN pg_type t ON t.oid=a.atttypid WHERE a.attrelid=$1::text::regclass AND a.attname=$2 AND NOT a.attisdropped", &[&relation, &args.key]).await?.get(0);
    if !["int2", "int4", "int8", "numeric"].contains(&key_type.as_str()) { bail!("Split column must be integer or integral numeric"); }
    let row = client.query_one(&format!("SELECT count(*)::text, count({key})::text, count(DISTINCT {key})::text, min({key})::text, max({key})::text, count(*) FILTER (WHERE {key} != trunc({key}::numeric))::text FROM ONLY {relation}"), &[]).await?;
    let rows: u64 = row.get::<_, String>(0).parse()?;
    if row.get::<_, String>(1).parse::<u64>()? != rows || row.get::<_, String>(2).parse::<u64>()? != rows || row.get::<_, String>(5) != "0" { bail!("Split column must be non-null, unique and exactly integral in this snapshot"); }
    let minimum = row.get::<_, Option<String>>(3).map(|s| integer(&s)).transpose()?;
    let maximum = row.get::<_, Option<String>>(4).map(|s| integer(&s)).transpose()?;
    let block_size = info.get::<_, i64>(3) as u64;
    let value = json!({"kind":"table", "table":table, "relation":relation, "key_sql":key, "split_key_type":key_type, "expected_rows":rows, "minimum":minimum.map(|v|v.to_string()), "maximum":maximum.map(|v|v.to_string()), "heap_bytes":info.get::<_,i64>(1), "total_bytes":info.get::<_,i64>(2), "block_size":block_size, "catalog_pages":info.get::<_,i32>(6), "catalog_rows":info.get::<_,f64>(7), "reference_count_seconds":started.elapsed().as_secs_f64()});
    Ok(Metadata { table: table.into(), relation, key, key_type, rows, minimum, block_size, value })
}
fn ranges(key: &str, mut cuts: Vec<i128>) -> Vec<String> {
    cuts.sort_unstable(); cuts.dedup();
    if cuts.is_empty() { return vec!["TRUE".into()]; }
    let mut predicates = vec![format!("{key} < {}", cuts[0])];
    for pair in cuts.windows(2) { predicates.push(format!("{key} >= {} AND {key} < {}", pair[0], pair[1])); }
    predicates.push(format!("{key} >= {}", cuts[cuts.len()-1])); predicates
}
async fn plan(client: &Client, metadata: &Metadata, strategy: &str, p: usize, args: &Args) -> Result<(Vec<String>, Value)> {
    let key = &metadata.key; let relation = &metadata.relation;
    if strategy == "single" || metadata.minimum.is_none() { return Ok((vec!["TRUE".into()], json!({}))); }
    match strategy {
        "equal" => {
            let row = client.query_one(&format!("SELECT min({key})::text, max({key})::text FROM ONLY {relation}"), &[]).await?;
            let min = integer(&row.get::<_,String>(0))?; let max = integer(&row.get::<_,String>(1))?;
            let width = max.checked_sub(min).and_then(|x| x.checked_add(1)).context("Key domain exceeds i128")?;
            let cuts = (1..p).map(|i| width.checked_mul(i as i128).and_then(|v|min.checked_add(v / p as i128)).context("Range boundary overflow")).collect::<Result<Vec<_>>>()?;
            Ok((ranges(key, cuts.clone()), json!({"cuts":cuts.iter().map(ToString::to_string).collect::<Vec<_>>() })))
        }
        "quantile" | "sample" => {
            let count = if strategy == "sample" { p * args.chunks_per_worker } else { p };
            if count == 1 { return Ok((vec!["TRUE".into()], json!({}))); }
            let fractions = (1..count).map(|i| format!("{}", i as f64 / count as f64)).collect::<Vec<_>>().join(",");
            let sampling = if strategy == "sample" { format!(" TABLESAMPLE SYSTEM ({}) REPEATABLE ({})", args.sample_percent, args.seed) } else { String::new() };
            let query = format!("SELECT x::text FROM unnest((SELECT percentile_disc(ARRAY[{fractions}]::float8[]) WITHIN GROUP (ORDER BY {key}) FROM ONLY {relation}{sampling})) x");
            let cuts = client.query(&query, &[]).await?.iter().map(|row| integer(&row.get::<_,String>(0))).collect::<Result<Vec<_>>>()?;
            Ok((ranges(key, cuts.clone()), json!({"cuts":cuts.iter().map(ToString::to_string).collect::<Vec<_>>(),"sample_percent": if strategy=="sample" {Some(args.sample_percent)} else {None} })))
        }
        "stats" => {
            let parts = metadata.table.split('.').collect::<Vec<_>>();
            let row = client.query_opt("SELECT histogram_bounds::text FROM pg_stats WHERE schemaname=$1 AND tablename=$2 AND attname=$3 AND NOT inherited", &[&parts[0], &parts[1], &args.key]).await?;
            let bounds = row.and_then(|row| row.get::<_,Option<String>>(0));
            let Some(bounds) = bounds else { return Ok((vec!["TRUE".into()],json!({"fallback_reason":"missing_histogram","mcv_excluded":true}))); };
            let content = bounds.strip_prefix('{').and_then(|s|s.strip_suffix('}')).context("Malformed numeric histogram array")?;
            if content.is_empty() { return Ok((vec!["TRUE".into()],json!({"fallback_reason":"empty_histogram","mcv_excluded":true}))); }
            let histogram = content.split(',').map(|s|integer(s.trim_matches('"'))).collect::<Result<Vec<_>>>()?;
            let count = p.checked_mul(args.chunks_per_worker).context("Chunk count overflow")?;
            let cuts = (1..count).map(|i|histogram[i*(histogram.len()-1)/count]).collect::<Vec<_>>();
            Ok((ranges(key,cuts.clone()),json!({"histogram_entries":histogram.len(),"mcv_excluded":true,"cuts":cuts.iter().map(ToString::to_string).collect::<Vec<_>>()})))
        }
        "modulo" | "hash" => {
            let hash = if metadata.key_type == "numeric" { format!("hash_numeric({key})") } else { format!("hashint8({key}::bigint)") };
            let expr = if strategy == "modulo" { format!("{key} % {p}") } else { format!("{hash}::bigint % {p}") };
            Ok(((0..p).map(|i|format!("(({expr}) + {p}) % {p} = {i}")).collect(),json!({})))
        }
        "hash_ctid" => {
            // Hash chooses a worker only, never substitutes for row identity.
            // Physical addresses are stable for the imported shared snapshot.
            let predicates = (0..p).map(|i|format!("((pg_catalog.hashtid(ctid)::bigint % {p}) + {p}) % {p} = {i}")).collect();
            Ok((predicates,json!({"assignment":"hash of physical tuple address in shared snapshot","full_heap_scans":p})))
        }
        "ctid" | "ctid_queue" => {
            let size: i64 = client.query_one("SELECT pg_relation_size($1::text::regclass)", &[relation]).await?.get(0);
            let pages = (size as u64).div_ceil(metadata.block_size);
            let count = if strategy == "ctid_queue" { p * args.chunks_per_worker } else { p } as u64;
            let width = pages.div_ceil(count).max(1);
            let cuts = (width..pages).step_by(width as usize).collect::<Vec<_>>();
            if cuts.is_empty() { return Ok((vec!["TRUE".into()],json!({"pages":pages,"pages_per_chunk":width}))); }
            let mut predicates = vec![format!("ctid < '({},0)'::tid", cuts[0])];
            for pair in cuts.windows(2) { predicates.push(format!("ctid >= '({},0)'::tid AND ctid < '({},0)'::tid",pair[0],pair[1])); }
            predicates.push(format!("ctid >= '({},0)'::tid",cuts[cuts.len()-1]));
            Ok((predicates,json!({"pages":pages,"pages_per_chunk":width})))
        }
        "weighted_ctid" => {
            let count = p.checked_mul(args.chunks_per_worker).context("Chunk count overflow")?;
            // BERNOULLI samples rows across the heap, including a localized band
            // of wide/TOASTed rows. Sampling still visits the entire heap; all
            // that work is inside planner timing. Whole-row datum size is an
            // estimated output weight, not exact binary COPY framing size.
            // TID order/comparison and cumulative sums stay inside PostgreSQL.
            // Multiplication avoids floating-point quantiles or rounded weights.
            let query = format!(r#"
                WITH sampled AS MATERIALIZED (
                    SELECT t.ctid AS tid, pg_column_size(t.*)::bigint AS weight_bytes
                    FROM ONLY {relation} AS t
                    TABLESAMPLE BERNOULLI ({sample_percent}) REPEATABLE ({seed})
                ), weighted AS MATERIALIZED (
                    SELECT tid, sum(weight_bytes) OVER (
                        ORDER BY tid ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                    ) AS cumulative_bytes
                    FROM sampled
                ), totals AS MATERIALIZED (
                    SELECT count(*) AS sampled_rows,
                           coalesce(sum(weight_bytes), 0) AS sampled_weight_bytes
                    FROM sampled
                ), cuts AS (
                    SELECT DISTINCT chosen.tid
                    FROM totals
                    CROSS JOIN generate_series(1::bigint, {count}::bigint - 1) AS target(i)
                    CROSS JOIN LATERAL (
                        SELECT tid FROM weighted
                        WHERE weighted.cumulative_bytes * {count} >= totals.sampled_weight_bytes * target.i
                        ORDER BY tid LIMIT 1
                    ) AS chosen
                )
                SELECT totals.sampled_rows::text, totals.sampled_weight_bytes::text,
                       (SELECT coalesce(array_agg(tid::text ORDER BY tid), ARRAY[]::text[]) FROM cuts)
                FROM totals
            "#, sample_percent=args.sample_percent, seed=args.seed);
            let row = client.query_one(&query, &[]).await?;
            let sampled_rows: u64 = row.get::<_, String>(0).parse()?;
            let sampled_weight_bytes = row.get::<_, String>(1);
            let cuts: Vec<String> = row.get(2);
            let mut detail = json!({
                "sample_method":"bernoulli", "sample_percent":args.sample_percent,
                "weight":"pg_column_size(whole-row datum)", "sampled_rows":sampled_rows,
                "sampled_weight_bytes":sampled_weight_bytes, "target_chunks":count,
                "cuts":cuts,
            });
            if cuts.is_empty() {
                detail["fallback_reason"] = json!(if sampled_rows == 0 {"empty_sample"} else {"no_internal_boundaries"});
                detail["realized_chunks"] = json!(1);
                return Ok((vec!["TRUE".into()], detail));
            }
            let mut predicates = vec![format!("ctid < {}::tid", literal(&cuts[0]))];
            for pair in cuts.windows(2) {
                predicates.push(format!("ctid >= {}::tid AND ctid < {}::tid", literal(&pair[0]), literal(&pair[1])));
            }
            predicates.push(format!("ctid >= {}::tid", literal(&cuts[cuts.len()-1])));
            detail["realized_chunks"] = json!(predicates.len());
            Ok((predicates, detail))
        }
        "weighted_ctid_linear" => {
            let count = p.checked_mul(args.chunks_per_worker).context("Chunk count overflow")?;
            // For positive weights, a row is the first row crossing at least one
            // internal target iff floor(cum*K/total) exceeds floor(prev*K/total)
            // and prev has not crossed target K-1. div(numeric,numeric) is exact
            // integer division; repeated targets naturally emit just one TID.
            // This preserves weighted_ctid's cuts without K sample rescans.
            let query = format!(r#"
                WITH sampled AS MATERIALIZED (
                    SELECT t.ctid AS tid, pg_column_size(t.*)::bigint AS weight_bytes
                    FROM ONLY {relation} AS t
                    TABLESAMPLE BERNOULLI ({sample_percent}) REPEATABLE ({seed})
                ), weighted AS MATERIALIZED (
                    SELECT tid, weight_bytes, sum(weight_bytes) OVER (
                        ORDER BY tid ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                    ) AS cumulative_bytes
                    FROM sampled
                ), totals AS MATERIALIZED (
                    SELECT count(*) AS sampled_rows,
                           coalesce(sum(weight_bytes), 0) AS sampled_weight_bytes
                    FROM sampled
                ), cuts AS (
                    SELECT weighted.tid FROM weighted CROSS JOIN totals
                    WHERE div(weighted.cumulative_bytes * {count}, nullif(totals.sampled_weight_bytes, 0))
                        > div((weighted.cumulative_bytes - weighted.weight_bytes) * {count}, nullif(totals.sampled_weight_bytes, 0))
                      AND div((weighted.cumulative_bytes - weighted.weight_bytes) * {count}, nullif(totals.sampled_weight_bytes, 0))
                        < {count} - 1
                )
                SELECT totals.sampled_rows::text, totals.sampled_weight_bytes::text,
                       (SELECT coalesce(array_agg(tid::text ORDER BY tid), ARRAY[]::text[]) FROM cuts)
                FROM totals
            "#, sample_percent=args.sample_percent, seed=args.seed);
            let row = client.query_one(&query, &[]).await?;
            let sampled_rows: u64 = row.get::<_, String>(0).parse()?;
            let sampled_weight_bytes = row.get::<_, String>(1);
            let cuts: Vec<String> = row.get(2);
            let mut detail = json!({
                "sample_method":"bernoulli", "sample_percent":args.sample_percent,
                "weight":"pg_column_size(whole-row datum)", "sampled_rows":sampled_rows,
                "sampled_weight_bytes":sampled_weight_bytes, "target_chunks":count,
                "boundary_selection":"one pass after native-TID cumulative-weight sort",
                "cuts":cuts,
            });
            if cuts.is_empty() {
                detail["fallback_reason"] = json!(if sampled_rows == 0 {"empty_sample"} else if sampled_weight_bytes == "0" {"zero_sample_weight"} else {"no_internal_boundaries"});
                detail["realized_chunks"] = json!(1);
                return Ok((vec!["TRUE".into()], detail));
            }
            let mut predicates = vec![format!("ctid < {}::tid", literal(&cuts[0]))];
            for pair in cuts.windows(2) {
                predicates.push(format!("ctid >= {}::tid AND ctid < {}::tid", literal(&pair[0]), literal(&pair[1])));
            }
            predicates.push(format!("ctid >= {}::tid", literal(&cuts[cuts.len()-1])));
            detail["realized_chunks"] = json!(predicates.len());
            Ok((predicates, detail))
        }
        "keyset" => {
            let target = metadata.rows.div_ceil((p * args.chunks_per_worker) as u64).max(1);
            let mut cuts = Vec::new(); let mut predicate = "TRUE".to_string();
            loop {
                let row = client.query_opt(&format!("SELECT {key}::text AS boundary FROM ONLY {relation} WHERE {predicate} ORDER BY {key} OFFSET {target} LIMIT 1"), &[]).await?;
                let Some(row) = row else { break; }; let cut = integer(&row.get::<_,String>(0))?;
                if cuts.last().is_some_and(|last| *last >= cut) { bail!("Keyset boundary did not advance"); }
                cuts.push(cut); predicate = format!("{key} >= {cut}");
            }
            Ok((ranges(key,cuts.clone()),json!({"target_rows":target,"cuts":cuts.iter().map(ToString::to_string).collect::<Vec<_>>() })))
        }
        _ => bail!("Unknown strategy"),
    }
}

// Streaming PostgreSQL binary COPY framing parser. It retains at most 19 header
// bytes, four scalar bytes and counters; field payloads are never copied/decoded.
#[derive(Clone, Copy)]
enum Stage { Header, Extension, Tuple, Length, Payload, Done }
struct BinaryCounter { stage: Stage, scratch: [u8;19], have: usize, skip: usize, fields: i16, columns: Option<i16>, rows: u64 }
impl BinaryCounter {
    fn new() -> Self { Self { stage:Stage::Header,scratch:[0;19],have:0,skip:0,fields:0,columns:None,rows:0 } }
    fn finish_field(&mut self) -> Result<()> {
        self.fields -= 1;
        if self.fields == 0 { self.rows = self.rows.checked_add(1).context("Row count overflow")?; self.stage=Stage::Tuple; }
        else { self.stage=Stage::Length; }
        Ok(())
    }
    fn feed(&mut self, mut data: &[u8]) -> Result<()> {
        while !data.is_empty() {
            match self.stage {
                Stage::Done => bail!("Bytes after binary COPY trailer"),
                Stage::Extension | Stage::Payload => {
                    let take = self.skip.min(data.len()); self.skip -= take; data=&data[take..];
                    if self.skip==0 { if matches!(self.stage,Stage::Extension) { self.stage=Stage::Tuple; } else { self.finish_field()?; } }
                }
                _ => {
                    let need = match self.stage { Stage::Header=>19, Stage::Tuple=>2, Stage::Length=>4, _=>unreachable!() };
                    let take=(need-self.have).min(data.len()); self.scratch[self.have..self.have+take].copy_from_slice(&data[..take]); self.have+=take; data=&data[take..];
                    if self.have<need { continue; } self.have=0;
                    match self.stage {
                        Stage::Header => {
                            if &self.scratch[..11]!=b"PGCOPY\n\xff\r\n\0" { bail!("Invalid binary COPY signature"); }
                            let flags=u32::from_be_bytes(self.scratch[11..15].try_into()?);
                            let extension=i32::from_be_bytes(self.scratch[15..19].try_into()?);
                            if flags!=0 || extension<0 { bail!("Unsupported binary COPY header"); }
                            self.skip=extension as usize; self.stage=if self.skip==0 {Stage::Tuple} else {Stage::Extension};
                        }
                        Stage::Tuple => {
                            let fields=i16::from_be_bytes(self.scratch[..2].try_into()?);
                            if fields == -1 { self.stage=Stage::Done; continue; }
                            if fields<0 || self.columns.is_some_and(|n|n!=fields) { bail!("Inconsistent COPY column count"); }
                            self.columns=Some(fields); self.fields=fields;
                            if fields==0 { self.rows=self.rows.checked_add(1).context("Row count overflow")?; } else { self.stage=Stage::Length; }
                        }
                        Stage::Length => {
                            let length=i32::from_be_bytes(self.scratch[..4].try_into()?);
                            if length < -1 { bail!("Invalid binary COPY field length"); }
                            if length<=0 { self.finish_field()?; } else { self.skip=length as usize; self.stage=Stage::Payload; }
                        }
                        _=>unreachable!(),
                    }
                }
            }
        }
        Ok(())
    }
    fn finish(self) -> Result<u64> { if !matches!(self.stage,Stage::Done) { bail!("Truncated binary COPY stream"); } Ok(self.rows) }
}
async fn scan_chunk(client: &Client, relation: &str, predicate: &str, worker: usize, chunk_id: usize, run_id: &str) -> Result<Value> {
    let started=Instant::now(); let mut first=None; let mut bytes=0u64; let mut blocks=0u64; let mut counter=BinaryCounter::new();
    let query=format!("COPY (SELECT * FROM ONLY {relation} WHERE {predicate}) TO STDOUT (FORMAT BINARY)");
    let stream=client.copy_out(&query).await?; futures_util::pin_mut!(stream);
    while let Some(block)=stream.try_next().await? {
        if first.is_none() { first=Some(started.elapsed().as_secs_f64()); }
        bytes=bytes.checked_add(block.len() as u64).context("COPY byte count overflow")?; blocks+=1; counter.feed(&block)?;
    }
    let rows=counter.finish()?;
    Ok(json!({"kind":"chunk","run_id":run_id,"chunk_id":chunk_id,"worker":worker,"predicate":predicate,"rows":rows,"copy_payload_bytes":bytes,"blocks":blocks,"seconds":started.elapsed().as_secs_f64(),"first_block_seconds":first,"client_cpu_seconds":null}))
}
fn process_cpu() -> f64 {
    let mut usage=std::mem::MaybeUninit::<libc::rusage>::uninit();
    // getrusage initializes the pointed-to rusage on success; no shared memory.
    if unsafe { libc::getrusage(libc::RUSAGE_SELF,usage.as_mut_ptr()) }!=0 { return 0.0; }
    let usage=unsafe {usage.assume_init()};
    usage.ru_utime.tv_sec as f64 + usage.ru_utime.tv_usec as f64 / 1e6 + usage.ru_stime.tv_sec as f64 + usage.ru_stime.tv_usec as f64 / 1e6
}
fn shuffle<T>(values: &mut [T], seed: u64) {
    let mut state=seed^0x9e3779b97f4a7c15;
    for i in (1..values.len()).rev() { state^=state<<13; state^=state>>7; state^=state<<17; values.swap(i,(state%(i as u64+1)) as usize); }
}
async fn experiment(args: &Args, output: &mut Output) -> Result<()> {
    output.write(&json!({"kind":"experiment","language":"Rust","release_build":!cfg!(debug_assertions),"started_unix_seconds":SystemTime::now().duration_since(UNIX_EPOCH)?.as_secs(),"consumer":"rust_release","copy_parser":"tokio-postgres binary framing; discards field payloads","debug_assertions":cfg!(debug_assertions),"tokio_worker_threads":16,"cache_policy":"reference key aggregates may warm indexes; no forced cache eviction; no guaranteed heap warmup","timing_policy":"total=planning+scan; connection setup and EXPLAIN reported separately; run CPU is process CPU across Tokio tasks","byte_semantics":"PostgreSQL binary COPY payload and framing, excluding TCP/TLS overhead","seed":args.seed,"server_parallel_workers_per_gather":args.server_parallel_workers,"strategies":args.strategies,"parallelism":args.parallelism,"repetitions":args.repetitions,"chunks_per_worker":args.chunks_per_worker,"sample_percent":args.sample_percent,"key":args.key,"max_minutes":args.max_minutes,"statement_timeout_ms":args.statement_timeout_ms,"lock_timeout_ms":args.lock_timeout_ms,"connect_timeout_seconds":args.connect_timeout,"ssl_mode":env::var("PGSSLMODE").unwrap_or_else(|_|"verify-full".into())}))?;
    let mut run_index=0;
    for table in &args.tables {
        let coordinator=connect(args,None).await?; let relation=relation(table)?;
        coordinator.batch_execute(&format!("LOCK TABLE ONLY {relation} IN ACCESS SHARE MODE")).await?;
        let snapshot:String=coordinator.query_one("SELECT pg_export_snapshot()",&[]).await?.get(0);
        let metadata=metadata(&coordinator,table,args).await?;
        let server=coordinator.query_one("SELECT version(),current_database(),inet_server_addr()::text,inet_server_port(),pg_is_in_recovery()",&[]).await?;
        let mut details=metadata.value.clone(); details["snapshot"]=json!(snapshot); details["server"]=json!([server.get::<_,String>(0),server.get::<_,String>(1),server.get::<_,Option<String>>(2).unwrap_or_default(),server.get::<_,Option<i32>>(3).unwrap_or_default().to_string(),server.get::<_,bool>(4).to_string()]); output.write(&details)?;
        let mut schedule=Vec::new();
        for repetition in 1..=args.repetitions { for strategy in &args.strategies { for &p in &args.parallelism { if strategy!="single" || p==1 {schedule.push((repetition,strategy.clone(),p));} } } }
        shuffle(&mut schedule,args.seed); output.write(&json!({"kind":"schedule","table":table,"runs":schedule}))?;
        for (repetition,strategy,p) in schedule {
            run_index+=1; let run_id=format!("{run_index:05}");
            let startup=Instant::now(); let readers=try_join_all((0..p).map(|_|connect(args,Some(&snapshot)))).await?; let startup_seconds=startup.elapsed().as_secs_f64();
            let planning=Instant::now(); let (predicates,detail)=plan(&coordinator,&metadata,&strategy,p,args).await?; let planning_seconds=planning.elapsed().as_secs_f64();
            output.write(&json!({"kind":"plan","run_id":run_id,"table":table,"strategy":strategy,"parallelism":p,"planning_seconds":planning_seconds,"detail":detail,"predicates":predicates}))?;
            if args.explain {
                let mut plans=Vec::new(); let mut indices=vec![0,predicates.len()/2]; indices.dedup();
                for index in indices { let rows=coordinator.simple_query(&format!("EXPLAIN (FORMAT JSON) SELECT * FROM ONLY {relation} WHERE {}",predicates[index])).await?;
                    for row in rows { if let tokio_postgres::SimpleQueryMessage::Row(row)=row { plans.push(json!({"chunk_id":index,"plan":serde_json::from_str::<Value>(row.get(0).context("EXPLAIN empty")?)?})); } }
                }
                output.write(&json!({"kind":"explain","run_id":run_id,"plans":plans}))?;
            }
            let predicates=Arc::new(predicates); let next=Arc::new(AtomicUsize::new(0)); let started=Instant::now(); let cpu_start=process_cpu(); let mut workers=tokio::task::JoinSet::new();
            for (worker,client) in readers.into_iter().enumerate() {
                let predicates=predicates.clone(); let next=next.clone(); let relation=relation.clone(); let run_id=run_id.clone();
                workers.spawn(async move {
                    let mut results=Vec::new();
                    loop { let index=next.fetch_add(1,Ordering::Relaxed); if index>=predicates.len() {break;} results.push(scan_chunk(&client,&relation,&predicates[index],worker,index,&run_id).await?); }
                    Ok::<_,anyhow::Error>(results)
                });
            }
            let mut chunks=Vec::new(); while let Some(result)=workers.join_next().await {chunks.extend(result??);}
            let scan_seconds=started.elapsed().as_secs_f64(); let cpu_seconds=process_cpu()-cpu_start;
            let rows=chunks.iter().map(|v|v["rows"].as_u64().unwrap()).sum::<u64>();
            let bytes=chunks.iter().map(|v|v["copy_payload_bytes"].as_u64().unwrap()).sum::<u64>();
            let mut times=chunks.iter().map(|v|v["seconds"].as_f64().unwrap()).collect::<Vec<_>>(); times.sort_by(f64::total_cmp);
            let median=if times.len()%2==0 {(times[times.len()/2-1]+times[times.len()/2])/2.0} else {times[times.len()/2]};
            let run=json!({"kind":"run","run_id":run_id,"table":table,"strategy":strategy,"parallelism":p,"repetition":repetition,"planning_seconds":planning_seconds,"scan_seconds":scan_seconds,"total_seconds":planning_seconds+scan_seconds,"worker_startup_seconds":startup_seconds,"rows":rows,"copy_payload_bytes":bytes,"rows_per_second":rows as f64/scan_seconds,"mib_per_second":bytes as f64/scan_seconds/1048576.0,"chunks":chunks.len(),"client_cpu_seconds":cpu_seconds,"chunk_max_seconds":times.last(),"chunk_median_seconds":median,"chunk_rows_min":chunks.iter().map(|v|v["rows"].as_u64().unwrap()).min(),"chunk_rows_max":chunks.iter().map(|v|v["rows"].as_u64().unwrap()).max(),"expected_rows":metadata.rows,"row_count_matches":rows==metadata.rows,"release_build":!cfg!(debug_assertions)});
            for chunk in chunks {output.write(&chunk)?;} output.write(&run)?; println!("{run}");
            if rows!=metadata.rows {bail!("Row count mismatch: {rows} != {}",metadata.rows);}
            if args.explain_analyze {
                let mut plans=Vec::new(); let mut indices=vec![0,predicates.len()-1]; indices.dedup();
                for index in indices {
                    let rows=coordinator.simple_query(&format!("EXPLAIN (ANALYZE, BUFFERS, TIMING OFF, FORMAT JSON) SELECT * FROM ONLY {relation} WHERE {}",predicates[index])).await?;
                    for row in rows { if let tokio_postgres::SimpleQueryMessage::Row(row)=row {
                        plans.push(json!({"chunk_id":index,"plan":serde_json::from_str::<Value>(row.get(0).context("EXPLAIN empty")?)?}));
                    } }
                }
                output.write(&json!({"kind":"explain_analyze","run_id":run_id,"plans":plans,"outside_timed_scan":true}))?;
            }
        }
        coordinator.batch_execute("ROLLBACK").await?;
    }
    output.write(&json!({"kind":"complete","runs":run_index}))?; Ok(())
}
#[tokio::main(flavor = "multi_thread", worker_threads = 16)]
async fn main() -> Result<()> {
    let args=Args::parse()?;
    if cfg!(debug_assertions) {bail!("Benchmark requires a RELEASE build (cargo build --release)");}
    let mut output=Output::new(&args.output)?;
    let result=tokio::time::timeout(Duration::from_secs_f64(args.max_minutes*60.0),experiment(&args,&mut output)).await;
    let result=match result {Ok(result)=>result,Err(_)=>Err(anyhow!("Overall benchmark time budget exhausted"))};
    if let Err(error)=&result {output.write(&json!({"kind":"error","error":format!("{error:#}")}))?;}
    result
}

#[cfg(test)]
mod tests;
