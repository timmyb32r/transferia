# PostgreSQL snapshot benchmark: обязательства

Старт: 2026-09-20 17:43:33 UTC. Жёсткий предел: **19:13:33 UTC** (90 минут).
Репликация исключена. Пользователь разрешил изменения тестовой БД и кода,
необходимые для бенчмарка. Пароль не сохраняется в артефактах.

| Обязательство | Критерий | Статус |
|---|---|---|
| Профили генератора | Несколько реальных профилей Transferia, загрузка в PG с PK, зафиксированные параметры и размеры | verified: numeric 2M, transfer_logs 1M, clickbench 500k; derived key-skew 2M, bloat 200k, TOAST-skew 200k |
| Сравнение snapshot | Одинаковые данные/проекция/ресурсы, реальное чтение строк, shared snapshot; planning/read/total и repetitions | verified: 1044 Rust RELEASE runs (666 + 270 + 108), exact row counts; 20 diagnostic COPY and 40 EXPLAIN plans kept separate |
| Краевые случаи | Skew/пробелы, границы и типы, NULL при PK, MVCC/изменения; измерения или явные пределы проверки | verified: 34/34 functional scenarios, exact identity checks; unsupported and untested cases explicitly listed |
| PostgreSQL source | Узкий аудит executor/planner/MVCC, подтверждённые факты отдельно от гипотез | verified: POSTGRES-SOURCE-AUDIT.md; PG20 local differences checked against PG17 |
| Анализ и графики | Простой отчёт, исходные результаты и воспроизводимые команды, гистограмма/столбчатая диаграмма | verified: main report, all three series CSV/JSON/PNG/SVG, raw event archives, source versions and reproduction commands |
| Выбор алгоритма | Правила выбора по измеренным условиям, корректность/retry, не обещать универсальную оптимальность | verified: selection table, pages/rows/bytes cost model and snapshot/lock/retry contracts; proposed adaptive integration distinguished from measured prototypes |
| Итоговая проверка | Числа соответствуют raw data, ошибки не спрятаны; всё закончено до дедлайна | verified: independent report/raw audit, 1044/1044 row counts, 34/34 edges, 6/6 release parser/boundary tests, Rust release build and runtime execution, artifact links and secret scan |

Делегировано: generator_loader — профили/configs; snapshot_harness — измеритель;
postgres_edges — исходники PostgreSQL и edge cases. Root отвечает за среду,
запуски, нагрузку БД, сведение данных и итог. Нагрузочные процессы в БД не
запускаются агентами независимо друг от друга.

План времени: 0–15 мин среда и loader; 15–35 мин данные и smoke;
35–65 мин измерения и края; 65–85 мин анализ/графики; 85–90 мин handoff.
Если сборка/размер данных угрожает сроку, уменьшать объём и число комбинаций,
сохраняя реальные профили, корректность и явно фиксируя пределы вывода.

## Уточнения пользователя во время выполнения

- 18:04 UTC: все измерения производительности выполнять **Rust release**. Python matrix остановлена; Python/C pilot исключены из итогового сравнения. Python допустим только для offline charts и функциональных SQL checks. Реализуется отдельный полностью Rust coordinator/reader.
- Расширить corners: составные PK, разные типы, NULL, несколько видов skew, отсутствующая/ошибочная/устаревшая статистика. Алгоритм обязан явно выбирать применимый путь; непроверенные случаи не объявлять проверенными. Итог: 34/34 функциональных checks; полного покрытия всех типов/DDL PostgreSQL не заявляется.

Основная матрица завершена в 18:30 UTC: 666/666 успешных Rust RELEASE runs.
Дополнительная серия: 270 runs, weighted CTID и 8/16/32 readers. Уточнённая:
108 runs, hash(CTID) и линейный выбор weighted-границ. Все процессы измерения
завершены. Окончательная функциональная матрица: 34/34; ошибочное предположение,
что READ ONLY запрещает SHARE UPDATE EXCLUSIVE, исправлено и перепроверено.

Финальный аудит и отчёт завершены 19:02 UTC, примерно за 79 минут, до предела
19:13:33 UTC. `just check-affected` завершился успешно и определил, что production
code не затронут; standalone benchmark crate проверен отдельно release-сборкой,
тестами и реальными запусками. Production pipeline не менялся.

Необязательная уборка: automatic approval review отклонил удаление 23 ранних
временных таблиц в public, потребовав отдельное согласие на конкретные имена.
Удаление не выполнялось; SQL для просмотра — `fixtures/optional-cleanup.sql`.
Пользователю задан отдельный вопрос, таблицы оставлены до ответа. Это не мешает
готовности бенчмарка и не является незавершённым обязательством исследования.
