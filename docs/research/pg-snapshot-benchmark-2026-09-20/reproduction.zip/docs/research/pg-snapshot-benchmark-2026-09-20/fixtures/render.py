#!/usr/bin/env python3
"""Render generator→PostgreSQL benchmark configs; never print credentials."""
import argparse
import json
import os
import subprocess
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--profile", choices=["numeric", "transfer_logs", "clickbench"], required=True)
parser.add_argument("--rows", type=int, required=True)
parser.add_argument("--start-row", type=int, default=0)
parser.add_argument("--column-count", type=int, default=8)
parser.add_argument("--table")
destination = parser.add_mutually_exclusive_group(required=True)
destination.add_argument("--output", type=Path)
destination.add_argument("--run", type=Path, help="Run binary; secret config goes only through stdin")
args = parser.parse_args()
if args.rows < 1 or args.start_row < 0 or args.column_count < 1:
    parser.error("rows/column-count must be positive; start-row nonnegative")

template = Path(__file__).parent / (args.profile + ".json")
config = json.loads(template.read_text())
source = config["source"]["data_generator"]
source["amount"]["row_count"] = args.rows
source["start_row"] = args.start_row
if args.table:
    source["table_name"] = args.table
if args.profile == "numeric":
    source["preset"]["column_count"] = args.column_count
config["delivery_id"] = "pgsnap-load-" + source["table_name"]
sink = config["sink"]["postgres"]
sink["installation"]["host"] = os.environ["PGHOST"]
sink["installation"]["port"] = int(os.environ.get("PGPORT", "6432"))
sink["installation"]["tls_ca_file"] = os.environ.get("PGSSLROOTCERT")
sink["database"] = os.environ.get("PGDATABASE", "db1")
sink["username"] = os.environ.get("PGUSER", "user1")
sink["password"] = os.environ["PGPASSWORD"]
if args.run:
    environment = os.environ.copy()
    environment.pop("PGPASSWORD", None)
    result = subprocess.run(
        [str(args.run.resolve()), "--config", "/dev/stdin"],
        input=json.dumps(config).encode(),
        env=environment,
        check=False,
    )
    raise SystemExit(result.returncode)
args.output.parent.mkdir(parents=True, exist_ok=True)
fd = os.open(args.output, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
os.fchmod(fd, 0o600)
with os.fdopen(fd, "w") as handle:
    json.dump(config, handle, indent=2)
    handle.write("\n")
print(args.output)
